"use strict";
/**
 * Copyright (c) 2026 The xterm.js authors. All rights reserved.
 * @license MIT
 */
Object.defineProperty(exports, "__esModule", { value: true });
const xterm_benchmark_1 = require("xterm-benchmark");
const Event_1 = require("common/Event");
const ITERATIONS = 1_000_000;
(0, xterm_benchmark_1.perfContext)('Emitter.fire()', () => {
    (0, xterm_benchmark_1.perfContext)('0 listeners', () => {
        let emitter;
        (0, xterm_benchmark_1.before)(() => {
            emitter = new Event_1.Emitter();
        });
        new xterm_benchmark_1.RuntimeCase('', () => {
            for (let i = 0; i < ITERATIONS; i++) {
                emitter.fire(i);
            }
            return { payloadSize: ITERATIONS };
        }, { fork: false }).showAverageRuntime();
    });
    (0, xterm_benchmark_1.perfContext)('1 listener', () => {
        let emitter;
        let sum = 0;
        (0, xterm_benchmark_1.before)(() => {
            emitter = new Event_1.Emitter();
            emitter.event(e => { sum += e; });
        });
        new xterm_benchmark_1.RuntimeCase('', () => {
            for (let i = 0; i < ITERATIONS; i++) {
                emitter.fire(i);
            }
            return { payloadSize: ITERATIONS, sum };
        }, { fork: false }).showAverageRuntime();
    });
    (0, xterm_benchmark_1.perfContext)('2 listeners', () => {
        let emitter;
        let sum = 0;
        (0, xterm_benchmark_1.before)(() => {
            emitter = new Event_1.Emitter();
            emitter.event(e => { sum += e; });
            emitter.event(e => { sum += e * 2; });
        });
        new xterm_benchmark_1.RuntimeCase('', () => {
            for (let i = 0; i < ITERATIONS; i++) {
                emitter.fire(i);
            }
            return { payloadSize: ITERATIONS, sum };
        }, { fork: false }).showAverageRuntime();
    });
    (0, xterm_benchmark_1.perfContext)('5 listeners', () => {
        let emitter;
        let sum = 0;
        (0, xterm_benchmark_1.before)(() => {
            emitter = new Event_1.Emitter();
            for (let j = 0; j < 5; j++) {
                emitter.event(e => { sum += e; });
            }
        });
        new xterm_benchmark_1.RuntimeCase('', () => {
            for (let i = 0; i < ITERATIONS; i++) {
                emitter.fire(i);
            }
            return { payloadSize: ITERATIONS, sum };
        }, { fork: false }).showAverageRuntime();
    });
});
