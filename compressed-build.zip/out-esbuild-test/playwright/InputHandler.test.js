"use strict";
var import_test = require("@playwright/test");
var import_assert = require("assert");
var import_TestUtils = require("./TestUtils");
/**
 * Copyright (c) 2019 The xterm.js authors. All rights reserved.
 * @license MIT
 */
let ctx;
import_test.test.beforeAll(async ({ browser }) => {
  ctx = await (0, import_TestUtils.createTestContext)(browser);
  await (0, import_TestUtils.openTerminal)(ctx);
});
import_test.test.afterAll(async () => await ctx.page.close());
import_test.test.describe("InputHandler Integration Tests", () => {
  let recordedData;
  let recordDataDisposable;
  import_test.test.beforeAll(async () => {
    recordedData = [];
    recordDataDisposable = ctx.proxy.onData((d) => recordedData.push(d));
  });
  import_test.test.afterAll(async () => {
    recordDataDisposable.dispose();
  });
  import_test.test.beforeEach(async () => {
    recordedData.length = 0;
    await ctx.proxy.resize(80, 24);
  });
  import_test.test.describe("CSI", () => {
    import_test.test.beforeEach(async () => await ctx.proxy.reset());
    (0, import_test.test)("CSI Ps @ - ICH: Insert Ps (Blank) Character(s) (default = 1)", async () => {
      await ctx.proxy.write("foo\x1B[3D\x1B[@\n\r");
      await ctx.proxy.write("bar\x1B[3D\x1B[4@");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(2), [" foo", "    bar"]);
    });
    (0, import_test.test)("CSI Ps SP @ - SL: Shift left Ps columns(s) (default = 1), ECMA-48", async () => {
      await ctx.proxy.write("abcdefg\x1B[ @");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["bcdefg"]);
      await ctx.proxy.reset();
      await ctx.proxy.write("abcdefg\x1B[3 @");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["defg"]);
    });
    (0, import_test.test)("CSI Ps A - CUU: Cursor Up Ps Times (default = 1)", async () => {
      await ctx.proxy.write("\n\n\n\n\x1B[Aa");
      await ctx.proxy.write("\x1B[2Ab");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(4), ["", " b", "", "a"]);
    });
    (0, import_test.test)("CSI Ps B - CUD: Cursor Down Ps Times (default = 1)", async () => {
      await ctx.proxy.write("\x1B[Ba");
      await ctx.proxy.write("\x1B[2Bb");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(4), ["", "a", "", " b"]);
    });
    (0, import_test.test)("CSI Ps C - CUF: Cursor Forward Ps Times (default = 1)", async () => {
      await ctx.proxy.write("\x1B[Ca");
      await ctx.proxy.write("\x1B[2Cb");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), [" a  b"]);
    });
    (0, import_test.test)("CSI Ps D - CUB: Cursor Backward Ps Times (default = 1)", async () => {
      await ctx.proxy.write("foo\x1B[Da");
      await ctx.proxy.write("\x1B[2Db");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["fba"]);
    });
    (0, import_test.test)("CSI Ps E - CNL: Cursor Next Line Ps Times (default = 1)", async () => {
      await ctx.proxy.write("\x1B[Ea");
      await ctx.proxy.write("\x1B[2Eb");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(4), ["", "a", "", "b"]);
    });
    (0, import_test.test)("CSI Ps F - CPL: Cursor Preceding Line Ps Times (default = 1)", async () => {
      await ctx.proxy.write("\n\n\n\n\x1B[Fa");
      await ctx.proxy.write("\x1B[2Fb");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(5), ["", "b", "", "a", ""]);
    });
    (0, import_test.test)("CSI Ps G - CHA: Cursor Character Absolute [column] (default = [row,1])", async () => {
      await ctx.proxy.write("foo\x1B[Ga");
      await ctx.proxy.write("\x1B[10Gb");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["aoo      b"]);
    });
    (0, import_test.test)("CSI Ps ; Ps H - CUP: Cursor Position [row;column] (default = [1,1])", async () => {
      await ctx.proxy.write("foo\x1B[Ha");
      await ctx.proxy.write("\x1B[3;3Hb");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(3), ["aoo", "", "  b"]);
    });
    (0, import_test.test)("CSI Ps I - CHT: Cursor Forward Tabulation Ps tab stops (default = 1)", async () => {
      await ctx.proxy.write("\x1B[Ia");
      await ctx.proxy.write("\n\r\x1B[2Ib");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(2), ["        a", "                b"]);
    });
    (0, import_test.test)("CSI Ps J - ED: Erase in Display, VT100", async () => {
      const fixture = "abc\n\rdef\n\rghi\x1B[2;2H";
      await ctx.proxy.resize(5, 5);
      await ctx.proxy.write(fixture + "\x1B[J");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(3), ["abc", "d", ""]);
      await ctx.proxy.reset();
      await ctx.proxy.write(fixture + "\x1B[0J");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(3), ["abc", "d", ""]);
      await ctx.proxy.reset();
      await ctx.proxy.write(fixture + "\x1B[1J");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(3), ["", "  f", "ghi"]);
      await ctx.proxy.reset();
      await ctx.proxy.write("1\n2\n3\n4\n5" + fixture + "\x1B[3J");
      await (0, import_TestUtils.pollFor)(ctx.page, () => ctx.proxy.buffer.active.length, 5);
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(5), ["   4", "    5", "abc", "def", "ghi"]);
    });
    (0, import_test.test)("CSI ? Ps J - DECSED: Erase in Display, VT220", async () => {
      const fixture = "abc\n\rdef\n\rghi\x1B[2;2H";
      await ctx.proxy.resize(5, 5);
      await ctx.proxy.write(fixture + "\x1B[?J");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(3), ["abc", "d", ""]);
      await ctx.proxy.reset();
      await ctx.proxy.write(fixture + "\x1B[?0J");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(3), ["abc", "d", ""]);
      await ctx.proxy.reset();
      await ctx.proxy.write(fixture + "\x1B[?1J");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(3), ["", "  f", "ghi"]);
      await ctx.proxy.reset();
      await ctx.proxy.write("1\n2\n3\n4\n5" + fixture + "\x1B[?3J");
      await (0, import_TestUtils.pollFor)(ctx.page, () => ctx.proxy.buffer.active.length, 5);
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(5), ["   4", "    5", "abc", "def", "ghi"]);
    });
    (0, import_test.test)("CSI Ps K - EL: Erase in Line, VT100", async () => {
      const fixture = "abcde\x1B[1;3H";
      await ctx.proxy.write(fixture + "\x1B[K");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["ab"]);
      await ctx.proxy.reset();
      await ctx.proxy.write(fixture + "\x1B[0K");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["ab"]);
      await ctx.proxy.reset();
      await ctx.proxy.write(fixture + "\x1B[1K");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["   de"]);
      await ctx.proxy.reset();
      await ctx.proxy.write(fixture + "\x1B[2K");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), [""]);
    });
    (0, import_test.test)("CSI ? Ps K - DECSEL: Erase in Line, VT220", async () => {
      const fixture = "abcde\x1B[1;3H";
      await ctx.proxy.write(fixture + "\x1B[?K");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["ab"]);
      await ctx.proxy.reset();
      await ctx.proxy.write(fixture + "\x1B[?0K");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["ab"]);
      await ctx.proxy.reset();
      await ctx.proxy.write(fixture + "\x1B[?1K");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["   de"]);
      await ctx.proxy.reset();
      await ctx.proxy.write(fixture + "\x1B[?2K");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), [""]);
    });
    (0, import_test.test)("CSI Ps L - IL: Insert Ps Line(s) (default = 1)", async () => {
      await ctx.proxy.write("foo\x1B[La");
      await ctx.proxy.write("\x1B[2Lb");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(4), ["b", "", "a", "foo"]);
    });
    (0, import_test.test)("CSI Ps M - DL: Delete Ps Line(s) (default = 1)", async () => {
      await ctx.proxy.write("a\nb\x1B[1F\x1B[M");
      await ctx.proxy.write("\x1B[1Ed\ne\nf\x1B[2F\x1B[2M");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(5), [" b", "  f", "", "", ""]);
    });
    (0, import_test.test)("CSI Ps P - DCH: Delete Ps Character(s) (default = 1)", async () => {
      await ctx.proxy.write("abc\x1B[1;1H\x1B[P");
      await ctx.proxy.write("\n\rdef\x1B[2;1H\x1B[2P");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(2), ["bc", "f"]);
    });
    import_test.test.skip("CSI Pm # P - XTPUSHCOLORS: Push current dynamic- and ANSI-palette colors onto stack, xterm", async () => {
    });
    import_test.test.skip("CSI Pm # Q - XTPOPCOLORS: Pop stack to set dynamic- and ANSI-palette colors, xterm", async () => {
    });
    import_test.test.skip("CSI # R - XTREPORTCOLORS: Report the current entry on the palette stack, and the number of palettes stored on the stack, using the same form as XTPOPCOLOR (default = 0), xterm", async () => {
    });
    (0, import_test.test)("CSI Ps S - SU: Scroll up Ps lines (default = 1), VT420, ECMA-48", async () => {
      await ctx.proxy.write("1\r\n2\r\n3\r\n4\r\n5");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(5), ["1", "2", "3", "4", "5"]);
      await ctx.proxy.write("\x1B[S");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(5), ["2", "3", "4", "5", ""]);
      await ctx.proxy.reset();
      await ctx.proxy.write("1\r\n2\r\n3\r\n4\r\n5");
      await ctx.proxy.write("\x1B[2S");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(5), ["3", "4", "5", "", ""]);
    });
    (0, import_test.test)("CSI Ps T - SD: Scroll down Ps lines (default = 1), VT420", async () => {
      await ctx.proxy.write("1\r\n2\r\n3\r\n4\r\n5");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(5), ["1", "2", "3", "4", "5"]);
      await ctx.proxy.write("\x1B[T");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(5), ["", "1", "2", "3", "4"]);
      await ctx.proxy.reset();
      await ctx.proxy.write("1\r\n2\r\n3\r\n4\r\n5");
      await ctx.proxy.write("\x1B[2T");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(5), ["", "", "1", "2", "3"]);
    });
    import_test.test.skip("CSI Ps ; Ps ; Ps ; Ps ; Ps T - XTHIMOUSE: Initiate highlight mouse tracking (XTHIMOUSE), xterm", async () => {
    });
    import_test.test.skip("CSI > Pm T - XTRMTITLE: Reset title mode features to default value, xterm", async () => {
    });
    (0, import_test.test)("CSI Ps X - ECH: Erase Ps Character(s) (default = 1)", async () => {
      await ctx.proxy.write("abcdef\x1B[1;1H\x1B[X");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), [" bcdef"]);
      await ctx.proxy.reset();
      await ctx.proxy.write("abcdef\x1B[1;1H\x1B[3X");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["   def"]);
    });
    (0, import_test.test)("CSI Ps Z - CBT: Cursor Backward Tabulation Ps tab stops (default = 1)", async () => {
      await ctx.proxy.write("\x1B[17Ga\x1B[17G\x1B[Zb");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["        b       a"]);
    });
    (0, import_test.test)("CSI Ps ^ - SD: Scroll down Ps lines (default = 1) (SD), ECMA-48", async () => {
      await ctx.proxy.write("1\r\n2\r\n3\r\n4\r\n5");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(5), ["1", "2", "3", "4", "5"]);
      await ctx.proxy.write("\x1B[^");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(5), ["", "1", "2", "3", "4"]);
      await ctx.proxy.reset();
      await ctx.proxy.write("1\r\n2\r\n3\r\n4\r\n5");
      await ctx.proxy.write("\x1B[2^");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(5), ["", "", "1", "2", "3"]);
    });
    (0, import_test.test)("CSI Ps ` - HPA: Character Position Absolute [column] (default = [row,1])", async () => {
      await ctx.proxy.write("foo\x1B[`a");
      await ctx.proxy.write("\x1B[10`b");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["aoo      b"]);
    });
    (0, import_test.test)("CSI Ps a - HPR: Character Position Relative (default = [row,col+1])", async () => {
      await ctx.proxy.write("a\x1B[2aB");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["a  B"]);
    });
    (0, import_test.test)("CSI Ps b - REP: Repeat preceding character, ECMA48", async () => {
      await ctx.proxy.resize(10, 10);
      await ctx.proxy.write("#\x1B[b");
      await ctx.proxy.writeln("");
      await ctx.proxy.write("#\x1B[0b");
      await ctx.proxy.writeln("");
      await ctx.proxy.write("#\x1B[1b");
      await ctx.proxy.writeln("");
      await ctx.proxy.write("#\x1B[5b");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(4), ["##", "##", "##", "######"]);
      await (0, import_TestUtils.pollFor)(ctx.page, () => getCursor(), { col: 6, row: 3 });
      await ctx.proxy.reset();
      await ctx.proxy.write("\uFFE5\x1B[8b");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["\uFFE5\uFFE5\uFFE5\uFFE5\uFFE5"]);
      await ctx.proxy.reset();
      await ctx.proxy.write("e\u0301\x1B[2b");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["e\u0301e\u0301e\u0301"]);
      await ctx.proxy.reset();
      await ctx.proxy.write("#\x1B[15b");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(2), ["##########", "######"]);
      await ctx.proxy.reset();
      await ctx.proxy.write("\x1B[?7l");
      await ctx.proxy.write("#\x1B[15b");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(2), ["##########", ""]);
      await ctx.proxy.reset();
      await ctx.proxy.write("\x1B[?7h");
      await ctx.proxy.write("#\n\x1B[3b");
      await ctx.proxy.write("#\r\x1B[3b");
      await ctx.proxy.writeln("");
      await ctx.proxy.write("abcdefg\x1B[3D\x1B[10b#\x1B[3b");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(3), ["#", " #", "abcd####"]);
    });
    (0, import_test.test)("CSI Ps c - ", async () => {
      await ctx.proxy.write("\x1B[c");
      await (0, import_TestUtils.pollFor)(ctx.page, () => recordedData, ["\x1B[?1;2c"]);
    });
    import_test.test.skip("CSI = Ps c - ", async () => {
    });
    (0, import_test.test)("CSI > Ps c - ", async () => {
      await ctx.proxy.write("\x1B[>c");
      await (0, import_TestUtils.pollFor)(ctx.page, () => recordedData, ["\x1B[>0;276;0c"]);
    });
    (0, import_test.test)("CSI Ps d - VPA: Line Position Absolute [row] (default = [1,column])", async () => {
      await ctx.proxy.write("\n\n\n   \x1B[da");
      await ctx.proxy.write("\x1B[2d    b");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(4), ["   a", "        b", "", "   "]);
    });
    (0, import_test.test)("CSI Ps e - VPR: Line Position Relative (default = 1)", async () => {
      await ctx.proxy.write("\x1B[ea");
      await ctx.proxy.write("\x1B[2eb");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(4), ["", "a", "", " b"]);
    });
    (0, import_test.test)("CSI Ps ; Ps f - HVP: Horizontal and Vertical Position [row;column] (default = [1,1])", async () => {
      await ctx.proxy.write("foo\x1B[fa");
      await ctx.proxy.write("\x1B[3;3fb");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(3), ["aoo", "", "  b"]);
    });
    (0, import_test.test)("CSI Ps g - TBC: Tab Clear (default = 0)", async () => {
      await ctx.proxy.write("\x1B[9G\x1B[g\x1B[1G	a");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["                a"]);
      await ctx.proxy.reset();
      await ctx.proxy.write("\x1B[3g	a");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["                                                                               a"]);
    });
    (0, import_test.test)("CSI Ps h - SM: Set Mode", async () => {
      await ctx.proxy.write("\x1B[4h");
      await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).insertMode, true);
      await ctx.proxy.write("\x1B[20h");
      await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.getOption("convertEol"), true);
    });
    import_test.test.describe("CSI ? Pm h - DECSET: Private Mode Set", () => {
      (0, import_test.test)("Ps = 1 - Application Cursor Keys (DECCKM), VT100", async () => {
        await ctx.proxy.write("\x1B[?1h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).applicationCursorKeysMode, true);
        recordedData.length = 0;
        await ctx.proxy.focus();
        await ctx.page.keyboard.press("ArrowUp");
        await (0, import_TestUtils.pollFor)(ctx.page, () => recordedData, ["\x1BOA"]);
      });
      (0, import_test.test)("Ps = 2 - Designate USASCII for character sets G0-G3 (DECANM), VT100, and set VT100 mode", async () => {
        await ctx.proxy.write("\x1B(0q\x1B[?2hq");
        await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["\u2500q"]);
      });
      (0, import_test.test)("Ps = 3 - 132 Column Mode (DECCOLM), VT100", async () => {
        const windowOptions = await ctx.proxy.getOption("windowOptions");
        await ctx.proxy.setOption("windowOptions", { ...windowOptions, setWinLines: true });
        await ctx.proxy.write("\x1B[?3h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.cols, 132);
        await ctx.proxy.resize(80, 24);
        await ctx.proxy.setOption("windowOptions", windowOptions);
      });
      (0, import_test.test)("Ps = 4 - Smooth (Slow) Scroll (DECSCLM), VT100", async () => {
        await assertNoModeChange("\x1B[?4h");
      });
      (0, import_test.test)("Ps = 5 - Reverse Video (DECSCNM), VT100", async () => {
        await assertNoModeChange("\x1B[?5h");
      });
      (0, import_test.test)("Ps = 6 - Origin Mode (DECOM), VT100", async () => {
        await ctx.proxy.write("\x1B[?6h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).originMode, true);
        await (0, import_TestUtils.pollFor)(ctx.page, () => getCursor(), { col: 0, row: 0 });
        await ctx.proxy.write("\x1B[2;3r");
        await ctx.proxy.write("\x1B[1;1HX");
        await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(3), ["", "X", ""]);
      });
      (0, import_test.test)("Ps = 7 - Auto-Wrap Mode (DECAWM), VT100", async () => {
        await ctx.proxy.resize(5, 2);
        await ctx.proxy.write("\x1B[?7h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).wraparoundMode, true);
        await ctx.proxy.write("12345X");
        await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(2), ["12345", "X"]);
        await ctx.proxy.reset();
        await ctx.proxy.write("\x1B[?7l");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).wraparoundMode, false);
        await ctx.proxy.write("12345X");
        await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["1234X"]);
        await ctx.proxy.resize(80, 24);
      });
      (0, import_test.test)("Ps = 8 - Auto-Repeat Keys (DECARM), VT100", async () => {
        await assertNoModeChange("\x1B[?8h");
      });
      (0, import_test.test)("Ps = 9 - Send Mouse X & Y on button press", async () => {
        const selectionBefore = await dragSelection();
        (0, import_assert.ok)(selectionBefore > 0);
        await ctx.proxy.write("\x1B[?9h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).mouseTrackingMode, "x10");
        const selectionAfter = await dragSelection();
        (0, import_assert.ok)(selectionAfter === 0);
      });
      (0, import_test.test)("Ps = 1 0 - Show toolbar (rxvt)", async () => {
        await assertNoModeChange("\x1B[?10h");
      });
      (0, import_test.test)("Ps = 1 2 - Start blinking cursor (AT&T 610)", async () => {
        const previousQuirks = await ctx.proxy.getOption("quirks");
        const previousCursorBlink = await ctx.proxy.getOption("cursorBlink");
        await ctx.proxy.setOption("quirks", { ...previousQuirks ?? {}, allowSetCursorBlink: true });
        await ctx.proxy.write("\x1B[?12h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.getOption("cursorBlink"), true);
        await ctx.proxy.setOption("quirks", previousQuirks);
        await ctx.proxy.setOption("cursorBlink", previousCursorBlink);
      });
      (0, import_test.test)("Ps = 1 3 - Start blinking cursor (set only via resource or menu)", async () => {
        await assertNoModeChange("\x1B[?13h");
      });
      (0, import_test.test)("Ps = 1 4 - Enable XOR of blinking cursor control sequence and menu", async () => {
        await assertNoModeChange("\x1B[?14h");
      });
      (0, import_test.test)("Ps = 1 8 - Print Form Feed (DECPFF), VT220", async () => {
        await assertNoModeChange("\x1B[?18h");
      });
      (0, import_test.test)("Ps = 1 9 - Set print extent to full screen (DECPEX), VT220", async () => {
        await assertNoModeChange("\x1B[?19h");
      });
      (0, import_test.test)("Ps = 2 5 - Show cursor (DECTCEM), VT220", async () => {
        await ctx.proxy.write("\x1B[?25l");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).showCursor, false);
        await ctx.proxy.write("\x1B[?25h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).showCursor, true);
      });
      (0, import_test.test)("Ps = 3 0 - Show scrollbar (rxvt)", async () => {
        await assertNoModeChange("\x1B[?30h");
      });
      (0, import_test.test)("Ps = 3 5 - Enable font-shifting functions (rxvt)", async () => {
        await assertNoModeChange("\x1B[?35h");
      });
      (0, import_test.test)("Ps = 3 8 - Enter Tektronix mode (DECTEK), VT240, xterm", async () => {
        await assertNoModeChange("\x1B[?38h");
      });
      (0, import_test.test)("Ps = 4 0 - Allow 80 \u21D2  132 mode, xterm", async () => {
        await assertNoModeChange("\x1B[?40h");
      });
      (0, import_test.test)("Ps = 4 1 - more(1) fix (see curses resource)", async () => {
        await assertNoModeChange("\x1B[?41h");
      });
      (0, import_test.test)("Ps = 4 2 - Enable National Replacement Character sets (DECNRCM), VT220", async () => {
        await assertNoModeChange("\x1B[?42h");
      });
      (0, import_test.test)("Ps = 4 3 - Enable Graphic Expanded Print Mode (DECGEPM), VT340", async () => {
        await assertNoModeChange("\x1B[?43h");
      });
      (0, import_test.test)("Ps = 4 4 - Turn on margin bell, xterm", async () => {
        await assertNoModeChange("\x1B[?44h");
      });
      (0, import_test.test)("Ps = 4 4 - Enable Graphic Print Color Mode (DECGPCM), VT340", async () => {
        await assertNoModeChange("\x1B[?44h");
      });
      (0, import_test.test)("Ps = 4 5 - Reverse-wraparound mode (XTREVWRAP), xterm", async () => {
        await ctx.proxy.write("\x1B[?45h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).reverseWraparoundMode, true);
        await ctx.proxy.resize(5, 2);
        await ctx.proxy.write("\x1B[?7h");
        await ctx.proxy.write("12345X");
        await ctx.proxy.write("\r\bY");
        await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(2), ["1234Y", "X"]);
        await ctx.proxy.resize(80, 24);
      });
      import_test.test.skip("Ps = 4 5 - Enable Graphic Print Color Syntax (DECGPCS), VT340", async () => {
      });
      (0, import_test.test)("Ps = 4 6 - Start logging (XTLOGGING), xterm", async () => {
        await assertNoModeChange("\x1B[?46h");
      });
      (0, import_test.test)("Ps = 4 6 - Graphic Print Background Mode, VT340", async () => {
        await assertNoModeChange("\x1B[?46h");
      });
      (0, import_test.test)("Ps = 4 7 - Use Alternate Screen Buffer, xterm", async () => {
        await ctx.proxy.write("main");
        await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["main"]);
        await ctx.proxy.write("\x1B[?47h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.buffer.active.type, "alternate");
        await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), [""]);
        await ctx.proxy.write("\x1B[Halt");
        await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["alt"]);
        await ctx.proxy.write("\x1B[?47l");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.buffer.active.type, "normal");
        await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["main"]);
      });
      import_test.test.skip("Ps = 4 7 - Enable Graphic Rotated Print Mode (DECGRPM), VT340", async () => {
      });
      (0, import_test.test)("Ps = 6 6 - Application keypad mode (DECNKM), VT320", async () => {
        await ctx.proxy.write("\x1B[?66h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).applicationKeypadMode, true);
      });
      (0, import_test.test)("Ps = 6 7 - Backarrow key sends backspace (DECBKM), VT340, VT420", async () => {
        await assertNoModeChange("\x1B[?67h");
      });
      (0, import_test.test)("Ps = 6 9 - Enable left and right margin mode (DECLRMM), VT420 and up", async () => {
        await assertNoModeChange("\x1B[?69h");
      });
      (0, import_test.test)("Ps = 9 5 - Do not clear screen when DECCOLM is set/reset (DECNCSM), VT510 and up", async () => {
        await assertNoModeChange("\x1B[?95h");
      });
      (0, import_test.test)("Ps = 1 0 0 0 - Send Mouse X & Y on button press and release", async () => {
        const selectionBefore = await dragSelection();
        (0, import_assert.ok)(selectionBefore > 0);
        await ctx.proxy.write("\x1B[?1000h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).mouseTrackingMode, "vt200");
        const selectionAfter = await dragSelection();
        (0, import_assert.ok)(selectionAfter === 0);
      });
      (0, import_test.test)("Ps = 1 0 0 1 - Use Hilite Mouse Tracking, xterm", async () => {
        await assertNoModeChange("\x1B[?1001h");
      });
      (0, import_test.test)("Ps = 1 0 0 2 - Use Cell Motion Mouse Tracking, xterm", async () => {
        const selectionBefore = await dragSelection();
        (0, import_assert.ok)(selectionBefore > 0);
        await ctx.proxy.write("\x1B[?1002h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).mouseTrackingMode, "drag");
        const selectionAfter = await dragSelection();
        (0, import_assert.ok)(selectionAfter === 0);
      });
      (0, import_test.test)("Ps = 1 0 0 3 - Set Use All Motion (any event) Mouse Tracking", async () => {
        const coords = await ctx.page.evaluate(`
          (function() {
            const rect = window.term.element.getBoundingClientRect();
            return { left: rect.left, top: rect.top, bottom: rect.bottom, right: rect.right };
          })();
        `);
        await ctx.page.mouse.click((coords.left + coords.right) / 2, (coords.top + coords.bottom) / 2);
        await ctx.page.mouse.down();
        await ctx.page.mouse.move((coords.left + coords.right) / 2, (coords.top + coords.bottom) / 4);
        (0, import_assert.ok)((await ctx.proxy.getSelection()).length > 0, "mouse events are off so there should be a selection");
        await ctx.page.mouse.up();
        await ctx.page.mouse.click((coords.left + coords.right) / 2, (coords.top + coords.bottom) / 2);
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.getSelection()).length, 0);
        await ctx.proxy.write("\x1B[?1003h");
        await ctx.page.mouse.click((coords.left + coords.right) / 2, (coords.top + coords.bottom) / 2);
        await ctx.page.mouse.down();
        await ctx.page.mouse.move((coords.left + coords.right) / 2, (coords.top + coords.bottom) / 4);
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.getSelection()).length, 0);
        await ctx.page.mouse.up();
      });
      (0, import_test.test)("Ps = 1 0 0 4 - Send FocusIn/FocusOut events, xterm", async () => {
        await ctx.proxy.write("\x1B[?1004h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).sendFocusMode, true);
        await ctx.proxy.blur();
        recordedData.length = 0;
        await ctx.proxy.focus();
        await ctx.proxy.blur();
        await (0, import_TestUtils.pollFor)(ctx.page, () => recordedData, ["\x1B[I", "\x1B[O"]);
      });
      (0, import_test.test)("Ps = 1 0 0 5 - Enable UTF-8 Mouse Mode, xterm", async () => {
        await ctx.proxy.write("\x1B[?1006h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.core.evaluate(([core]) => core.coreMouseService.activeEncoding), "SGR");
        await ctx.proxy.write("\x1B[?1005h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.core.evaluate(([core]) => core.coreMouseService.activeEncoding), "SGR");
      });
      (0, import_test.test)("Ps = 1 0 0 6 - Enable SGR Mouse Mode, xterm", async () => {
        await ctx.proxy.write("\x1B[?1006h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.core.evaluate(([core]) => core.coreMouseService.activeEncoding), "SGR");
      });
      (0, import_test.test)("Ps = 1 0 0 7 - Enable Alternate Scroll Mode, xterm", async () => {
        await assertNoModeChange("\x1B[?1007h");
      });
      (0, import_test.test)("Ps = 1 0 1 0 - Scroll to bottom on tty output (rxvt)", async () => {
        await assertNoModeChange("\x1B[?1010h");
      });
      (0, import_test.test)("Ps = 1 0 1 1 - Scroll to bottom on key press (rxvt)", async () => {
        await assertNoModeChange("\x1B[?1011h");
      });
      (0, import_test.test)("Ps = 1 0 1 5 - Enable urxvt Mouse Mode", async () => {
        await ctx.proxy.write("\x1B[?1006h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.core.evaluate(([core]) => core.coreMouseService.activeEncoding), "SGR");
        await ctx.proxy.write("\x1B[?1015h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.core.evaluate(([core]) => core.coreMouseService.activeEncoding), "SGR");
      });
      (0, import_test.test)("Ps = 1 0 1 6 - Enable SGR Mouse PixelMode, xterm", async () => {
        await ctx.proxy.write("\x1B[?1016h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.core.evaluate(([core]) => core.coreMouseService.activeEncoding), "SGR_PIXELS");
      });
      (0, import_test.test)('Ps = 1 0 3 4 - Interpret "meta" key, xterm', async () => {
        await assertNoModeChange("\x1B[?1034h");
      });
      (0, import_test.test)("Ps = 1 0 3 5 - Enable special modifiers for Alt and NumLock keys, xterm", async () => {
        await assertNoModeChange("\x1B[?1035h");
      });
      (0, import_test.test)("Ps = 1 0 3 6 - Send ESC   when Meta modifies a key, xterm", async () => {
        await assertNoModeChange("\x1B[?1036h");
      });
      (0, import_test.test)("Ps = 1 0 3 7 - Send DEL from the editing-keypad Delete key, xterm", async () => {
        await assertNoModeChange("\x1B[?1037h");
      });
      (0, import_test.test)("Ps = 1 0 3 9 - Send ESC  when Alt modifies a key, xterm", async () => {
        await assertNoModeChange("\x1B[?1039h");
      });
      (0, import_test.test)("Ps = 1 0 4 0 - Keep selection even if not highlighted, xterm", async () => {
        await assertNoModeChange("\x1B[?1040h");
      });
      (0, import_test.test)("Ps = 1 0 4 1 - Use the CLIPBOARD selection, xterm", async () => {
        await assertNoModeChange("\x1B[?1041h");
      });
      (0, import_test.test)("Ps = 1 0 4 2 - Enable Urgency window manager hint when Control-G is received, xterm", async () => {
        await assertNoModeChange("\x1B[?1042h");
      });
      (0, import_test.test)("Ps = 1 0 4 3 - Enable raising of the window when Control-G is received, xterm", async () => {
        await assertNoModeChange("\x1B[?1043h");
      });
      (0, import_test.test)("Ps = 1 0 4 4 - Reuse the most recent data copied to CLIPBOARD, xterm", async () => {
        await assertNoModeChange("\x1B[?1044h");
      });
      (0, import_test.test)("Ps = 1 0 4 5 - XTREVWRAP2: Extended Reverse-wraparound mode, xterm", async () => {
        await assertNoModeChange("\x1B[?1045h");
      });
      (0, import_test.test)("Ps = 1 0 4 6 - Enable switching to/from Alternate Screen Buffer, xterm", async () => {
        await assertNoModeChange("\x1B[?1046h");
      });
      (0, import_test.test)("Ps = 1 0 4 7 - Use Alternate Screen Buffer, xterm", async () => {
        await ctx.proxy.write("main");
        await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["main"]);
        await ctx.proxy.write("\x1B[?1047h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.buffer.active.type, "alternate");
        await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), [""]);
        await ctx.proxy.write("\x1B[Halt");
        await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["alt"]);
        await ctx.proxy.write("\x1B[?1047l");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.buffer.active.type, "normal");
        await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["main"]);
      });
      (0, import_test.test)("Ps = 1 0 4 8 - Save cursor as in DECSC, xterm", async () => {
        await ctx.proxy.write("\x1B[4;5H");
        await ctx.proxy.write("\x1B[?1048h");
        await ctx.proxy.write("\x1B[1;1H");
        await ctx.proxy.write("\x1B[?1048l");
        await (0, import_TestUtils.pollFor)(ctx.page, () => getCursor(), { col: 4, row: 3 });
      });
      (0, import_test.test)("Ps = 1 0 4 9 - Save cursor as in DECSC, xterm", async () => {
        await ctx.proxy.write("main");
        await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["main"]);
        await ctx.proxy.write("\x1B[4;6H");
        await ctx.proxy.write("\x1B[?1049h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.buffer.active.type, "alternate");
        await ctx.proxy.write("\x1B[Halt");
        await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["alt"]);
        await ctx.proxy.write("\x1B[?1049l");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.buffer.active.type, "normal");
        await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["main"]);
        await (0, import_TestUtils.pollFor)(ctx.page, () => getCursor(), { col: 5, row: 3 });
      });
      (0, import_test.test)("Ps = 1 0 5 0 - Set terminfo/termcap function-key mode, xterm", async () => {
        await assertNoModeChange("\x1B[?1050h");
      });
      (0, import_test.test)("Ps = 1 0 5 1 - Set Sun function-key mode, xterm", async () => {
        await assertNoModeChange("\x1B[?1051h");
      });
      (0, import_test.test)("Ps = 1 0 5 2 - Set HP function-key mode, xterm", async () => {
        await assertNoModeChange("\x1B[?1052h");
      });
      (0, import_test.test)("Ps = 1 0 5 3 - Set SCO function-key mode, xterm", async () => {
        await assertNoModeChange("\x1B[?1053h");
      });
      (0, import_test.test)("Ps = 1 0 6 0 - Set legacy keyboard emulation, i.e, X11R6, xterm", async () => {
        await assertNoModeChange("\x1B[?1060h");
      });
      (0, import_test.test)("Ps = 1 0 6 1 - Set VT220 keyboard emulation, xterm", async () => {
        await assertNoModeChange("\x1B[?1061h");
      });
      (0, import_test.test)("Ps = 2 0 0 1 - Enable readline mouse button-1, xterm", async () => {
        await assertNoModeChange("\x1B[?2001h");
      });
      (0, import_test.test)("Ps = 2 0 0 2 - Enable readline mouse button-2, xterm", async () => {
        await assertNoModeChange("\x1B[?2002h");
      });
      (0, import_test.test)("Ps = 2 0 0 3 - Enable readline mouse button-3, xterm", async () => {
        await assertNoModeChange("\x1B[?2003h");
      });
      (0, import_test.test)("Pm = 2 0 0 4, Set bracketed paste mode", async () => {
        if (ctx.browser.browserType().name() !== "chromium") {
          import_test.test.skip();
          return;
        }
        await (0, import_TestUtils.pollFor)(ctx.page, () => simulatePaste("foo"), "foo");
        await ctx.proxy.write("\x1B[?2004h");
        await (0, import_TestUtils.pollFor)(ctx.page, () => simulatePaste("bar"), "\x1B[200~bar\x1B[201~");
        await ctx.proxy.write("\x1B[?2004l");
        await (0, import_TestUtils.pollFor)(ctx.page, () => simulatePaste("baz"), "baz");
      });
      (0, import_test.test)("Ps = 2 0 0 5 - Enable readline character-quoting, xterm", async () => {
        await assertNoModeChange("\x1B[?2005h");
      });
      (0, import_test.test)("Ps = 2 0 0 6 - Enable readline newline pasting, xterm", async () => {
        await assertNoModeChange("\x1B[?2006h");
      });
    });
    import_test.test.skip("CSI Ps i - MC: Media Copy", async () => {
    });
    import_test.test.skip("CSI ? Ps i - MC: Media Copy, DEC-specified", async () => {
    });
    (0, import_test.test)("CSI Pm l - RM: Reset Mode", async () => {
      await ctx.proxy.write("\x1B[4h\x1B[20h");
      await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).insertMode, true);
      await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.getOption("convertEol"), true);
      await ctx.proxy.write("\x1B[4l\x1B[20l");
      await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).insertMode, false);
      await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.getOption("convertEol"), false);
    });
    import_test.test.describe("CSI ? Pm l - DECRST: DEC Private Mode Reset", async () => {
      (0, import_test.test)("Ps = 1 - Normal Cursor Keys (DECCKM), VT100.", async () => {
        await ctx.proxy.write("\x1B[?1h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).applicationCursorKeysMode, true);
        await ctx.proxy.write("\x1B[?1l");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).applicationCursorKeysMode, false);
      });
      (0, import_test.test)("Ps = 2 - Designate VT52 mode (DECANM), VT100.", async () => {
        await assertNoModeChange("\x1B[?2l");
      });
      (0, import_test.test)("Ps = 3 - 80 Column Mode (DECCOLM), VT100.", async () => {
        const windowOptions = await ctx.proxy.getOption("windowOptions");
        await ctx.proxy.setOption("windowOptions", { ...windowOptions, setWinLines: true });
        await ctx.proxy.write("\x1B[?3h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.cols, 132);
        await ctx.proxy.write("\x1B[?3l");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.cols, 80);
        await ctx.proxy.resize(80, 24);
        await ctx.proxy.setOption("windowOptions", windowOptions);
      });
      (0, import_test.test)("Ps = 4 - Jump (Fast) Scroll (DECSCLM), VT100.", async () => {
        await assertNoModeChange("\x1B[?4l");
      });
      (0, import_test.test)("Ps = 5 - Normal Video (DECSCNM), VT100.", async () => {
        await assertNoModeChange("\x1B[?5l");
      });
      (0, import_test.test)("Ps = 6 - Normal Cursor Mode (DECOM), VT100.", async () => {
        await ctx.proxy.write("\x1B[?6h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).originMode, true);
        await ctx.proxy.write("\x1B[?6l");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).originMode, false);
      });
      (0, import_test.test)("Ps = 7 - No Auto-Wrap Mode (DECAWM), VT100.", async () => {
        await ctx.proxy.resize(5, 2);
        await ctx.proxy.write("\x1B[?7h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).wraparoundMode, true);
        await ctx.proxy.write("\x1B[?7l");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).wraparoundMode, false);
        await ctx.proxy.write("12345X");
        await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["1234X"]);
        await ctx.proxy.write("\x1B[?7h");
        await ctx.proxy.reset();
        await ctx.proxy.write("\x1B[?7h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).wraparoundMode, true);
        await ctx.proxy.write("12345X");
        await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(2), ["12345", "X"]);
        await ctx.proxy.resize(80, 24);
      });
      (0, import_test.test)("Ps = 8 - No Auto-Repeat Keys (DECARM), VT100.", async () => {
        await assertNoModeChange("\x1B[?8l");
      });
      (0, import_test.test)("Ps = 9 - Don't send Mouse X & Y on button press, xterm.", async () => {
        await ctx.proxy.write("\x1B[?9h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).mouseTrackingMode, "x10");
        await ctx.proxy.write("\x1B[?9l");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).mouseTrackingMode, "none");
      });
      (0, import_test.test)("Ps = 1 0 - Hide toolbar (rxvt).", async () => {
        await assertNoModeChange("\x1B[?10l");
      });
      (0, import_test.test)("Ps = 1 2 - Stop blinking cursor (AT&T 610).", async () => {
        const previousQuirks = await ctx.proxy.getOption("quirks");
        const previousCursorBlink = await ctx.proxy.getOption("cursorBlink");
        await ctx.proxy.setOption("quirks", { ...previousQuirks ?? {}, allowSetCursorBlink: true });
        await ctx.proxy.setOption("cursorBlink", true);
        await ctx.proxy.write("\x1B[?12l");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.getOption("cursorBlink"), false);
        await ctx.proxy.setOption("quirks", previousQuirks);
        await ctx.proxy.setOption("cursorBlink", previousCursorBlink);
      });
      (0, import_test.test)("Ps = 1 3 - Disable blinking cursor (reset only via resource or menu).", async () => {
        await assertNoModeChange("\x1B[?13l");
      });
      (0, import_test.test)("Ps = 1 4 - Disable XOR of blinking cursor control sequence and menu.", async () => {
        await assertNoModeChange("\x1B[?14l");
      });
      (0, import_test.test)("Ps = 1 8 - Don't Print Form Feed (DECPFF), VT220.", async () => {
        await assertNoModeChange("\x1B[?18l");
      });
      (0, import_test.test)("Ps = 1 9 - Limit print to scrolling region (DECPEX), VT220.", async () => {
        await assertNoModeChange("\x1B[?19l");
      });
      (0, import_test.test)("Ps = 2 5 - Hide cursor (DECTCEM), VT220.", async () => {
        await ctx.proxy.write("\x1B[?25h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).showCursor, true);
        await ctx.proxy.write("\x1B[?25l");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).showCursor, false);
      });
      (0, import_test.test)("Ps = 3 0 - Don't show scrollbar (rxvt).", async () => {
        await assertNoModeChange("\x1B[?30l");
      });
      (0, import_test.test)("Ps = 3 5 - Disable font-shifting functions (rxvt).", async () => {
        await assertNoModeChange("\x1B[?35l");
      });
      (0, import_test.test)("Ps = 4 0 - Disallow 80 \u21D2  132 mode, xterm.", async () => {
        await assertNoModeChange("\x1B[?40l");
      });
      (0, import_test.test)("Ps = 4 1 - No more(1) fix (see curses resource).", async () => {
        await assertNoModeChange("\x1B[?41l");
      });
      (0, import_test.test)("Ps = 4 2 - Disable National Replacement Character sets (DECNRCM), VT220.", async () => {
        await assertNoModeChange("\x1B[?42l");
      });
      (0, import_test.test)("Ps = 4 3 - Disable Graphic Expanded Print Mode (DECGEPM), VT340.", async () => {
        await assertNoModeChange("\x1B[?43l");
      });
      (0, import_test.test)("Ps = 4 4 - Turn off margin bell, xterm.", async () => {
        await assertNoModeChange("\x1B[?44l");
      });
      (0, import_test.test)("Ps = 4 4 - Disable Graphic Print Color Mode (DECGPCM), VT340.", async () => {
        await assertNoModeChange("\x1B[?44l");
      });
      (0, import_test.test)("Ps = 4 5 - No Reverse-wraparound mode (XTREVWRAP), xterm.", async () => {
        await ctx.proxy.write("\x1B[?45h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).reverseWraparoundMode, true);
        await ctx.proxy.write("\x1B[?45l");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).reverseWraparoundMode, false);
      });
      import_test.test.skip("Ps = 4 5 - Disable Graphic Print Color Syntax (DECGPCS), VT340.", async () => {
      });
      (0, import_test.test)("Ps = 4 6 - Stop logging (XTLOGGING), xterm.  This is normally disabled by a compile-time option.", async () => {
        await assertNoModeChange("\x1B[?46l");
      });
      (0, import_test.test)("Ps = 4 7 - Use Normal Screen Buffer, xterm.", async () => {
        await ctx.proxy.write("\x1B[?47h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.buffer.active.type, "alternate");
        await ctx.proxy.write("\x1B[?47l");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.buffer.active.type, "normal");
      });
      import_test.test.skip("Ps = 4 7 - Disable Graphic Rotated Print Mode (DECGRPM), VT340.", async () => {
      });
      (0, import_test.test)("Ps = 6 6 - Numeric keypad mode (DECNKM), VT320.", async () => {
        await ctx.proxy.write("\x1B[?66h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).applicationKeypadMode, true);
        await ctx.proxy.write("\x1B[?66l");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).applicationKeypadMode, false);
      });
      (0, import_test.test)('Ps = 6 7 - Backarrow key sends delete (DECBKM), VT340, VT420.  This sets the backarrowKey resource to "false".', async () => {
        await assertNoModeChange("\x1B[?67l");
      });
      (0, import_test.test)("Ps = 6 9 - Disable left and right margin mode (DECLRMM), VT420 and up.", async () => {
        await assertNoModeChange("\x1B[?69l");
      });
      (0, import_test.test)("Ps = 9 5 - Clear screen when DECCOLM is set/reset (DECNCSM), VT510 and up.", async () => {
        await assertNoModeChange("\x1B[?95l");
      });
      (0, import_test.test)("Ps = 1 0 0 0 - Don't send Mouse X & Y on button press and release.  See the section Mouse Tracking.", async () => {
        await ctx.proxy.write("\x1B[?1000h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).mouseTrackingMode, "vt200");
        await ctx.proxy.write("\x1B[?1000l");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).mouseTrackingMode, "none");
      });
      (0, import_test.test)("Ps = 1 0 0 1 - Don't use Hilite Mouse Tracking, xterm.", async () => {
        await assertNoModeChange("\x1B[?1001l");
      });
      (0, import_test.test)("Ps = 1 0 0 2 - Don't use Cell Motion Mouse Tracking, xterm.  See the section Button-event tracking.", async () => {
        await ctx.proxy.write("\x1B[?1002h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).mouseTrackingMode, "drag");
        await ctx.proxy.write("\x1B[?1002l");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).mouseTrackingMode, "none");
      });
      (0, import_test.test)("Ps = 1 0 0 3 - Don't use All Motion Mouse Tracking, xterm. See the section Any-event tracking.", async () => {
        await ctx.proxy.write("\x1B[?1003h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).mouseTrackingMode, "any");
        await ctx.proxy.write("\x1B[?1003l");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).mouseTrackingMode, "none");
      });
      (0, import_test.test)("Ps = 1 0 0 4 - Don't send FocusIn/FocusOut events, xterm.", async () => {
        await ctx.proxy.write("\x1B[?1004h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).sendFocusMode, true);
        await ctx.proxy.write("\x1B[?1004l");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).sendFocusMode, false);
      });
      (0, import_test.test)("Ps = 1 0 0 5 - Disable UTF-8 Mouse Mode, xterm.", async () => {
        await ctx.proxy.write("\x1B[?1006h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.core.evaluate(([core]) => core.coreMouseService.activeEncoding), "SGR");
        await ctx.proxy.write("\x1B[?1005l");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.core.evaluate(([core]) => core.coreMouseService.activeEncoding), "SGR");
      });
      (0, import_test.test)("Ps = 1 0 0 6 - Disable SGR Mouse Mode, xterm.", async () => {
        await ctx.proxy.write("\x1B[?1006h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.core.evaluate(([core]) => core.coreMouseService.activeEncoding), "SGR");
        await ctx.proxy.write("\x1B[?1006l");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.core.evaluate(([core]) => core.coreMouseService.activeEncoding), "DEFAULT");
      });
      (0, import_test.test)("Ps = 1 0 0 7 - Disable Alternate Scroll Mode, xterm.  This corresponds to the alternateScroll resource.", async () => {
        await assertNoModeChange("\x1B[?1007l");
      });
      (0, import_test.test)(`Ps = 1 0 1 0 - Don't scroll to bottom on tty output (rxvt).  This sets the scrollTtyOutput resource to "false".`, async () => {
        await assertNoModeChange("\x1B[?1010l");
      });
      (0, import_test.test)(`Ps = 1 0 1 1 - Don't scroll to bottom on key press (rxvt). This sets the scrollKey resource to "false".`, async () => {
        await assertNoModeChange("\x1B[?1011l");
      });
      (0, import_test.test)("Ps = 1 0 1 5 - Disable urxvt Mouse Mode.", async () => {
        await ctx.proxy.write("\x1B[?1006h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.core.evaluate(([core]) => core.coreMouseService.activeEncoding), "SGR");
        await ctx.proxy.write("\x1B[?1015l");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.core.evaluate(([core]) => core.coreMouseService.activeEncoding), "SGR");
      });
      (0, import_test.test)("Ps = 1 0 1 6 - Disable SGR Mouse Pixel-Mode, xterm.", async () => {
        await ctx.proxy.write("\x1B[?1016h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.core.evaluate(([core]) => core.coreMouseService.activeEncoding), "SGR_PIXELS");
        await ctx.proxy.write("\x1B[?1016l");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.core.evaluate(([core]) => core.coreMouseService.activeEncoding), "DEFAULT");
      });
      (0, import_test.test)(`Ps = 1 0 3 4 - Don't interpret "meta" key, xterm.  This disables the eightBitInput resource.`, async () => {
        await assertNoModeChange("\x1B[?1034l");
      });
      (0, import_test.test)("Ps = 1 0 3 5 - Disable special modifiers for Alt and NumLock keys, xterm.  This disables the numLock resource.", async () => {
        await assertNoModeChange("\x1B[?1035l");
      });
      (0, import_test.test)("Ps = 1 0 3 6 - Don't send ESC  when Meta modifies a key, xterm.  This disables the metaSendsEscape resource.", async () => {
        await assertNoModeChange("\x1B[?1036l");
      });
      (0, import_test.test)("Ps = 1 0 3 7 - Send VT220 Remove from the editing-keypad Delete key, xterm.", async () => {
        await assertNoModeChange("\x1B[?1037l");
      });
      (0, import_test.test)("Ps = 1 0 3 9 - Don't send ESC when Alt modifies a key, xterm.  This disables the altSendsEscape resource.", async () => {
        await assertNoModeChange("\x1B[?1039l");
      });
      (0, import_test.test)("Ps = 1 0 4 0 - Do not keep selection when not highlighted, xterm.  This disables the keepSelection resource.", async () => {
        await assertNoModeChange("\x1B[?1040l");
      });
      (0, import_test.test)("Ps = 1 0 4 1 - Use the PRIMARY selection, xterm.  This disables the selectToClipboard resource.", async () => {
        await assertNoModeChange("\x1B[?1041l");
      });
      (0, import_test.test)("Ps = 1 0 4 2 - Disable Urgency window manager hint when Control-G is received, xterm.  This disables the bellIsUrgent resource.", async () => {
        await assertNoModeChange("\x1B[?1042l");
      });
      (0, import_test.test)("Ps = 1 0 4 3 - Disable raising of the window when Control- G is received, xterm.  This disables the popOnBell resource.", async () => {
        await assertNoModeChange("\x1B[?1043l");
      });
      (0, import_test.test)("Ps = 1 0 4 5 - No Extended Reverse-wraparound mode (XTREVWRAP2), xterm.", async () => {
        await assertNoModeChange("\x1B[?1045l");
      });
      (0, import_test.test)("Ps = 1 0 4 6 - Disable switching to/from Alternate Screen Buffer, xterm.  This works for terminfo-based systems, updating the titeInhibit resource.  If currently using the Alternate Screen Buffer, xterm switches to the Normal Screen Buffer.", async () => {
        await assertNoModeChange("\x1B[?1046l");
      });
      (0, import_test.test)("Ps = 1 0 4 7 - Use Normal Screen Buffer, xterm.  Clear the screen first if in the Alternate Screen Buffer.  This may be disabled by the titeInhibit resource.", async () => {
        await ctx.proxy.write("\x1B[?1047h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.buffer.active.type, "alternate");
        await ctx.proxy.write("\x1B[?1047l");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.buffer.active.type, "normal");
      });
      (0, import_test.test)("Ps = 1 0 4 8 - Restore cursor as in DECRC, xterm.  This may be disabled by the titeInhibit resource.", async () => {
        await ctx.proxy.write("\x1B[4;6H");
        await ctx.proxy.write("\x1B[?1048h");
        await ctx.proxy.write("\x1B[1;1H");
        await ctx.proxy.write("\x1B[?1048l");
        await (0, import_TestUtils.pollFor)(ctx.page, () => getCursor(), { col: 5, row: 3 });
      });
      (0, import_test.test)("Ps = 1 0 4 9 - Use Normal Screen Buffer and restore cursor as in DECRC, xterm.  This may be disabled by the titeInhibit resource.  This combines the effects of the 1 0 4 7  and 1 0 4 8  modes.  Use this with terminfo-based applications rather than the 4 7  mode.", async () => {
        await ctx.proxy.write("\x1B[3;4H");
        await ctx.proxy.write("\x1B[?1048h");
        await ctx.proxy.write("\x1B[?47h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.buffer.active.type, "alternate");
        await ctx.proxy.write("\x1B[1;1H");
        await ctx.proxy.write("\x1B[?1049l");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => await ctx.proxy.buffer.active.type, "normal");
        await (0, import_TestUtils.pollFor)(ctx.page, () => getCursor(), { col: 3, row: 2 });
      });
      (0, import_test.test)("Ps = 1 0 5 0 - Reset terminfo/termcap function-key mode, xterm.", async () => {
        await assertNoModeChange("\x1B[?1050l");
      });
      (0, import_test.test)("Ps = 1 0 5 1 - Reset Sun function-key mode, xterm.", async () => {
        await assertNoModeChange("\x1B[?1051l");
      });
      (0, import_test.test)("Ps = 1 0 5 2 - Reset HP function-key mode, xterm.", async () => {
        await assertNoModeChange("\x1B[?1052l");
      });
      (0, import_test.test)("Ps = 1 0 5 3 - Reset SCO function-key mode, xterm.", async () => {
        await assertNoModeChange("\x1B[?1053l");
      });
      (0, import_test.test)("Ps = 1 0 6 0 - Reset legacy keyboard emulation, i.e, X11R6, xterm.", async () => {
        await assertNoModeChange("\x1B[?1060l");
      });
      (0, import_test.test)("Ps = 1 0 6 1 - Reset keyboard emulation to Sun/PC style, xterm.", async () => {
        await assertNoModeChange("\x1B[?1061l");
      });
      (0, import_test.test)("Ps = 2 0 0 1 - Disable readline mouse button-1, xterm.", async () => {
        await assertNoModeChange("\x1B[?2001l");
      });
      (0, import_test.test)("Ps = 2 0 0 2 - Disable readline mouse button-2, xterm.", async () => {
        await assertNoModeChange("\x1B[?2002l");
      });
      (0, import_test.test)("Ps = 2 0 0 3 - Disable readline mouse button-3, xterm.", async () => {
        await assertNoModeChange("\x1B[?2003l");
      });
      (0, import_test.test)("Ps = 2 0 0 4 - Reset bracketed paste mode, xterm.", async () => {
        await ctx.proxy.write("\x1B[?2004h");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).bracketedPasteMode, true);
        await ctx.proxy.write("\x1B[?2004l");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).bracketedPasteMode, false);
      });
      (0, import_test.test)("Ps = 2 0 0 5 - Disable readline character-quoting, xterm.", async () => {
        await assertNoModeChange("\x1B[?2005l");
      });
      (0, import_test.test)("Ps = 2 0 0 6 - Disable readline newline pasting, xterm.", async () => {
        await assertNoModeChange("\x1B[?2006l");
      });
    });
    import_test.test.describe("CSI Pm m - SGR: Character Attributes", () => {
      (0, import_test.test)("Ps = 0 - Normal (default), VT100", async () => {
        await ctx.proxy.write("\x1B[1;3;4;5;7;8;9m#\x1B[0m@");
        const cell0 = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.ok)(await cell0.isBold());
        (0, import_assert.ok)(await cell0.isItalic());
        (0, import_assert.ok)(await cell0.isUnderline());
        (0, import_assert.ok)(await cell0.isBlink());
        (0, import_assert.ok)(await cell0.isInverse());
        (0, import_assert.ok)(await cell0.isInvisible());
        (0, import_assert.ok)(await cell0.isStrikethrough());
        const cell1 = await (await ctx.proxy.buffer.active.getLine(0)).getCell(1);
        (0, import_assert.deepStrictEqual)(await cell1.isAttributeDefault(), true);
      });
      (0, import_test.test)("Ps = 1 - Bold, VT100", async () => {
        await ctx.proxy.write("\x1B[1m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.ok)(await cell.isBold());
      });
      (0, import_test.test)("Ps = 2 - Faint, decreased intensity, ECMA-48 2nd", async () => {
        await ctx.proxy.write("\x1B[2m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.ok)(await cell.isDim());
      });
      (0, import_test.test)("Ps = 3 - Italicized, ECMA-48 2nd", async () => {
        await ctx.proxy.write("\x1B[3m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.ok)(await cell.isItalic());
      });
      (0, import_test.test)("Ps = 4 - Underlined, VT100", async () => {
        await ctx.proxy.write("\x1B[4m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.ok)(await cell.isUnderline());
      });
      (0, import_test.test)("Ps = 5 - Blink, VT100", async () => {
        await ctx.proxy.write("\x1B[5m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.ok)(await cell.isBlink());
      });
      (0, import_test.test)("Ps = 7 - Inverse, VT100", async () => {
        await ctx.proxy.write("\x1B[7m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.ok)(await cell.isInverse());
      });
      (0, import_test.test)("Ps = 8 - Invisible, ECMA-48 2nd, VT300", async () => {
        await ctx.proxy.write("\x1B[8m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.ok)(await cell.isInvisible());
      });
      (0, import_test.test)("Ps = 9 - Crossed-out characters, ECMA-48 3rd", async () => {
        await ctx.proxy.write("\x1B[9m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.ok)(await cell.isStrikethrough());
      });
      (0, import_test.test)("Ps = 21 - Doubly-underlined, ECMA-48 3rd", async () => {
        await ctx.proxy.write("\x1B[21m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.ok)(await cell.isUnderline());
      });
      (0, import_test.test)("Ps = 22 - Normal (neither bold nor faint), ECMA-48 3rd", async () => {
        await ctx.proxy.write("\x1B[1;2m#\x1B[22m@");
        const cell0 = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.ok)(await cell0.isBold());
        (0, import_assert.ok)(await cell0.isDim());
        const cell1 = await (await ctx.proxy.buffer.active.getLine(0)).getCell(1);
        (0, import_assert.deepStrictEqual)(await cell1.isBold(), 0);
        (0, import_assert.deepStrictEqual)(await cell1.isDim(), 0);
      });
      (0, import_test.test)("Ps = 23 - Not italicized, ECMA-48 3rd", async () => {
        await ctx.proxy.write("\x1B[3m#\x1B[23m@");
        const cell0 = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.ok)(await cell0.isItalic());
        const cell1 = await (await ctx.proxy.buffer.active.getLine(0)).getCell(1);
        (0, import_assert.deepStrictEqual)(await cell1.isItalic(), 0);
      });
      (0, import_test.test)("Ps = 24 - Not underlined, ECMA-48 3rd", async () => {
        await ctx.proxy.write("\x1B[4m#\x1B[24m@");
        const cell0 = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.ok)(await cell0.isUnderline());
        const cell1 = await (await ctx.proxy.buffer.active.getLine(0)).getCell(1);
        (0, import_assert.deepStrictEqual)(await cell1.isUnderline(), 0);
      });
      (0, import_test.test)("Ps = 25 - Steady (not blinking), ECMA-48 3rd", async () => {
        await ctx.proxy.write("\x1B[5m#\x1B[25m@");
        const cell0 = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.ok)(await cell0.isBlink());
        const cell1 = await (await ctx.proxy.buffer.active.getLine(0)).getCell(1);
        (0, import_assert.deepStrictEqual)(await cell1.isBlink(), 0);
      });
      (0, import_test.test)("Ps = 27 - Positive (not inverse), ECMA-48 3rd", async () => {
        await ctx.proxy.write("\x1B[7m#\x1B[27m@");
        const cell0 = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.ok)(await cell0.isInverse());
        const cell1 = await (await ctx.proxy.buffer.active.getLine(0)).getCell(1);
        (0, import_assert.deepStrictEqual)(await cell1.isInverse(), 0);
      });
      (0, import_test.test)("Ps = 28 - Visible, ECMA-48 3rd, VT300", async () => {
        await ctx.proxy.write("\x1B[8m#\x1B[28m@");
        const cell0 = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.ok)(await cell0.isInvisible());
        const cell1 = await (await ctx.proxy.buffer.active.getLine(0)).getCell(1);
        (0, import_assert.deepStrictEqual)(await cell1.isInvisible(), 0);
      });
      (0, import_test.test)("Ps = 29 - Not crossed-out, ECMA-48 3rd", async () => {
        await ctx.proxy.write("\x1B[9m#\x1B[29m@");
        const cell0 = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.ok)(await cell0.isStrikethrough());
        const cell1 = await (await ctx.proxy.buffer.active.getLine(0)).getCell(1);
        (0, import_assert.deepStrictEqual)(await cell1.isStrikethrough(), 0);
      });
      (0, import_test.test)("Ps = 30 - Set foreground color to Black", async () => {
        await ctx.proxy.write("\x1B[30m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isFgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getFgColor(), 0);
      });
      (0, import_test.test)("Ps = 31 - Set foreground color to Red", async () => {
        await ctx.proxy.write("\x1B[31m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isFgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getFgColor(), 1);
      });
      (0, import_test.test)("Ps = 32 - Set foreground color to Green", async () => {
        await ctx.proxy.write("\x1B[32m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isFgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getFgColor(), 2);
      });
      (0, import_test.test)("Ps = 33 - Set foreground color to Yellow", async () => {
        await ctx.proxy.write("\x1B[33m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isFgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getFgColor(), 3);
      });
      (0, import_test.test)("Ps = 34 - Set foreground color to Blue", async () => {
        await ctx.proxy.write("\x1B[34m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isFgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getFgColor(), 4);
      });
      (0, import_test.test)("Ps = 35 - Set foreground color to Magenta", async () => {
        await ctx.proxy.write("\x1B[35m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isFgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getFgColor(), 5);
      });
      (0, import_test.test)("Ps = 36 - Set foreground color to Cyan", async () => {
        await ctx.proxy.write("\x1B[36m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isFgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getFgColor(), 6);
      });
      (0, import_test.test)("Ps = 37 - Set foreground color to White", async () => {
        await ctx.proxy.write("\x1B[37m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isFgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getFgColor(), 7);
      });
      (0, import_test.test)("Ps = 39 - Set foreground color to default, ECMA-48 3rd", async () => {
        await ctx.proxy.write("\x1B[31m#\x1B[39m@");
        const cell0 = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell0.isFgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell0.getFgColor(), 1);
        const cell1 = await (await ctx.proxy.buffer.active.getLine(0)).getCell(1);
        (0, import_assert.deepStrictEqual)(await cell1.isFgDefault(), true);
      });
      (0, import_test.test)("Ps = 40 - Set background color to Black", async () => {
        await ctx.proxy.write("\x1B[40m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isBgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getBgColor(), 0);
      });
      (0, import_test.test)("Ps = 41 - Set background color to Red", async () => {
        await ctx.proxy.write("\x1B[41m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isBgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getBgColor(), 1);
      });
      (0, import_test.test)("Ps = 42 - Set background color to Green", async () => {
        await ctx.proxy.write("\x1B[42m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isBgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getBgColor(), 2);
      });
      (0, import_test.test)("Ps = 43 - Set background color to Yellow", async () => {
        await ctx.proxy.write("\x1B[43m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isBgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getBgColor(), 3);
      });
      (0, import_test.test)("Ps = 44 - Set background color to Blue", async () => {
        await ctx.proxy.write("\x1B[44m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isBgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getBgColor(), 4);
      });
      (0, import_test.test)("Ps = 45 - Set background color to Magenta", async () => {
        await ctx.proxy.write("\x1B[45m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isBgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getBgColor(), 5);
      });
      (0, import_test.test)("Ps = 46 - Set background color to Cyan", async () => {
        await ctx.proxy.write("\x1B[46m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isBgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getBgColor(), 6);
      });
      (0, import_test.test)("Ps = 47 - Set background color to White", async () => {
        await ctx.proxy.write("\x1B[47m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isBgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getBgColor(), 7);
      });
      (0, import_test.test)("Ps = 49 - Set background color to default, ECMA-48 3rd", async () => {
        await ctx.proxy.write("\x1B[41m#\x1B[49m@");
        const cell0 = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell0.isBgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell0.getBgColor(), 1);
        const cell1 = await (await ctx.proxy.buffer.active.getLine(0)).getCell(1);
        (0, import_assert.deepStrictEqual)(await cell1.isBgDefault(), true);
      });
      (0, import_test.test)("Ps = 90 - Set foreground color to bright Black", async () => {
        await ctx.proxy.write("\x1B[90m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isFgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getFgColor(), 8);
      });
      (0, import_test.test)("Ps = 91 - Set foreground color to bright Red", async () => {
        await ctx.proxy.write("\x1B[91m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isFgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getFgColor(), 9);
      });
      (0, import_test.test)("Ps = 92 - Set foreground color to bright Green", async () => {
        await ctx.proxy.write("\x1B[92m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isFgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getFgColor(), 10);
      });
      (0, import_test.test)("Ps = 93 - Set foreground color to bright Yellow", async () => {
        await ctx.proxy.write("\x1B[93m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isFgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getFgColor(), 11);
      });
      (0, import_test.test)("Ps = 94 - Set foreground color to bright Blue", async () => {
        await ctx.proxy.write("\x1B[94m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isFgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getFgColor(), 12);
      });
      (0, import_test.test)("Ps = 95 - Set foreground color to bright Magenta", async () => {
        await ctx.proxy.write("\x1B[95m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isFgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getFgColor(), 13);
      });
      (0, import_test.test)("Ps = 96 - Set foreground color to bright Cyan", async () => {
        await ctx.proxy.write("\x1B[96m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isFgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getFgColor(), 14);
      });
      (0, import_test.test)("Ps = 97 - Set foreground color to bright White", async () => {
        await ctx.proxy.write("\x1B[97m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isFgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getFgColor(), 15);
      });
      (0, import_test.test)("Ps = 100 - Set background color to bright Black", async () => {
        await ctx.proxy.write("\x1B[100m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isBgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getBgColor(), 8);
      });
      (0, import_test.test)("Ps = 101 - Set background color to bright Red", async () => {
        await ctx.proxy.write("\x1B[101m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isBgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getBgColor(), 9);
      });
      (0, import_test.test)("Ps = 102 - Set background color to bright Green", async () => {
        await ctx.proxy.write("\x1B[102m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isBgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getBgColor(), 10);
      });
      (0, import_test.test)("Ps = 103 - Set background color to bright Yellow", async () => {
        await ctx.proxy.write("\x1B[103m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isBgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getBgColor(), 11);
      });
      (0, import_test.test)("Ps = 104 - Set background color to bright Blue", async () => {
        await ctx.proxy.write("\x1B[104m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isBgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getBgColor(), 12);
      });
      (0, import_test.test)("Ps = 105 - Set background color to bright Magenta", async () => {
        await ctx.proxy.write("\x1B[105m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isBgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getBgColor(), 13);
      });
      (0, import_test.test)("Ps = 106 - Set background color to bright Cyan", async () => {
        await ctx.proxy.write("\x1B[106m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isBgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getBgColor(), 14);
      });
      (0, import_test.test)("Ps = 107 - Set background color to bright White", async () => {
        await ctx.proxy.write("\x1B[107m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isBgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getBgColor(), 15);
      });
      (0, import_test.test)("Ps = 38:2:Pi:Pr:Pg:Pb - Set foreground color using RGB values (colon separator)", async () => {
        await ctx.proxy.write("\x1B[38:2::171:205:239m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isFgRGB(), true);
        (0, import_assert.deepStrictEqual)(await cell.getFgColor(), 11259375);
      });
      (0, import_test.test)("Ps = 38:5:Ps - Set foreground color to Ps using indexed color (colon separator)", async () => {
        await ctx.proxy.write("\x1B[38:5:123m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isFgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getFgColor(), 123);
      });
      (0, import_test.test)("Ps = 48:2:Pi:Pr:Pg:Pb - Set background color using RGB values (colon separator)", async () => {
        await ctx.proxy.write("\x1B[48:2::18:52:86m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isBgRGB(), true);
        (0, import_assert.deepStrictEqual)(await cell.getBgColor(), 1193046);
      });
      (0, import_test.test)("Ps = 48:5:Ps - Set background color to Ps using indexed color (colon separator)", async () => {
        await ctx.proxy.write("\x1B[48:5:200m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isBgPalette(), true);
        (0, import_assert.deepStrictEqual)(await cell.getBgColor(), 200);
      });
      (0, import_test.test)("Ps = 38;2;Pr;Pg;Pb - Set foreground color using RGB values (semicolon separator)", async () => {
        await ctx.proxy.write("\x1B[38;2;171;205;239m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isFgRGB(), true);
        (0, import_assert.deepStrictEqual)(await cell.getFgColor(), 11259375);
      });
      (0, import_test.test)("Ps = 48;2;Pr;Pg;Pb - Set background color using RGB values (semicolon separator)", async () => {
        await ctx.proxy.write("\x1B[48;2;18;52;86m#");
        const cell = await (await ctx.proxy.buffer.active.getLine(0)).getCell(0);
        (0, import_assert.deepStrictEqual)(await cell.isBgRGB(), true);
        (0, import_assert.deepStrictEqual)(await cell.getBgColor(), 1193046);
      });
    });
    import_test.test.skip("CSI > Pp [; Pv] m - XTMODKEYS: Set/reset key modifier options, xterm", () => {
    });
    import_test.test.skip("CSI ? Pp m - XTQMODKEYS: Query key modifier options, xterm", () => {
    });
    import_test.test.describe("CSI Ps n - DSR: Device Status Report", () => {
      (0, import_test.test)("Status Report - CSI 5 n", async () => {
        await ctx.proxy.write("\x1B[5n");
        (0, import_assert.deepStrictEqual)(recordedData, ["\x1B[0n"]);
      });
      (0, import_test.test)("Report Cursor Position (CPR) - CSI 6 n", async () => {
        await ctx.proxy.write("\n\nfoo");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => [
          await ctx.proxy.buffer.active.cursorY,
          await ctx.proxy.buffer.active.cursorX
        ], [2, 3]);
        await ctx.proxy.write("\x1B[6n");
        (0, import_assert.deepStrictEqual)(recordedData, ["\x1B[3;4R"]);
      });
      (0, import_test.test)("Report Cursor Position (DECXCPR) - CSI ? 6 n", async () => {
        await ctx.proxy.write("\n\nfoo");
        await (0, import_TestUtils.pollFor)(ctx.page, async () => [
          await ctx.proxy.buffer.active.cursorY,
          await ctx.proxy.buffer.active.cursorX
        ], [2, 3]);
        await ctx.proxy.write("\x1B[?6n");
        (0, import_assert.deepStrictEqual)(recordedData, ["\x1B[?3;4R"]);
      });
    });
    import_test.test.skip("CSI > Ps n - Disable key modifier options, xterm", () => {
    });
    import_test.test.describe("CSI ? Ps n - DECDSR: Device Status Report (DEC-specific)", () => {
      (0, import_test.test)("Color Scheme Query - CSI ? 996 n (dark theme)", async () => {
        await ctx.proxy.write("\x1B[?996n");
        (0, import_assert.deepStrictEqual)(recordedData, ["\x1B[?997;1n"]);
      });
      (0, import_test.test)("Color Scheme Query - CSI ? 996 n (light theme)", async () => {
        recordedData.length = 0;
        await ctx.page.evaluate(`window.term.options.theme = { background: '#ffffff', foreground: '#000000' }`);
        await ctx.proxy.write("\x1B[?996n");
        (0, import_assert.deepStrictEqual)(recordedData, ["\x1B[?997;2n"]);
        await ctx.page.evaluate(`window.term.options.theme = { background: '#000000', foreground: '#ffffff' }`);
      });
      (0, import_test.test)("Color Scheme Query disabled via vtExtensions.colorSchemeQuery", async () => {
        recordedData.length = 0;
        await ctx.page.evaluate(`window.term.options.vtExtensions = { colorSchemeQuery: false }`);
        await ctx.proxy.write("\x1B[?996n");
        (0, import_assert.deepStrictEqual)(recordedData, []);
        await ctx.page.evaluate(`window.term.options.vtExtensions = { colorSchemeQuery: true }`);
      });
    });
    import_test.test.skip("CSI > Ps p - XTSMPOINTER: Set resource value pointerMode, xterm", () => {
    });
    (0, import_test.test)("CSI ! p - DECSTR: Soft terminal reset, VT220 and up.", async () => {
      const rows = await ctx.proxy.rows;
      await ctx.proxy.write("\x1B[4h\x1B[?6h\x1B[3;5r");
      await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).insertMode, true);
      await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).originMode, true);
      await ctx.proxy.write("\x1B[!p");
      await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).insertMode, false);
      await (0, import_TestUtils.pollFor)(ctx.page, async () => (await ctx.proxy.modes).originMode, false);
      await (0, import_TestUtils.pollFor)(ctx.page, () => ctx.page.evaluate(`({ top: window.term._core._bufferService.buffer.scrollTop, bottom: window.term._core._bufferService.buffer.scrollBottom })`), { top: 0, bottom: rows - 1 });
    });
    import_test.test.skip('CSI Pl ; Pc " p - DECSCL: Set conformance level, VT220 and up.', () => {
    });
    (0, import_test.test)("CSI Ps $ p - DECRQM: Request ANSI mode", async () => {
      await ctx.proxy.write("\x1B[4h");
      recordedData.length = 0;
      await ctx.proxy.write("\x1B[4$p");
      (0, import_assert.deepStrictEqual)(recordedData, ["\x1B[4;1$y"]);
      await ctx.proxy.write("\x1B[4l");
      recordedData.length = 0;
      await ctx.proxy.write("\x1B[4$p");
      (0, import_assert.deepStrictEqual)(recordedData, ["\x1B[4;2$y"]);
      await ctx.proxy.write("\x1B[20h");
      recordedData.length = 0;
      await ctx.proxy.write("\x1B[20$p");
      (0, import_assert.deepStrictEqual)(recordedData, ["\x1B[20;1$y"]);
      await ctx.proxy.write("\x1B[20l");
    });
    (0, import_test.test)("CSI ? Ps $ p - Request DEC private mode (DECRQM).", async () => {
      await ctx.proxy.write("\x1B[?1h");
      recordedData.length = 0;
      await ctx.proxy.write("\x1B[?1$p");
      (0, import_assert.deepStrictEqual)(recordedData, ["\x1B[?1;1$y"]);
      await ctx.proxy.write("\x1B[?1l");
      recordedData.length = 0;
      await ctx.proxy.write("\x1B[?1$p");
      (0, import_assert.deepStrictEqual)(recordedData, ["\x1B[?1;2$y"]);
    });
    import_test.test.skip("CSI [Pm] # p - Push video attributes onto stack (XTPUSHSGR), xterm.  This is an alias for CSI # { , used to work around language limitations of C#.", async () => {
    });
    (0, import_test.test)("CSI > Ps q - Report xterm name and version (XTVERSION).", async () => {
      await ctx.proxy.write("\x1B[>q");
      (0, import_assert.ok)(recordedData.length === 1);
      (0, import_assert.ok)(recordedData[0].startsWith("\x1BP>|xterm.js("));
      (0, import_assert.ok)(recordedData[0].endsWith("\x1B\\"));
    });
    import_test.test.skip("CSI Ps q - Load LEDs (DECLL), VT100.", async () => {
    });
    (0, import_test.test)("CSI Ps SP q - Set cursor style (DECSCUSR), VT520.", async () => {
      const getCursorMode = async () => ctx.proxy.core.evaluate(([core]) => {
        const modes = core.coreService.decPrivateModes;
        return { style: modes.cursorStyle, blink: modes.cursorBlink };
      });
      await ctx.proxy.write("\x1B[1 q");
      (0, import_assert.deepStrictEqual)(await getCursorMode(), { style: "block", blink: true });
      await ctx.proxy.write("\x1B[2 q");
      (0, import_assert.deepStrictEqual)(await getCursorMode(), { style: "block", blink: false });
      await ctx.proxy.write("\x1B[3 q");
      (0, import_assert.deepStrictEqual)(await getCursorMode(), { style: "underline", blink: true });
      await ctx.proxy.write("\x1B[4 q");
      (0, import_assert.deepStrictEqual)(await getCursorMode(), { style: "underline", blink: false });
      await ctx.proxy.write("\x1B[5 q");
      (0, import_assert.deepStrictEqual)(await getCursorMode(), { style: "bar", blink: true });
      await ctx.proxy.write("\x1B[6 q");
      (0, import_assert.deepStrictEqual)(await getCursorMode(), { style: "bar", blink: false });
      await ctx.proxy.write("\x1B[0 q");
      (0, import_assert.deepStrictEqual)(await getCursorMode(), { style: void 0, blink: void 0 });
    });
    (0, import_test.test)('CSI Ps " q - Select character protection attribute (DECSCA), VT220.', async () => {
      await ctx.proxy.write('\x1B[1"q');
      await ctx.proxy.write("PROT");
      await ctx.proxy.write('\x1B[2"q');
      await ctx.proxy.write("open");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["PROTopen"]);
      await ctx.proxy.write("\x1B[1;1H\x1B[?2K");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(1), ["PROT"]);
    });
    import_test.test.skip("CSI # q - Pop video attributes from stack (XTPOPSGR), xterm.", async () => {
    });
    (0, import_test.test)("CSI Ps ; Ps r - Set Scrolling Region [top;bottom] (default = full size of window) (DECSTBM), VT100.", async () => {
      const rows = await ctx.proxy.rows;
      await ctx.proxy.write("\x1B[2;4r");
      await (0, import_TestUtils.pollFor)(ctx.page, () => ctx.page.evaluate(`({ top: window.term._core._bufferService.buffer.scrollTop, bottom: window.term._core._bufferService.buffer.scrollBottom })`), { top: 1, bottom: 3 });
      await ctx.proxy.write("\x1B[r");
      await (0, import_TestUtils.pollFor)(ctx.page, () => ctx.page.evaluate(`({ top: window.term._core._bufferService.buffer.scrollTop, bottom: window.term._core._bufferService.buffer.scrollBottom })`), { top: 0, bottom: rows - 1 });
    });
    import_test.test.skip("CSI ? Pm r - Restore DEC Private Mode Values (XTRESTORE), xterm.", async () => {
    });
    import_test.test.skip("CSI Pt ; Pl ; Pb ; Pr ; Pm $ r - Change Attributes in Rectangular Area (DECCARA), VT400 and up.", async () => {
    });
    (0, import_test.test)("CSI s - Save cursor, available only when DECLRMM is disabled (SCOSC, also ANSI.SYS).", async () => {
      await ctx.proxy.write("\x1B[3;4H");
      await ctx.proxy.write("\x1B[s");
      await ctx.proxy.write("\x1B[1;1H");
      await ctx.proxy.write("\x1B[u");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getCursor(), { col: 3, row: 2 });
    });
    import_test.test.skip("CSI Pl ; Pr s - Set left and right margins (DECSLRM), VT420 and up.", async () => {
    });
    import_test.test.skip("CSI > Ps s - Set/reset shift-escape options (XTSHIFTESCAPE), xterm.", async () => {
    });
    import_test.test.skip("CSI ? Pm s - Save DEC Private Mode Values (XTSAVE), xterm.  Ps values are the same as for DECSET.", async () => {
    });
    import_test.test.skip("CSI > Pm t - This xterm control sets one or more features of the title modes (XTSMTITLE), xterm.", async () => {
    });
    import_test.test.skip("CSI Ps SP t - Set warning-bell volume (DECSWBV), VT520.", async () => {
    });
    import_test.test.skip("CSI Pt ; Pl ; Pb ; Pr ; Pm $ t - Reverse Attributes in Rectangular Area (DECRARA), VT400 and up.", async () => {
    });
    (0, import_test.test)("CSI u - Restore cursor (SCORC, also ANSI.SYS).", async () => {
      await ctx.proxy.write("\x1B[4;6H");
      await ctx.proxy.write("\x1B[s");
      await ctx.proxy.write("\x1B[1;1H");
      await ctx.proxy.write("\x1B[u");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getCursor(), { col: 5, row: 3 });
    });
    import_test.test.skip("CSI Ps SP u - Set margin-bell volume (DECSMBV), VT520.", async () => {
    });
    import_test.test.skip("CSI Pt ; Pl ; Pb ; Pr ; Pp ; Pt ; Pl ; Pp $ v - Copy Rectangular Area (DECCRA), VT400 and up.", async () => {
    });
    import_test.test.skip("CSI Ps $ w - Request presentation state report (DECRQPSR), VT320 and up.", async () => {
    });
    import_test.test.skip("CSI Pt ; Pl ; Pb ; Pr ' w - Enable Filter Rectangle (DECEFR), VT420 and up.", async () => {
    });
    import_test.test.skip("CSI Ps x - Request Terminal Parameters (DECREQTPARM).", async () => {
    });
    import_test.test.skip("CSI Ps * x - Select Attribute Change Extent (DECSACE), VT420 and up.", async () => {
    });
    import_test.test.skip("CSI Pc ; Pt ; Pl ; Pb ; Pr $ x - Fill Rectangular Area (DECFRA), VT420 and up.", async () => {
    });
    import_test.test.skip("CSI Ps # y - Select checksum extension (XTCHECKSUM), xterm.", async () => {
    });
    import_test.test.skip("CSI Pi ; Pg ; Pt ; Pl ; Pb ; Pr * y - Request Checksum of Rectangular Area (DECRQCRA), VT420 and up.", async () => {
    });
    import_test.test.skip("CSI Ps ; Pu ' z - Enable Locator Reporting (DECELR).", async () => {
    });
    import_test.test.skip("CSI Pt ; Pl ; Pb ; Pr $ z - Erase Rectangular Area (DECERA), VT400 and up.", async () => {
    });
    import_test.test.skip("CSI Pm ' { - Select Locator Events (DECSLE).", async () => {
    });
    import_test.test.skip("CSI [Pm] # { Push video attributes onto stack (XTPUSHSGR), xterm.", async () => {
    });
    import_test.test.skip("CSI Pt ; Pl ; Pb ; Pr $ { - Selective Erase Rectangular Area (DECSERA), VT400 and up.", async () => {
    });
    import_test.test.skip("CSI Pt ; Pl ; Pb ; Pr # | - Report selected graphic rendition (XTREPORTSGR), xterm.", async () => {
    });
    import_test.test.skip("CSI Ps $ | - Select columns per page (DECSCPP), VT340.", async () => {
    });
    import_test.test.skip("CSI Ps ' | - Request Locator Position (DECRQLP).", async () => {
    });
    import_test.test.skip("CSI Ps * | - Select number of lines per screen (DECSNLS), VT420 and up.", async () => {
    });
    import_test.test.skip("CSI # } - Pop video attributes from stack (XTPOPSGR), xterm.", async () => {
    });
    (0, import_test.test)("CSI Ps ' } - Insert Ps Column(s) (default = 1) (DECIC), VT420 and up.", async () => {
      await ctx.proxy.resize(5, 5);
      await ctx.proxy.write("12345".repeat(6));
      await ctx.proxy.write("\x1B[3;3H");
      await ctx.proxy.write("\x1B['}");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(6), ["12345", "12 34", "12 34", "12 34", "12 34", "12 34"]);
    });
    import_test.test.skip("CSI Ps $ } - Select active status display (DECSASD), VT320 and up.", async () => {
    });
    (0, import_test.test)("CSI Ps ' ~ - Delete Ps Column(s) (default = 1) (DECDC), VT420 and up.", async () => {
      await ctx.proxy.resize(5, 5);
      await ctx.proxy.write("12345".repeat(6));
      await ctx.proxy.write("\x1B[3;3H");
      await ctx.proxy.write("\x1B['~");
      await (0, import_TestUtils.pollFor)(ctx.page, () => getLinesAsArray(6), ["12345", "1245", "1245", "1245", "1245", "1245"]);
    });
    import_test.test.skip("CSI Ps $ ~ - Select status line type (DECSSDT), VT320 and up.", async () => {
    });
    import_test.test.describe("CSI Ps ; Ps ; Ps t - Window Options", () => {
      (0, import_test.test)("should be disabled by default", async () => {
        await ctx.proxy.write("\x1B[14t");
        await ctx.proxy.write("\x1B[16t");
        await ctx.proxy.write("\x1B[18t");
        await ctx.proxy.write("\x1B[20t");
        await ctx.proxy.write("\x1B[21t");
        (0, import_assert.deepStrictEqual)(recordedData, []);
      });
      (0, import_test.test)("14 - GetWinSizePixels", async () => {
        await ctx.proxy.setOption("windowOptions", { getWinSizePixels: true });
        await ctx.proxy.write("\x1B[14t");
        const d = await getDimensions();
        (0, import_assert.deepStrictEqual)(recordedData, [`\x1B[4;${d.height};${d.width}t`]);
      });
      (0, import_test.test)("16 - GetCellSizePixels", async () => {
        await ctx.proxy.setOption("windowOptions", { getCellSizePixels: true });
        await ctx.proxy.write("\x1B[16t");
        const d = await getDimensions();
        (0, import_assert.deepStrictEqual)(recordedData, [`\x1B[6;${d.cellHeight};${d.cellWidth}t`]);
      });
    });
  });
  import_test.test.describe("OSC", () => {
    import_test.test.describe("OSC 4", () => {
      (0, import_test.test)("query single color", async () => {
        await ctx.proxy.write("\x1B]4;0;?\x07");
        (0, import_assert.deepStrictEqual)(recordedData, ["\x1B]4;0;rgb:2e2e/3434/3636\x1B\\"]);
        await ctx.proxy.write("\x1B]4;77;?\x07");
        (0, import_assert.deepStrictEqual)(recordedData, ["\x1B]4;0;rgb:2e2e/3434/3636\x1B\\", "\x1B]4;77;rgb:5f5f/d7d7/5f5f\x1B\\"]);
      });
      (0, import_test.test)("query multiple colors", async () => {
        await ctx.proxy.write("\x1B]4;0;?;77;?\x07");
        (0, import_assert.deepStrictEqual)(recordedData, ["\x1B]4;0;rgb:2e2e/3434/3636\x1B\\", "\x1B]4;77;rgb:5f5f/d7d7/5f5f\x1B\\"]);
      });
      (0, import_test.test)("set & query single color", async () => {
        await ctx.proxy.write("\x1B]4;0;?\x07");
        const restore = [...recordedData];
        (0, import_assert.deepStrictEqual)(recordedData, restore);
        await ctx.proxy.write("\x1B]4;0;rgb:01/02/03\x07\x1B]4;0;?\x07");
        (0, import_assert.deepStrictEqual)(recordedData, [restore[0], "\x1B]4;0;rgb:0101/0202/0303\x1B\\"]);
        await ctx.proxy.write(restore[0] + "\x1B]4;0;?\x07");
        (0, import_assert.deepStrictEqual)(recordedData, [restore[0], "\x1B]4;0;rgb:0101/0202/0303\x1B\\", restore[0]]);
      });
      (0, import_test.test)("query & set colors mixed", async () => {
        await ctx.proxy.write("\x1B]4;0;?;77;?\x07");
        const restore = [...recordedData];
        recordedData.length = 0;
        await ctx.proxy.write("\x1B]4;0;rgb:01/02/03;43;?;77;#aabbcc\x07");
        (0, import_assert.deepStrictEqual)(recordedData, ["\x1B]4;43;rgb:0000/d7d7/afaf\x1B\\"]);
        recordedData.length = 0;
        await ctx.proxy.write("\x1B]4;0;?;77;?\x07");
        (0, import_assert.deepStrictEqual)(recordedData, ["\x1B]4;0;rgb:0101/0202/0303\x1B\\", "\x1B]4;77;rgb:aaaa/bbbb/cccc\x1B\\"]);
        recordedData.length = 0;
        await ctx.proxy.write(restore[0] + restore[1] + "\x1B]4;0;?;77;?\x07");
        (0, import_assert.deepStrictEqual)(recordedData, restore);
      });
    });
    import_test.test.describe("OSC 4 & 104", () => {
      (0, import_test.test)("change & restore single color", async () => {
        for (const i of [0, 43, 77, 255]) {
          await ctx.proxy.write(`\x1B]4;${i};?\x07`);
          const restore = [...recordedData];
          await ctx.proxy.write(`\x1B]4;${i};rgb:01/02/03\x07\x1B]4;${i};?\x07`);
          (0, import_assert.deepStrictEqual)(recordedData, [restore[0], `\x1B]4;${i};rgb:0101/0202/0303\x1B\\`]);
          await ctx.proxy.write(`\x1B]104;${i}\x07\x1B]4;${i};?\x07`);
          (0, import_assert.deepStrictEqual)(recordedData, [restore[0], `\x1B]4;${i};rgb:0101/0202/0303\x1B\\`, restore[0]]);
          recordedData.length = 0;
        }
      });
      (0, import_test.test)("restore multiple at once", async () => {
        await ctx.proxy.write(`\x1B]4;0;?;43;?;77;?\x07`);
        const restore = [...recordedData];
        recordedData.length = 0;
        await ctx.proxy.write(`\x1B]4;0;rgb:01/02/03;43;#aabbcc;77;#123456\x07`);
        await ctx.proxy.write(`\x1B]104;0;43;77\x07\x1B]4;0;?;43;?;77;?\x07`);
        (0, import_assert.deepStrictEqual)(recordedData, restore);
      });
      (0, import_test.test)("restore full table", async () => {
        await ctx.proxy.write(`\x1B]4;0;?;43;?;77;?\x07`);
        const restore = [...recordedData];
        recordedData.length = 0;
        await ctx.proxy.write(`\x1B]4;0;rgb:01/02/03;43;#aabbcc;77;#123456\x07`);
        await ctx.proxy.write(`\x1B]104\x07\x1B]4;0;?;43;?;77;?\x07`);
        (0, import_assert.deepStrictEqual)(recordedData, restore);
      });
    });
    import_test.test.describe("OSC 10 & 11 + 110 | 111 | 112", () => {
      (0, import_test.test)("query FG color", async () => {
        await ctx.proxy.write("\x1B]10;?\x07");
        (0, import_assert.deepStrictEqual)(recordedData, ["\x1B]10;rgb:ffff/ffff/ffff\x1B\\"]);
      });
      (0, import_test.test)("query BG color", async () => {
        await ctx.proxy.write("\x1B]11;?\x07");
        (0, import_assert.deepStrictEqual)(recordedData, ["\x1B]11;rgb:0000/0000/0000\x1B\\"]);
      });
      (0, import_test.test)("query FG & BG color in one call", async () => {
        await ctx.proxy.write("\x1B]10;?;?\x07");
        (0, import_assert.deepStrictEqual)(recordedData, ["\x1B]10;rgb:ffff/ffff/ffff\x1B\\", "\x1B]11;rgb:0000/0000/0000\x1B\\"]);
      });
      (0, import_test.test)("set & query FG", async () => {
        await ctx.proxy.write("\x1B]10;rgb:1/2/3\x07\x1B]10;?\x07");
        (0, import_assert.deepStrictEqual)(recordedData, ["\x1B]10;rgb:1111/2222/3333\x1B\\"]);
        await ctx.proxy.write("\x1B]10;#ffffff\x07\x1B]10;?\x07");
        (0, import_assert.deepStrictEqual)(recordedData, ["\x1B]10;rgb:1111/2222/3333\x1B\\", "\x1B]10;rgb:ffff/ffff/ffff\x1B\\"]);
      });
      (0, import_test.test)("set & query BG", async () => {
        await ctx.proxy.write("\x1B]11;rgb:1/2/3\x07\x1B]11;?\x07");
        (0, import_assert.deepStrictEqual)(recordedData, ["\x1B]11;rgb:1111/2222/3333\x1B\\"]);
        await ctx.proxy.write("\x1B]11;#000000\x07\x1B]11;?\x07");
        (0, import_assert.deepStrictEqual)(recordedData, ["\x1B]11;rgb:1111/2222/3333\x1B\\", "\x1B]11;rgb:0000/0000/0000\x1B\\"]);
      });
      (0, import_test.test)("set & query cursor color", async () => {
        await ctx.proxy.write("\x1B]12;rgb:1/2/3\x07\x1B]12;?\x07");
        (0, import_assert.deepStrictEqual)(recordedData, ["\x1B]12;rgb:1111/2222/3333\x1B\\"]);
        await ctx.proxy.write("\x1B]12;#ffffff\x07\x1B]12;?\x07");
        (0, import_assert.deepStrictEqual)(recordedData, ["\x1B]12;rgb:1111/2222/3333\x1B\\", "\x1B]12;rgb:ffff/ffff/ffff\x1B\\"]);
      });
      (0, import_test.test)("set & query FG & BG color in one call", async () => {
        await ctx.proxy.write("\x1B]10;#123456;rgb:aa/bb/cc\x07\x1B]10;?;?\x07");
        (0, import_assert.deepStrictEqual)(recordedData, ["\x1B]10;rgb:1212/3434/5656\x1B\\", "\x1B]11;rgb:aaaa/bbbb/cccc\x1B\\"]);
        await ctx.proxy.write("\x1B]10;#ffffff;#000000\x07");
      });
      (0, import_test.test)("OSC 110: restore FG color", async () => {
        await ctx.proxy.write("\x1B]10;rgb:1/2/3\x07\x1B]10;?\x07");
        (0, import_assert.deepStrictEqual)(recordedData, ["\x1B]10;rgb:1111/2222/3333\x1B\\"]);
        recordedData.length = 0;
        await ctx.proxy.write("\x1B]110\x07\x1B]10;?\x07");
        (0, import_assert.deepStrictEqual)(recordedData, ["\x1B]10;rgb:ffff/ffff/ffff\x1B\\"]);
      });
      (0, import_test.test)("OSC 111: restore BG color", async () => {
        await ctx.proxy.write("\x1B]11;rgb:1/2/3\x07\x1B]11;?\x07");
        (0, import_assert.deepStrictEqual)(recordedData, ["\x1B]11;rgb:1111/2222/3333\x1B\\"]);
        recordedData.length = 0;
        await ctx.proxy.write("\x1B]111\x07\x1B]11;?\x07");
        (0, import_assert.deepStrictEqual)(recordedData, ["\x1B]11;rgb:0000/0000/0000\x1B\\"]);
      });
      (0, import_test.test)("OSC 112: restore cursor color", async () => {
        await ctx.proxy.write("\x1B]12;rgb:1/2/3\x07\x1B]12;?\x07");
        (0, import_assert.deepStrictEqual)(recordedData, ["\x1B]12;rgb:1111/2222/3333\x1B\\"]);
        recordedData.length = 0;
        await ctx.proxy.write("\x1B]112\x07\x1B]12;?\x07");
        (0, import_assert.deepStrictEqual)(recordedData, ["\x1B]12;rgb:ffff/ffff/ffff\x1B\\"]);
      });
    });
  });
  import_test.test.describe("ESC", () => {
    import_test.test.describe("DECRC: Save cursor, ESC 7", () => {
      (0, import_test.test)("should save the absolute cursor position so resizing restores to the correct position", async () => {
        await ctx.proxy.resize(10, 2);
        await ctx.proxy.write("1\n\r2\n\r3\n\r4\n\r5");
        await ctx.proxy.write("\x1B7\x1B[?47h");
        await ctx.proxy.resize(10, 4);
        await ctx.proxy.write("\x1B[?47l\x1B8");
        await (0, import_TestUtils.pollFor)(ctx.page, () => getCursor(), { col: 1, row: 3 });
      });
    });
  });
});
async function getModeSnapshot() {
  return {
    modes: await ctx.proxy.modes,
    cursorBlink: await ctx.proxy.getOption("cursorBlink"),
    cols: await ctx.proxy.cols,
    rows: await ctx.proxy.rows,
    bufferType: await ctx.proxy.buffer.active.type,
    mouseProtocol: await ctx.proxy.core.evaluate(([core]) => core.coreMouseService.activeProtocol),
    mouseEncoding: await ctx.proxy.core.evaluate(([core]) => core.coreMouseService.activeEncoding)
  };
}
async function assertNoModeChange(sequence) {
  const before = await getModeSnapshot();
  await ctx.proxy.write(sequence);
  (0, import_assert.deepStrictEqual)(await getModeSnapshot(), before);
}
async function getLinesAsArray(count, start = 0) {
  let text = "";
  for (let i = start; i < start + count; i++) {
    text += `window.term.buffer.active.getLine(${i}).translateToString(true),`;
  }
  return await ctx.page.evaluate(`[${text}]`);
}
async function simulatePaste(text) {
  const id = Math.floor(Math.random() * 1e6);
  await ctx.page.evaluate(`
    (function() {
      window.disposable_${id} = window.term.onData(e => window.result_${id} = e);
      const clipboardData = new DataTransfer();
      clipboardData.setData('text/plain', '${text}');
      window.term.textarea.dispatchEvent(new ClipboardEvent('paste', { clipboardData }));
    })();
  `);
  const result = await ctx.page.evaluate(`window.result_${id}`);
  await ctx.page.evaluate(`window.disposable_${id}.dispose()`);
  return result;
}
async function dragSelection() {
  await ctx.proxy.clearSelection();
  const coords = await ctx.page.evaluate(`
    (function() {
      const rect = window.term.element.getBoundingClientRect();
      return { left: rect.left, top: rect.top, bottom: rect.bottom, right: rect.right };
    })();
  `);
  await ctx.page.mouse.click((coords.left + coords.right) / 2, (coords.top + coords.bottom) / 2);
  await ctx.page.mouse.down();
  await ctx.page.mouse.move((coords.left + coords.right) / 2, (coords.top + coords.bottom) / 4);
  await ctx.page.mouse.up();
  return (await ctx.proxy.getSelection()).length;
}
async function getCursor() {
  return {
    col: await ctx.proxy.buffer.active.cursorX,
    row: await ctx.proxy.buffer.active.cursorY
  };
}
async function getDimensions() {
  const dim = await ctx.proxy.dimensions;
  return {
    cellWidth: dim.css.cell.width.toFixed(0),
    cellHeight: dim.css.cell.height.toFixed(0),
    width: dim.css.canvas.width.toFixed(0),
    height: dim.css.canvas.height.toFixed(0)
  };
}
//# sourceMappingURL=InputHandler.test.js.map
