var import_xterm_benchmark = require("xterm-benchmark");
var import_Event = require("common/Event");
/**
 * Copyright (c) 2026 The xterm.js authors. All rights reserved.
 * @license MIT
 */
const ITERATIONS = 1e6;
(0, import_xterm_benchmark.perfContext)("Emitter.fire()", () => {
  (0, import_xterm_benchmark.perfContext)("0 listeners", () => {
    let emitter;
    (0, import_xterm_benchmark.before)(() => {
      emitter = new import_Event.Emitter();
    });
    new import_xterm_benchmark.RuntimeCase("", () => {
      for (let i = 0; i < ITERATIONS; i++) {
        emitter.fire(i);
      }
      return { payloadSize: ITERATIONS };
    }, { fork: false }).showAverageRuntime();
  });
  (0, import_xterm_benchmark.perfContext)("1 listener", () => {
    let emitter;
    let sum = 0;
    (0, import_xterm_benchmark.before)(() => {
      emitter = new import_Event.Emitter();
      emitter.event((e) => {
        sum += e;
      });
    });
    new import_xterm_benchmark.RuntimeCase("", () => {
      for (let i = 0; i < ITERATIONS; i++) {
        emitter.fire(i);
      }
      return { payloadSize: ITERATIONS, sum };
    }, { fork: false }).showAverageRuntime();
  });
  (0, import_xterm_benchmark.perfContext)("2 listeners", () => {
    let emitter;
    let sum = 0;
    (0, import_xterm_benchmark.before)(() => {
      emitter = new import_Event.Emitter();
      emitter.event((e) => {
        sum += e;
      });
      emitter.event((e) => {
        sum += e * 2;
      });
    });
    new import_xterm_benchmark.RuntimeCase("", () => {
      for (let i = 0; i < ITERATIONS; i++) {
        emitter.fire(i);
      }
      return { payloadSize: ITERATIONS, sum };
    }, { fork: false }).showAverageRuntime();
  });
  (0, import_xterm_benchmark.perfContext)("5 listeners", () => {
    let emitter;
    let sum = 0;
    (0, import_xterm_benchmark.before)(() => {
      emitter = new import_Event.Emitter();
      for (let j = 0; j < 5; j++) {
        emitter.event((e) => {
          sum += e;
        });
      }
    });
    new import_xterm_benchmark.RuntimeCase("", () => {
      for (let i = 0; i < ITERATIONS; i++) {
        emitter.fire(i);
      }
      return { payloadSize: ITERATIONS, sum };
    }, { fork: false }).showAverageRuntime();
  });
});
//# sourceMappingURL=Event.benchmark.js.map
