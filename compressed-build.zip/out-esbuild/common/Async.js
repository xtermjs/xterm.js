"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var Async_exports = {};
__export(Async_exports, {
  IntervalTimer: () => IntervalTimer,
  TimeoutTimer: () => TimeoutTimer,
  disposableTimeout: () => disposableTimeout,
  timeout: () => timeout
});
module.exports = __toCommonJS(Async_exports);
var import_Lifecycle = require("common/Lifecycle");
/**
 * Copyright (c) 2026 The xterm.js authors. All rights reserved.
 * @license MIT
 *
 * Minimal async helpers for xterm.js core.
 */
function timeout(millis) {
  return new Promise((resolve) => setTimeout(resolve, millis));
}
function disposableTimeout(handler, timeout2 = 0, store) {
  const timer = setTimeout(() => {
    handler();
    if (store) {
      disposable.dispose();
    }
  }, timeout2);
  const disposable = (0, import_Lifecycle.toDisposable)(() => {
    clearTimeout(timer);
  });
  store?.add(disposable);
  return disposable;
}
class TimeoutTimer {
  constructor() {
    this._token = -1;
    this._isDisposed = false;
  }
  dispose() {
    this.cancel();
    this._isDisposed = true;
  }
  cancel() {
    if (this._token !== -1) {
      clearTimeout(this._token);
      this._token = -1;
    }
  }
  cancelAndSet(runner, timeout2) {
    if (this._isDisposed) {
      throw new Error("Calling cancelAndSet on a disposed TimeoutTimer");
    }
    this.cancel();
    this._token = setTimeout(() => {
      this._token = -1;
      runner();
    }, timeout2);
  }
  setIfNotSet(runner, timeout2) {
    if (this._isDisposed) {
      throw new Error("Calling setIfNotSet on a disposed TimeoutTimer");
    }
    if (this._token !== -1) {
      return;
    }
    this._token = setTimeout(() => {
      this._token = -1;
      runner();
    }, timeout2);
  }
}
class IntervalTimer {
  constructor() {
    this._isDisposed = false;
  }
  cancel() {
    this._disposable?.dispose();
    this._disposable = void 0;
  }
  cancelAndSet(runner, interval, context = globalThis) {
    if (this._isDisposed) {
      throw new Error("Calling cancelAndSet on a disposed IntervalTimer");
    }
    this.cancel();
    const handle = context.setInterval(() => {
      runner();
    }, interval);
    this._disposable = {
      dispose: () => {
        context.clearInterval(handle);
        this._disposable = void 0;
      }
    };
  }
  dispose() {
    this.cancel();
    this._isDisposed = true;
  }
}
//# sourceMappingURL=Async.js.map
