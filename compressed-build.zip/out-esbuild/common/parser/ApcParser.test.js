"use strict";
var import_chai = require("chai");
var import_ApcParser = require("common/parser/ApcParser");
var import_TextDecoder = require("common/input/TextDecoder");
/**
 * Copyright (c) 2025 The xterm.js authors. All rights reserved.
 * @license MIT
 */
function toUtf32(s) {
  const utf32 = new Uint32Array(s.length);
  const decoder = new import_TextDecoder.StringToUtf32();
  const length = decoder.decode(s, utf32);
  return utf32.subarray(0, length);
}
class TestHandler {
  constructor(id, output, msg, returnFalse = false) {
    this.id = id;
    this.output = output;
    this.msg = msg;
    this.returnFalse = returnFalse;
  }
  start() {
    this.output.push([this.msg, this.id, "START"]);
  }
  put(data, start, end) {
    this.output.push([this.msg, this.id, "PUT", (0, import_TextDecoder.utf32ToString)(data, start, end)]);
  }
  end(success) {
    this.output.push([this.msg, this.id, "END", success]);
    if (this.returnFalse) {
      return false;
    }
    return true;
  }
}
describe("ApcParser", () => {
  let parser;
  let reports = [];
  beforeEach(() => {
    reports = [];
    parser = new import_ApcParser.ApcParser();
    parser.setHandlerFallback((id, action, data) => {
      reports.push([id, action, data]);
    });
  });
  describe("identifier parsing", () => {
    it("single character identifier", () => {
      parser.start();
      const data = toUtf32("Gf=100,a=T;payload");
      parser.put(data, 0, data.length);
      parser.end(true);
      import_chai.assert.deepEqual(reports, [
        [71, "START", void 0],
        // 0x47 = 'G'
        [71, "PUT", "f=100,a=T;payload"],
        [71, "END", true]
      ]);
    });
    it("identifier with no payload", () => {
      parser.start();
      const data = toUtf32("G");
      parser.put(data, 0, data.length);
      parser.end(true);
      import_chai.assert.deepEqual(reports, [
        [71, "START", void 0],
        [71, "END", true]
      ]);
    });
    it("identifier with chunked payload", () => {
      parser.start();
      let data = toUtf32("Gf=100");
      parser.put(data, 0, data.length);
      data = toUtf32(",a=T");
      parser.put(data, 0, data.length);
      data = toUtf32(";payload");
      parser.put(data, 0, data.length);
      parser.end(true);
      import_chai.assert.deepEqual(reports, [
        [71, "START", void 0],
        [71, "PUT", "f=100"],
        [71, "PUT", ",a=T"],
        [71, "PUT", ";payload"],
        [71, "END", true]
      ]);
    });
    it("empty APC sequence", () => {
      parser.start();
      parser.end(true);
      import_chai.assert.deepEqual(reports, []);
    });
  });
  describe("handler registration", () => {
    let handlerReports;
    beforeEach(() => {
      handlerReports = [];
    });
    it("registerHandler for specific identifier", () => {
      const G_CODE = 71;
      parser.registerHandler(G_CODE, new TestHandler(G_CODE, handlerReports, "kitty"));
      parser.start();
      const data = toUtf32("Gf=100,a=T;imagedata");
      parser.put(data, 0, data.length);
      parser.end(true);
      import_chai.assert.deepEqual(handlerReports, [
        ["kitty", G_CODE, "START"],
        ["kitty", G_CODE, "PUT", "f=100,a=T;imagedata"],
        ["kitty", G_CODE, "END", true]
      ]);
      import_chai.assert.deepEqual(reports, []);
    });
    it("unregistered identifier falls back", () => {
      const G_CODE = 71;
      const X_CODE = 88;
      parser.registerHandler(G_CODE, new TestHandler(G_CODE, handlerReports, "kitty"));
      parser.start();
      const data = toUtf32("Xsome data");
      parser.put(data, 0, data.length);
      parser.end(true);
      import_chai.assert.deepEqual(handlerReports, []);
      import_chai.assert.deepEqual(reports, [
        [X_CODE, "START", void 0],
        [X_CODE, "PUT", "some data"],
        [X_CODE, "END", true]
      ]);
    });
    it("clearHandler removes handler", () => {
      const G_CODE = 71;
      parser.registerHandler(G_CODE, new TestHandler(G_CODE, handlerReports, "kitty"));
      parser.clearHandler(G_CODE);
      parser.start();
      const data = toUtf32("Gf=100");
      parser.put(data, 0, data.length);
      parser.end(true);
      import_chai.assert.deepEqual(handlerReports, []);
      import_chai.assert.deepEqual(reports, [
        [G_CODE, "START", void 0],
        [G_CODE, "PUT", "f=100"],
        [G_CODE, "END", true]
      ]);
    });
    it("multiple handlers for same identifier", () => {
      const G_CODE = 71;
      parser.registerHandler(G_CODE, new TestHandler(G_CODE, handlerReports, "handler1"));
      parser.registerHandler(G_CODE, new TestHandler(G_CODE, handlerReports, "handler2"));
      parser.start();
      const data = toUtf32("Gdata");
      parser.put(data, 0, data.length);
      parser.end(true);
      import_chai.assert.deepEqual(handlerReports, [
        ["handler2", G_CODE, "START"],
        ["handler1", G_CODE, "START"],
        ["handler2", G_CODE, "PUT", "data"],
        ["handler1", G_CODE, "PUT", "data"],
        ["handler2", G_CODE, "END", true],
        ["handler1", G_CODE, "END", false]
      ]);
    });
    it("handler returning false allows fallthrough", () => {
      const G_CODE = 71;
      parser.registerHandler(G_CODE, new TestHandler(G_CODE, handlerReports, "handler1"));
      parser.registerHandler(G_CODE, new TestHandler(G_CODE, handlerReports, "handler2", true));
      parser.start();
      const data = toUtf32("Gdata");
      parser.put(data, 0, data.length);
      parser.end(true);
      import_chai.assert.deepEqual(handlerReports, [
        ["handler2", G_CODE, "START"],
        ["handler1", G_CODE, "START"],
        ["handler2", G_CODE, "PUT", "data"],
        ["handler1", G_CODE, "PUT", "data"],
        ["handler2", G_CODE, "END", true],
        ["handler1", G_CODE, "END", true]
      ]);
    });
    it("dispose removes handler", () => {
      const G_CODE = 71;
      parser.registerHandler(G_CODE, new TestHandler(G_CODE, handlerReports, "handler1"));
      const disposable = parser.registerHandler(G_CODE, new TestHandler(G_CODE, handlerReports, "handler2"));
      disposable.dispose();
      parser.start();
      const data = toUtf32("Gdata");
      parser.put(data, 0, data.length);
      parser.end(true);
      import_chai.assert.deepEqual(handlerReports, [
        ["handler1", G_CODE, "START"],
        ["handler1", G_CODE, "PUT", "data"],
        ["handler1", G_CODE, "END", true]
      ]);
    });
  });
  describe("ApcHandler convenience class", () => {
    const TEST_PAYLOAD_LIMIT = 100;
    const CHUNK_SIZE = 10;
    let originalPayloadLimit;
    beforeEach(() => {
      const handlerConstructor = import_ApcParser.ApcHandler;
      originalPayloadLimit = handlerConstructor._payloadLimit;
      handlerConstructor._payloadLimit = TEST_PAYLOAD_LIMIT;
    });
    afterEach(() => {
      const handlerConstructor = import_ApcParser.ApcHandler;
      handlerConstructor._payloadLimit = originalPayloadLimit;
    });
    it("should be called once on end(true)", () => {
      const G_CODE = 71;
      const results = [];
      parser.registerHandler(G_CODE, new import_ApcParser.ApcHandler((data2) => {
        results.push([G_CODE, data2]);
        return true;
      }));
      parser.start();
      let data = toUtf32("Gf=100");
      parser.put(data, 0, data.length);
      data = toUtf32(",a=T;payload");
      parser.put(data, 0, data.length);
      parser.end(true);
      import_chai.assert.deepEqual(results, [[G_CODE, "f=100,a=T;payload"]]);
    });
    it("should not be called on end(false)", () => {
      const G_CODE = 71;
      const results = [];
      parser.registerHandler(G_CODE, new import_ApcParser.ApcHandler((data2) => {
        results.push([G_CODE, data2]);
        return true;
      }));
      parser.start();
      const data = toUtf32("Gf=100,a=T;payload");
      parser.put(data, 0, data.length);
      parser.end(false);
      import_chai.assert.deepEqual(results, []);
    });
    it("should handle payload up to limit", function() {
      this.timeout(3e4);
      const G_CODE = 71;
      const results = [];
      parser.registerHandler(G_CODE, new import_ApcParser.ApcHandler((data2) => {
        results.push([G_CODE, data2]);
        return true;
      }));
      parser.start();
      let data = toUtf32("G");
      parser.put(data, 0, data.length);
      data = toUtf32("A".repeat(CHUNK_SIZE));
      for (let i = 0; i < TEST_PAYLOAD_LIMIT; i += CHUNK_SIZE) {
        parser.put(data, 0, data.length);
      }
      parser.end(true);
      import_chai.assert.deepEqual(results, [[G_CODE, "A".repeat(TEST_PAYLOAD_LIMIT)]]);
    });
    it("should abort for payload over limit", function() {
      this.timeout(3e4);
      const G_CODE = 71;
      const results = [];
      parser.registerHandler(G_CODE, new import_ApcParser.ApcHandler((data2) => {
        results.push([G_CODE, data2]);
        return true;
      }));
      parser.start();
      let data = toUtf32("G");
      parser.put(data, 0, data.length);
      data = toUtf32("A".repeat(CHUNK_SIZE));
      for (let i = 0; i < TEST_PAYLOAD_LIMIT; i += CHUNK_SIZE) {
        parser.put(data, 0, data.length);
      }
      data = toUtf32("A");
      parser.put(data, 0, data.length);
      parser.end(true);
      import_chai.assert.deepEqual(results, []);
    });
  });
  describe("reset behavior", () => {
    let handlerReports;
    beforeEach(() => {
      handlerReports = [];
    });
    it("reset during payload cleans up handlers", () => {
      const G_CODE = 71;
      parser.registerHandler(G_CODE, new TestHandler(G_CODE, handlerReports, "kitty"));
      parser.start();
      const data = toUtf32("Gf=100");
      parser.put(data, 0, data.length);
      parser.reset();
      import_chai.assert.deepEqual(handlerReports, [
        ["kitty", G_CODE, "START"],
        ["kitty", G_CODE, "PUT", "f=100"],
        ["kitty", G_CODE, "END", false]
      ]);
    });
  });
});
describe("ApcParser - async tests", () => {
  let parser;
  let reports = [];
  beforeEach(() => {
    reports = [];
    parser = new import_ApcParser.ApcParser();
    parser.setHandlerFallback((id, action, data) => {
      reports.push([id, action, data]);
    });
  });
  async function endP(parser2, success) {
    let result;
    let prev;
    while (result = parser2.end(success, prev)) {
      prev = await result;
    }
  }
  describe("async ApcHandler", () => {
    it("should handle async handler", async () => {
      const G_CODE = 71;
      const results = [];
      parser.registerHandler(G_CODE, new import_ApcParser.ApcHandler(async (data2) => {
        await new Promise((res) => setTimeout(res, 10));
        results.push([G_CODE, data2]);
        return true;
      }));
      parser.start();
      const data = toUtf32("Gf=100,a=T");
      parser.put(data, 0, data.length);
      await endP(parser, true);
      import_chai.assert.deepEqual(results, [[G_CODE, "f=100,a=T"]]);
    });
  });
});
//# sourceMappingURL=ApcParser.test.js.map
