"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var ApcParser_exports = {};
__export(ApcParser_exports, {
  ApcHandler: () => ApcHandler,
  ApcParser: () => ApcParser
});
module.exports = __toCommonJS(ApcParser_exports);
var import_Constants = require("common/parser/Constants");
var import_TextDecoder = require("common/input/TextDecoder");
/**
 * Copyright (c) 2025 The xterm.js authors. All rights reserved.
 * @license MIT
 */
const EMPTY_HANDLERS = [];
class ApcParser {
  constructor() {
    this._state = import_Constants.ApcState.START;
    this._active = EMPTY_HANDLERS;
    this._id = -1;
    this._handlers = /* @__PURE__ */ Object.create(null);
    this._handlerFb = () => {
    };
    this._stack = {
      paused: false,
      loopPosition: 0,
      fallThrough: false
    };
  }
  /**
   * Register an APC handler for a specific identifier.
   * @param ident The character code of the first byte (e.g., 0x47 for 'G')
   * @param handler The handler to register
   */
  registerHandler(ident, handler) {
    this._handlers[ident] ??= [];
    const handlerList = this._handlers[ident];
    handlerList.push(handler);
    return {
      dispose: () => {
        const handlerIndex = handlerList.indexOf(handler);
        if (handlerIndex !== -1) {
          handlerList.splice(handlerIndex, 1);
        }
      }
    };
  }
  clearHandler(ident) {
    if (this._handlers[ident]) delete this._handlers[ident];
  }
  setHandlerFallback(handler) {
    this._handlerFb = handler;
  }
  dispose() {
    this._handlers = /* @__PURE__ */ Object.create(null);
    this._handlerFb = () => {
    };
    this._active = EMPTY_HANDLERS;
  }
  reset() {
    if (this._state === import_Constants.ApcState.PAYLOAD) {
      for (let j = this._stack.paused ? this._stack.loopPosition - 1 : this._active.length - 1; j >= 0; --j) {
        this._active[j].end(false);
      }
    }
    this._stack.paused = false;
    this._active = EMPTY_HANDLERS;
    this._id = -1;
    this._state = import_Constants.ApcState.START;
  }
  _start() {
    this._active = this._handlers[this._id] || EMPTY_HANDLERS;
    if (!this._active.length) {
      this._handlerFb(this._id, "START");
    } else {
      for (let j = this._active.length - 1; j >= 0; j--) {
        this._active[j].start();
      }
    }
  }
  _put(data, start, end) {
    if (!this._active.length) {
      this._handlerFb(this._id, "PUT", (0, import_TextDecoder.utf32ToString)(data, start, end));
    } else {
      for (let j = this._active.length - 1; j >= 0; j--) {
        this._active[j].put(data, start, end);
      }
    }
  }
  start() {
    this.reset();
    this._state = import_Constants.ApcState.ID;
  }
  /**
   * Put data to current APC command.
   * For APC, the first character is used as the identifier.
   * Format: ESC _ <identifier><payload> ESC \
   * Example: ESC _ G f=100,a=T;... ESC \ (Kitty graphics, identifier='G')
   */
  put(data, start, end) {
    if (this._state === import_Constants.ApcState.ABORT) {
      return;
    }
    if (this._state === import_Constants.ApcState.ID) {
      if (start < end) {
        this._id = data[start++];
        this._state = import_Constants.ApcState.PAYLOAD;
        this._start();
      }
    }
    if (this._state === import_Constants.ApcState.PAYLOAD && end - start > 0) {
      this._put(data, start, end);
    }
  }
  /**
   * Indicates end of an APC command.
   * Whether the APC got aborted or finished normally
   * is indicated by `success`.
   */
  end(success, promiseResult = true) {
    if (this._state === import_Constants.ApcState.START) {
      return;
    }
    if (this._state !== import_Constants.ApcState.ABORT) {
      if (this._state === import_Constants.ApcState.ID) {
        this._active = EMPTY_HANDLERS;
        this._id = -1;
        this._state = import_Constants.ApcState.START;
        return;
      }
      if (!this._active.length) {
        this._handlerFb(this._id, "END", success);
      } else {
        let handlerResult = false;
        let j = this._active.length - 1;
        let fallThrough = false;
        if (this._stack.paused) {
          j = this._stack.loopPosition - 1;
          handlerResult = promiseResult;
          fallThrough = this._stack.fallThrough;
          this._stack.paused = false;
        }
        if (!fallThrough && handlerResult === false) {
          for (; j >= 0; j--) {
            handlerResult = this._active[j].end(success);
            if (handlerResult === true) {
              break;
            } else if (handlerResult instanceof Promise) {
              this._stack.paused = true;
              this._stack.loopPosition = j;
              this._stack.fallThrough = false;
              return handlerResult;
            }
          }
          j--;
        }
        for (; j >= 0; j--) {
          handlerResult = this._active[j].end(false);
          if (handlerResult instanceof Promise) {
            this._stack.paused = true;
            this._stack.loopPosition = j;
            this._stack.fallThrough = true;
            return handlerResult;
          }
        }
      }
    }
    this._active = EMPTY_HANDLERS;
    this._id = -1;
    this._state = import_Constants.ApcState.START;
  }
}
class ApcHandler {
  constructor(_handler) {
    this._handler = _handler;
    this._data = "";
    this._hitLimit = false;
  }
  static {
    this._payloadLimit = import_Constants.ParserConstants.PAYLOAD_LIMIT;
  }
  start() {
    this._data = "";
    this._hitLimit = false;
  }
  put(data, start, end) {
    if (this._hitLimit) {
      return;
    }
    this._data += (0, import_TextDecoder.utf32ToString)(data, start, end);
    if (this._data.length > ApcHandler._payloadLimit) {
      this._data = "";
      this._hitLimit = true;
    }
  }
  end(success) {
    let ret = false;
    if (this._hitLimit) {
      ret = false;
    } else if (success) {
      ret = this._handler(this._data);
      if (ret instanceof Promise) {
        return ret.then((res) => {
          this._data = "";
          this._hitLimit = false;
          return res;
        });
      }
    }
    this._data = "";
    this._hitLimit = false;
    return ret;
  }
}
//# sourceMappingURL=ApcParser.js.map
