"use strict";
var import_Constants = require("common/buffer/Constants");
var import_CellData = require("common/buffer/CellData");
var import_chai = require("chai");
/**
 * Copyright (c) 2026 The xterm.js authors. All rights reserved.
 * @license MIT
 */
function createStyledCell(char, underlineStyle, underlineColor) {
  const cell = new import_CellData.CellData();
  const fg = import_Constants.Attributes.CM_P256 | 12 | import_Constants.FgFlags.BOLD | import_Constants.FgFlags.UNDERLINE;
  cell.setFromCharData([fg, char, 1, char.charCodeAt(0)]);
  cell.bg = import_Constants.Attributes.CM_P16 | 2 | import_Constants.BgFlags.ITALIC;
  cell.extended.underlineStyle = underlineStyle;
  cell.extended.underlineColor = import_Constants.Attributes.CM_P256 | underlineColor;
  cell.updateExtended();
  return cell;
}
describe("CellData", () => {
  describe("attributesEquals", () => {
    it("returns true for same attributes with different chars", () => {
      const cellA = createStyledCell("A", import_Constants.UnderlineStyle.DOUBLE, 45);
      const cellB = createStyledCell("B", import_Constants.UnderlineStyle.DOUBLE, 45);
      import_chai.assert.equal(cellA.attributesEquals(cellB), true);
    });
    it("detects underline style changes", () => {
      const cellA = createStyledCell("A", import_Constants.UnderlineStyle.DOUBLE, 45);
      const cellB = createStyledCell("B", import_Constants.UnderlineStyle.SINGLE, 45);
      import_chai.assert.equal(cellA.attributesEquals(cellB), false);
    });
    it("detects underline color changes", () => {
      const cellA = createStyledCell("A", import_Constants.UnderlineStyle.SINGLE, 45);
      const cellB = createStyledCell("B", import_Constants.UnderlineStyle.SINGLE, 46);
      import_chai.assert.equal(cellA.attributesEquals(cellB), false);
    });
    it("ignores underline variant offsets", () => {
      const cellA = createStyledCell("A", import_Constants.UnderlineStyle.SINGLE, 45);
      const cellB = createStyledCell("B", import_Constants.UnderlineStyle.SINGLE, 45);
      cellA.extended.underlineVariantOffset = 1;
      cellB.extended.underlineVariantOffset = 3;
      cellA.updateExtended();
      cellB.updateExtended();
      import_chai.assert.equal(cellA.attributesEquals(cellB), true);
    });
    it("ignores url ids", () => {
      const cellA = createStyledCell("A", import_Constants.UnderlineStyle.SINGLE, 45);
      const cellB = createStyledCell("B", import_Constants.UnderlineStyle.SINGLE, 45);
      cellA.extended.urlId = 1;
      cellB.extended.urlId = 2;
      cellA.updateExtended();
      cellB.updateExtended();
      import_chai.assert.equal(cellA.attributesEquals(cellB), true);
    });
  });
});
//# sourceMappingURL=CellData.test.js.map
