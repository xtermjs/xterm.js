"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var Event_exports = {};
__export(Event_exports, {
  Emitter: () => Emitter,
  EventUtils: () => EventUtils
});
module.exports = __toCommonJS(Event_exports);
var import_Lifecycle = require("common/Lifecycle");
/**
 * Copyright (c) 2024-2026 The xterm.js authors. All rights reserved.
 * @license MIT
 *
 * Minimal event utilities for xterm.js core.
 * Simplified from VS Code's event.ts - no leak detection/profiling.
 */
class Emitter {
  constructor() {
    this._listeners = [];
    this._disposed = false;
  }
  get event() {
    if (this._event) {
      return this._event;
    }
    this._event = (listener, thisArgs, disposables) => {
      if (this._disposed) {
        return (0, import_Lifecycle.toDisposable)(() => {
        });
      }
      const entry = { fn: listener, thisArgs };
      this._listeners.push(entry);
      const result = (0, import_Lifecycle.toDisposable)(() => {
        const idx = this._listeners.indexOf(entry);
        if (idx !== -1) {
          this._listeners.splice(idx, 1);
        }
      });
      if (disposables) {
        if (Array.isArray(disposables)) {
          disposables.push(result);
        } else {
          disposables.add(result);
        }
      }
      return result;
    };
    return this._event;
  }
  fire(event) {
    if (this._disposed) {
      return;
    }
    switch (this._listeners.length) {
      case 0:
        return;
      case 1: {
        const { fn, thisArgs } = this._listeners[0];
        fn.call(thisArgs, event);
        return;
      }
      default: {
        const listeners = this._listeners.slice();
        for (const { fn, thisArgs } of listeners) {
          fn.call(thisArgs, event);
        }
      }
    }
  }
  dispose() {
    if (this._disposed) {
      return;
    }
    this._disposed = true;
    this._listeners.length = 0;
  }
}
var EventUtils;
((EventUtils2) => {
  function forward(from, to) {
    return from((e) => to.fire(e));
  }
  EventUtils2.forward = forward;
  function map(event, map2) {
    return (listener, thisArgs, disposables) => {
      return event((i) => listener.call(thisArgs, map2(i)), void 0, disposables);
    };
  }
  EventUtils2.map = map;
  function any(...events) {
    return (listener, thisArgs, disposables) => {
      const store = new import_Lifecycle.DisposableStore();
      for (const event of events) {
        store.add(event((e) => listener.call(thisArgs, e)));
      }
      if (disposables) {
        if (Array.isArray(disposables)) {
          disposables.push(store);
        } else {
          disposables.add(store);
        }
      }
      return store;
    };
  }
  EventUtils2.any = any;
  function runAndSubscribe(event, handler, initial) {
    handler(initial);
    return event((e) => handler(e));
  }
  EventUtils2.runAndSubscribe = runAndSubscribe;
})(EventUtils || (EventUtils = {}));
//# sourceMappingURL=Event.js.map
