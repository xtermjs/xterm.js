"use strict";
var import_chai = require("chai");
var import_DecorationService = require("./DecorationService");
var import_Lifecycle = require("common/Lifecycle");
var import_Event = require("common/Event");
var import_TestUtils = require("common/TestUtils.test");
/**
 * Copyright (c) 2019 The xterm.js authors. All rights reserved.
 * @license MIT
 */
function createFakeMarker(line) {
  return Object.freeze(new class extends import_Lifecycle.Disposable {
    constructor() {
      super(...arguments);
      this.id = 1;
      this.line = line;
      this.isDisposed = false;
      this.onDispose = new import_Event.Emitter().event;
    }
  }());
}
const fakeMarker = createFakeMarker(1);
describe("DecorationService", () => {
  it("should set isDisposed to true after dispose", () => {
    const service = new import_DecorationService.DecorationService(new import_TestUtils.MockLogService());
    const decoration = service.registerDecoration({
      marker: fakeMarker
    });
    import_chai.assert.ok(decoration);
    import_chai.assert.isFalse(decoration.isDisposed);
    decoration.dispose();
    import_chai.assert.isTrue(decoration.isDisposed);
  });
  describe("forEachDecorationAtCell", () => {
    it("should find decoration at its marker line", () => {
      const service = new import_DecorationService.DecorationService(new import_TestUtils.MockLogService());
      const decoration = service.registerDecoration({
        marker: createFakeMarker(5),
        width: 10
      });
      import_chai.assert.ok(decoration);
      const found = [];
      service.forEachDecorationAtCell(0, 5, void 0, (d) => found.push(d));
      import_chai.assert.strictEqual(found.length, 1);
    });
    it("should find decoration with height > 1 on subsequent lines", () => {
      const service = new import_DecorationService.DecorationService(new import_TestUtils.MockLogService());
      const decoration = service.registerDecoration({
        marker: createFakeMarker(5),
        width: 10,
        height: 3
      });
      import_chai.assert.ok(decoration);
      const foundAt5 = [];
      service.forEachDecorationAtCell(0, 5, void 0, (d) => foundAt5.push(d));
      import_chai.assert.strictEqual(foundAt5.length, 1);
      const foundAt6 = [];
      service.forEachDecorationAtCell(0, 6, void 0, (d) => foundAt6.push(d));
      import_chai.assert.strictEqual(foundAt6.length, 1);
      const foundAt7 = [];
      service.forEachDecorationAtCell(0, 7, void 0, (d) => foundAt7.push(d));
      import_chai.assert.strictEqual(foundAt7.length, 1);
      const foundAt8 = [];
      service.forEachDecorationAtCell(0, 8, void 0, (d) => foundAt8.push(d));
      import_chai.assert.strictEqual(foundAt8.length, 0);
    });
    it("should not find decoration outside its x range", () => {
      const service = new import_DecorationService.DecorationService(new import_TestUtils.MockLogService());
      const decoration = service.registerDecoration({
        marker: createFakeMarker(5),
        x: 5,
        width: 3,
        height: 2
      });
      import_chai.assert.ok(decoration);
      const foundAtX4 = [];
      service.forEachDecorationAtCell(4, 5, void 0, (d) => foundAtX4.push(d));
      import_chai.assert.strictEqual(foundAtX4.length, 0);
      const foundAtX5 = [];
      service.forEachDecorationAtCell(5, 5, void 0, (d) => foundAtX5.push(d));
      import_chai.assert.strictEqual(foundAtX5.length, 1);
      const foundAtX7 = [];
      service.forEachDecorationAtCell(7, 6, void 0, (d) => foundAtX7.push(d));
      import_chai.assert.strictEqual(foundAtX7.length, 1);
      const foundAtX8 = [];
      service.forEachDecorationAtCell(8, 5, void 0, (d) => foundAtX8.push(d));
      import_chai.assert.strictEqual(foundAtX8.length, 0);
    });
  });
  describe("getDecorationsAtCell", () => {
    it("should find decoration with height > 1 on subsequent lines", () => {
      const service = new import_DecorationService.DecorationService(new import_TestUtils.MockLogService());
      const decoration = service.registerDecoration({
        marker: createFakeMarker(5),
        width: 10,
        height: 3
      });
      import_chai.assert.ok(decoration);
      import_chai.assert.strictEqual([...service.getDecorationsAtCell(0, 5)].length, 1);
      import_chai.assert.strictEqual([...service.getDecorationsAtCell(0, 6)].length, 1);
      import_chai.assert.strictEqual([...service.getDecorationsAtCell(0, 7)].length, 1);
      import_chai.assert.strictEqual([...service.getDecorationsAtCell(0, 8)].length, 0);
    });
  });
});
//# sourceMappingURL=DecorationService.test.js.map
