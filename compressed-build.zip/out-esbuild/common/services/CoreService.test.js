"use strict";
var import_CoreService = require("common/services/CoreService");
var import_TestUtils = require("common/TestUtils.test");
var import_chai = require("chai");
/**
 * Copyright (c) 2019 The xterm.js authors. All rights reserved.
 * @license MIT
 */
describe("CoreService", () => {
  let coreService;
  beforeEach(() => {
    coreService = new import_CoreService.CoreService(
      new import_TestUtils.MockBufferService(80, 30),
      new import_TestUtils.MockLogService(),
      new import_TestUtils.MockOptionsService()
    );
  });
  describe("isCursorInitialized", () => {
    it("should be false by default", () => {
      import_chai.assert.equal(coreService.isCursorInitialized, false);
    });
    it("should be true when showCursorImmediately is true", () => {
      const coreServiceWithOption = new import_CoreService.CoreService(
        new import_TestUtils.MockBufferService(80, 30),
        new import_TestUtils.MockLogService(),
        new import_TestUtils.MockOptionsService({ showCursorImmediately: true })
      );
      import_chai.assert.equal(coreServiceWithOption.isCursorInitialized, true);
    });
  });
  describe("reset", () => {
    it("should not affect isCursorInitialized", () => {
      coreService.isCursorInitialized = true;
      coreService.reset();
      import_chai.assert.equal(coreService.isCursorInitialized, true);
      coreService.isCursorInitialized = false;
      coreService.reset();
      import_chai.assert.equal(coreService.isCursorInitialized, false);
    });
  });
});
//# sourceMappingURL=CoreService.test.js.map
