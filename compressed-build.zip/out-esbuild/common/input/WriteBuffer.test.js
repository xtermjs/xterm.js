"use strict";
var import_chai = require("chai");
var import_WriteBuffer = require("./WriteBuffer");
/**
 * Copyright (c) 2019 The xterm.js authors. All rights reserved.
 * @license MIT
 */
function toBytes(s) {
  return Buffer.from(s);
}
function fromBytes(bytes) {
  return bytes.toString();
}
describe("WriteBuffer", () => {
  let wb;
  let stack = [];
  let cbStack = [];
  beforeEach(() => {
    stack = [];
    cbStack = [];
    wb = new import_WriteBuffer.WriteBuffer((data) => {
      stack.push(data);
    });
  });
  describe("write input", () => {
    it("string", (done) => {
      wb.write("a._");
      wb.write("b.x", () => {
        cbStack.push("b");
      });
      wb.write("c._");
      wb.write("d.x", () => {
        cbStack.push("d");
      });
      wb.write("e", () => {
        import_chai.assert.deepEqual(stack, ["a._", "b.x", "c._", "d.x", "e"]);
        import_chai.assert.deepEqual(cbStack, ["b", "d"]);
        done();
      });
    });
    it("bytes", (done) => {
      wb.write(toBytes("a._"));
      wb.write(toBytes("b.x"), () => {
        cbStack.push("b");
      });
      wb.write(toBytes("c._"));
      wb.write(toBytes("d.x"), () => {
        cbStack.push("d");
      });
      wb.write(toBytes("e"), () => {
        import_chai.assert.deepEqual(stack.map((val) => typeof val === "string" ? "" : fromBytes(val)), ["a._", "b.x", "c._", "d.x", "e"]);
        import_chai.assert.deepEqual(cbStack, ["b", "d"]);
        done();
      });
    });
    it("string/bytes mixed", (done) => {
      wb.write("a._");
      wb.write("b.x", () => {
        cbStack.push("b");
      });
      wb.write(toBytes("c._"));
      wb.write(toBytes("d.x"), () => {
        cbStack.push("d");
      });
      wb.write(toBytes("e"), () => {
        import_chai.assert.deepEqual(stack.map((val) => typeof val === "string" ? val : fromBytes(val)), ["a._", "b.x", "c._", "d.x", "e"]);
        import_chai.assert.deepEqual(cbStack, ["b", "d"]);
        done();
      });
    });
    it("write callback works for empty chunks", (done) => {
      wb.write("a", () => {
        cbStack.push("a");
      });
      wb.write("", () => {
        cbStack.push("b");
      });
      wb.write(toBytes("c"), () => {
        cbStack.push("c");
      });
      wb.write(new Uint8Array(0), () => {
        cbStack.push("d");
      });
      wb.write("e", () => {
        import_chai.assert.deepEqual(stack.map((val) => typeof val === "string" ? val : fromBytes(val)), ["a", "", "c", "", "e"]);
        import_chai.assert.deepEqual(cbStack, ["a", "b", "c", "d"]);
        done();
      });
    });
    it("writeSync", (done) => {
      wb.write("a", () => {
        cbStack.push("a");
      });
      wb.write("b", () => {
        cbStack.push("b");
      });
      wb.write("c", () => {
        cbStack.push("c");
      });
      wb.writeSync("d");
      import_chai.assert.deepEqual(stack, ["a", "b", "c", "d"]);
      import_chai.assert.deepEqual(cbStack, ["a", "b", "c"]);
      wb.write("x", () => {
        cbStack.push("x");
      });
      wb.write("", () => {
        import_chai.assert.deepEqual(stack, ["a", "b", "c", "d", "x", ""]);
        import_chai.assert.deepEqual(cbStack, ["a", "b", "c", "x"]);
        done();
      });
    });
    it("writeSync called from action does not overflow callstack - issue #3265", () => {
      wb = new import_WriteBuffer.WriteBuffer((data) => {
        const num = parseInt(data);
        if (num < 1e4) {
          wb.writeSync("" + (num + 1));
        }
      });
      wb.writeSync("1");
    });
    it("writeSync maxSubsequentCalls argument", () => {
      let last = "";
      wb = new import_WriteBuffer.WriteBuffer((data) => {
        last = data;
        const num = parseInt(data);
        if (num < 1e6) {
          wb.writeSync("" + (num + 1), 10);
        }
      });
      wb.writeSync("1", 10);
      import_chai.assert.equal(last, "11");
    });
    it("flushSync processes all pending writes", (done) => {
      wb.write("a", () => {
        cbStack.push("a");
      });
      wb.write("b", () => {
        cbStack.push("b");
      });
      wb.write("c", () => {
        cbStack.push("c");
      });
      wb.flushSync();
      import_chai.assert.deepEqual(stack, ["a", "b", "c"]);
      import_chai.assert.deepEqual(cbStack, ["a", "b", "c"]);
      wb.write("x", () => {
        cbStack.push("x");
      });
      wb.write("", () => {
        import_chai.assert.deepEqual(stack, ["a", "b", "c", "x", ""]);
        import_chai.assert.deepEqual(cbStack, ["a", "b", "c", "x"]);
        done();
      });
    });
    it("flushSync with no pending writes is a no-op", () => {
      wb.flushSync();
      import_chai.assert.deepEqual(stack, []);
      import_chai.assert.deepEqual(cbStack, []);
    });
  });
});
//# sourceMappingURL=WriteBuffer.test.js.map
