"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var KittyKeyboard_exports = {};
__export(KittyKeyboard_exports, {
  KittyKeyboard: () => KittyKeyboard,
  KittyKeyboardEventType: () => KittyKeyboardEventType,
  KittyKeyboardFlags: () => KittyKeyboardFlags,
  KittyKeyboardModifiers: () => KittyKeyboardModifiers
});
module.exports = __toCommonJS(KittyKeyboard_exports);
var import_Types = require("common/Types");
var import_EscapeSequences = require("common/data/EscapeSequences");
/**
 * Copyright (c) 2025 The xterm.js authors. All rights reserved.
 * @license MIT
 *
 * Kitty keyboard protocol implementation.
 * @see https://sw.kovidgoyal.net/kitty/keyboard-protocol/
 */
var KittyKeyboardFlags = /* @__PURE__ */ ((KittyKeyboardFlags2) => {
  KittyKeyboardFlags2[KittyKeyboardFlags2["NONE"] = 0] = "NONE";
  KittyKeyboardFlags2[KittyKeyboardFlags2["DISAMBIGUATE_ESCAPE_CODES"] = 1] = "DISAMBIGUATE_ESCAPE_CODES";
  KittyKeyboardFlags2[KittyKeyboardFlags2["REPORT_EVENT_TYPES"] = 2] = "REPORT_EVENT_TYPES";
  KittyKeyboardFlags2[KittyKeyboardFlags2["REPORT_ALTERNATE_KEYS"] = 4] = "REPORT_ALTERNATE_KEYS";
  KittyKeyboardFlags2[KittyKeyboardFlags2["REPORT_ALL_KEYS_AS_ESCAPE_CODES"] = 8] = "REPORT_ALL_KEYS_AS_ESCAPE_CODES";
  KittyKeyboardFlags2[KittyKeyboardFlags2["REPORT_ASSOCIATED_TEXT"] = 16] = "REPORT_ASSOCIATED_TEXT";
  return KittyKeyboardFlags2;
})(KittyKeyboardFlags || {});
var KittyKeyboardEventType = /* @__PURE__ */ ((KittyKeyboardEventType2) => {
  KittyKeyboardEventType2[KittyKeyboardEventType2["PRESS"] = 1] = "PRESS";
  KittyKeyboardEventType2[KittyKeyboardEventType2["REPEAT"] = 2] = "REPEAT";
  KittyKeyboardEventType2[KittyKeyboardEventType2["RELEASE"] = 3] = "RELEASE";
  return KittyKeyboardEventType2;
})(KittyKeyboardEventType || {});
var KittyKeyboardModifiers = /* @__PURE__ */ ((KittyKeyboardModifiers2) => {
  KittyKeyboardModifiers2[KittyKeyboardModifiers2["SHIFT"] = 1] = "SHIFT";
  KittyKeyboardModifiers2[KittyKeyboardModifiers2["ALT"] = 2] = "ALT";
  KittyKeyboardModifiers2[KittyKeyboardModifiers2["CTRL"] = 4] = "CTRL";
  KittyKeyboardModifiers2[KittyKeyboardModifiers2["SUPER"] = 8] = "SUPER";
  KittyKeyboardModifiers2[KittyKeyboardModifiers2["HYPER"] = 16] = "HYPER";
  KittyKeyboardModifiers2[KittyKeyboardModifiers2["META"] = 32] = "META";
  KittyKeyboardModifiers2[KittyKeyboardModifiers2["CAPS_LOCK"] = 64] = "CAPS_LOCK";
  KittyKeyboardModifiers2[KittyKeyboardModifiers2["NUM_LOCK"] = 128] = "NUM_LOCK";
  return KittyKeyboardModifiers2;
})(KittyKeyboardModifiers || {});
class KittyKeyboard {
  constructor() {
    /**
     * Functional key codes for Kitty protocol.
     * Keys that don't produce text have specific unicode codepoint mappings.
     */
    this._functionalKeyCodes = {
      "Escape": 27,
      "Enter": 13,
      "Tab": 9,
      "Backspace": 127,
      "CapsLock": 57358,
      "ScrollLock": 57359,
      "NumLock": 57360,
      "PrintScreen": 57361,
      "Pause": 57362,
      "ContextMenu": 57363,
      // F13-F35 (F1-F12 use legacy encoding)
      "F13": 57376,
      "F14": 57377,
      "F15": 57378,
      "F16": 57379,
      "F17": 57380,
      "F18": 57381,
      "F19": 57382,
      "F20": 57383,
      "F21": 57384,
      "F22": 57385,
      "F23": 57386,
      "F24": 57387,
      "F25": 57388,
      // Keypad keys
      "KP_0": 57399,
      "KP_1": 57400,
      "KP_2": 57401,
      "KP_3": 57402,
      "KP_4": 57403,
      "KP_5": 57404,
      "KP_6": 57405,
      "KP_7": 57406,
      "KP_8": 57407,
      "KP_9": 57408,
      "KP_Decimal": 57409,
      "KP_Divide": 57410,
      "KP_Multiply": 57411,
      "KP_Subtract": 57412,
      "KP_Add": 57413,
      "KP_Enter": 57414,
      "KP_Equal": 57415,
      // Modifier keys
      "ShiftLeft": 57441,
      "ShiftRight": 57447,
      "ControlLeft": 57442,
      "ControlRight": 57448,
      "AltLeft": 57443,
      "AltRight": 57449,
      "MetaLeft": 57444,
      "MetaRight": 57450,
      // Media keys
      "MediaPlayPause": 57430,
      "MediaStop": 57432,
      "MediaTrackNext": 57435,
      "MediaTrackPrevious": 57436,
      "AudioVolumeDown": 57438,
      "AudioVolumeUp": 57439,
      "AudioVolumeMute": 57440
    };
    /**
     * Keys that use CSI ~ encoding with a number parameter.
     */
    this._csiTildeKeys = {
      "Insert": 2,
      "Delete": 3,
      "PageUp": 5,
      "PageDown": 6,
      "F5": 15,
      "F6": 17,
      "F7": 18,
      "F8": 19,
      "F9": 20,
      "F10": 21,
      "F11": 23,
      "F12": 24
    };
    /**
     * Keys that use CSI letter encoding (arrows, Home, End).
     */
    this._csiLetterKeys = {
      "ArrowUp": "A",
      "ArrowDown": "B",
      "ArrowRight": "C",
      "ArrowLeft": "D",
      "Home": "H",
      "End": "F"
    };
    /**
     * Function keys F1-F4 use SS3 encoding without modifiers.
     */
    this._ss3FunctionKeys = {
      "F1": "P",
      "F2": "Q",
      "F3": "R",
      "F4": "S"
    };
  }
  /**
   * Map browser key codes to Kitty numpad codes.
   */
  _getNumpadKeyCode(ev) {
    if (ev.code.startsWith("Numpad")) {
      const suffix = ev.code.slice(6);
      if (suffix >= "0" && suffix <= "9") {
        return 57399 + parseInt(suffix, 10);
      }
      switch (suffix) {
        case "Decimal":
          return 57409;
        case "Divide":
          return 57410;
        case "Multiply":
          return 57411;
        case "Subtract":
          return 57412;
        case "Add":
          return 57413;
        case "Enter":
          return 57414;
        case "Equal":
          return 57415;
      }
    }
    return void 0;
  }
  /**
   * Get modifier key code from code property.
   */
  _getModifierKeyCode(ev) {
    switch (ev.code) {
      case "ShiftLeft":
        return 57441;
      case "ShiftRight":
        return 57447;
      case "ControlLeft":
        return 57442;
      case "ControlRight":
        return 57448;
      case "AltLeft":
        return 57443;
      case "AltRight":
        return 57449;
      case "MetaLeft":
        return 57444;
      case "MetaRight":
        return 57450;
    }
    return void 0;
  }
  /**
   * Encode modifiers for Kitty protocol.
   * Returns 1 + modifier bits, or 0 if no modifiers.
   */
  _encodeModifiers(ev) {
    let mods = 0;
    if (ev.shiftKey) mods |= 1 /* SHIFT */;
    if (ev.altKey) mods |= 2 /* ALT */;
    if (ev.ctrlKey) mods |= 4 /* CTRL */;
    if (ev.metaKey) mods |= 8 /* SUPER */;
    return mods > 0 ? mods + 1 : 0;
  }
  /**
   * Get the unicode key code for a keyboard event.
   * Returns the lowercase codepoint for letters.
   * For shifted keys, uses the code property to get the base key.
   */
  _getKeyCode(ev) {
    const numpadCode = this._getNumpadKeyCode(ev);
    if (numpadCode !== void 0) {
      return numpadCode;
    }
    const modifierCode = this._getModifierKeyCode(ev);
    if (modifierCode !== void 0) {
      return modifierCode;
    }
    const funcCode = this._functionalKeyCodes[ev.key];
    if (funcCode !== void 0) {
      return funcCode;
    }
    if (ev.shiftKey && ev.code) {
      if (ev.code.startsWith("Digit") && ev.code.length === 6) {
        const digit = ev.code.charAt(5);
        if (digit >= "0" && digit <= "9") {
          return digit.charCodeAt(0);
        }
      }
      if (ev.code.startsWith("Key") && ev.code.length === 4) {
        const letter = ev.code.charAt(3).toLowerCase();
        return letter.charCodeAt(0);
      }
    }
    if (ev.key.length === 1) {
      const code = ev.key.codePointAt(0);
      if (code >= 65 && code <= 90) {
        return code + 32;
      }
      return code;
    }
    return void 0;
  }
  /**
   * Check if a key is a modifier key.
   */
  _isModifierKey(ev) {
    return ev.key === "Shift" || ev.key === "Control" || ev.key === "Alt" || ev.key === "Meta";
  }
  /**
   * Build CSI letter sequence for arrow keys, Home, End.
   * Format: CSI [1;mod] letter
   */
  _buildCsiLetterSequence(letter, modifiers, eventType, reportEventTypes) {
    const needsEventType = reportEventTypes && eventType !== 1 /* PRESS */;
    if (modifiers > 0 || needsEventType) {
      let seq = import_EscapeSequences.C0.ESC + "[1;" + (modifiers > 0 ? modifiers : "1");
      if (needsEventType) {
        seq += ":" + eventType;
      }
      seq += letter;
      return seq;
    }
    return import_EscapeSequences.C0.ESC + "[" + letter;
  }
  /**
   * Build SS3 sequence for F1-F4.
   * Without modifiers: SS3 letter
   * With modifiers: CSI 1;mod letter
   */
  _buildSs3Sequence(letter, modifiers, eventType, reportEventTypes) {
    const needsEventType = reportEventTypes && eventType !== 1 /* PRESS */;
    if (modifiers > 0 || needsEventType) {
      let seq = import_EscapeSequences.C0.ESC + "[1;" + (modifiers > 0 ? modifiers : "1");
      if (needsEventType) {
        seq += ":" + eventType;
      }
      seq += letter;
      return seq;
    }
    return import_EscapeSequences.C0.ESC + "O" + letter;
  }
  /**
   * Build CSI ~ sequence for Insert, Delete, PageUp/Down, F5-F12.
   * Format: CSI number [;mod[:event]] ~
   */
  _buildCsiTildeSequence(number, modifiers, eventType, reportEventTypes) {
    const needsEventType = reportEventTypes && eventType !== 1 /* PRESS */;
    let seq = import_EscapeSequences.C0.ESC + "[" + number;
    if (modifiers > 0 || needsEventType) {
      seq += ";" + (modifiers > 0 ? modifiers : "1");
      if (needsEventType) {
        seq += ":" + eventType;
      }
    }
    seq += "~";
    return seq;
  }
  /**
   * Build CSI u sequence.
   * Format: CSI keycode[:shifted[:base]] [;mod[:event][;text]] u
   */
  _buildCsiUSequence(ev, keyCode, modifiers, eventType, flags, isFunc, isMod) {
    const reportEventTypes = !!(flags & 2 /* REPORT_EVENT_TYPES */);
    const reportAlternateKeys = !!(flags & 4 /* REPORT_ALTERNATE_KEYS */);
    let seq = import_EscapeSequences.C0.ESC + "[" + keyCode;
    let shiftedKey;
    if (reportAlternateKeys && ev.shiftKey && ev.key.length === 1 && !isFunc && !isMod) {
      shiftedKey = ev.key.codePointAt(0);
      seq += ":" + shiftedKey;
    }
    const reportAssociatedText = !!(flags & 16 /* REPORT_ASSOCIATED_TEXT */) && eventType !== 3 /* RELEASE */ && ev.key.length === 1 && !isFunc && !isMod && !ev.ctrlKey;
    const textCode = reportAssociatedText ? ev.key.codePointAt(0) : void 0;
    const needsEventType = reportEventTypes && eventType !== 1 /* PRESS */ && (eventType === 3 /* RELEASE */ || textCode === void 0);
    if (modifiers > 0 || needsEventType || textCode !== void 0) {
      seq += ";";
      if (modifiers > 0) {
        seq += modifiers;
      } else if (needsEventType) {
        seq += "1";
      }
      if (needsEventType) {
        seq += ":" + eventType;
      }
    }
    if (textCode !== void 0) {
      seq += ";" + textCode;
    }
    seq += "u";
    return seq;
  }
  /**
   * Evaluate a keyboard event using Kitty keyboard protocol.
   *
   * @param ev The keyboard event.
   * @param flags The active Kitty keyboard enhancement flags.
   * @param eventType The event type (press, repeat, release).
   * @returns The keyboard result with the encoded key sequence.
   */
  evaluate(ev, flags, eventType = 1 /* PRESS */) {
    const result = {
      type: import_Types.KeyboardResultType.SEND_KEY,
      cancel: false,
      key: void 0
    };
    const modifiers = this._encodeModifiers(ev);
    const isMod = this._isModifierKey(ev);
    const reportEventTypes = !!(flags & 2 /* REPORT_EVENT_TYPES */);
    if (!reportEventTypes && eventType === 3 /* RELEASE */) {
      return result;
    }
    if (isMod && !(flags & 8 /* REPORT_ALL_KEYS_AS_ESCAPE_CODES */)) {
      return result;
    }
    const csiLetter = this._csiLetterKeys[ev.key];
    if (csiLetter) {
      result.key = this._buildCsiLetterSequence(csiLetter, modifiers, eventType, reportEventTypes);
      result.cancel = true;
      return result;
    }
    const ss3Letter = this._ss3FunctionKeys[ev.key];
    if (ss3Letter) {
      result.key = this._buildSs3Sequence(ss3Letter, modifiers, eventType, reportEventTypes);
      result.cancel = true;
      return result;
    }
    const tildeCode = this._csiTildeKeys[ev.key];
    if (tildeCode !== void 0) {
      result.key = this._buildCsiTildeSequence(tildeCode, modifiers, eventType, reportEventTypes);
      result.cancel = true;
      return result;
    }
    const keyCode = this._getKeyCode(ev);
    if (keyCode === void 0) {
      return result;
    }
    const isFunc = this._functionalKeyCodes[ev.key] !== void 0 || this._getNumpadKeyCode(ev) !== void 0;
    let useCsiU = false;
    if (flags & 8 /* REPORT_ALL_KEYS_AS_ESCAPE_CODES */) {
      useCsiU = true;
    } else if (reportEventTypes) {
      useCsiU = true;
    } else if (flags & 1 /* DISAMBIGUATE_ESCAPE_CODES */) {
      if (keyCode === 27 || keyCode === 127 || keyCode === 13 || keyCode === 9 || keyCode === 32) {
        useCsiU = true;
      } else if (isFunc) {
        useCsiU = true;
      } else if (modifiers > 0) {
        if (ev.shiftKey && !ev.ctrlKey && !ev.altKey && !ev.metaKey && ev.key.length === 1) {
          useCsiU = false;
        } else {
          useCsiU = true;
        }
      }
    }
    if (useCsiU) {
      result.key = this._buildCsiUSequence(ev, keyCode, modifiers, eventType, flags, isFunc, isMod);
      result.cancel = true;
    } else {
      if (ev.key.length === 1 && !ev.ctrlKey && !ev.altKey && !ev.metaKey) {
        result.key = ev.key;
      }
    }
    return result;
  }
  /**
   * Check if Kitty protocol should be used based on flags.
   */
  static shouldUseProtocol(flags) {
    return flags > 0;
  }
}
//# sourceMappingURL=KittyKeyboard.js.map
