"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var Win32InputMode_exports = {};
__export(Win32InputMode_exports, {
  Win32ControlKeyState: () => Win32ControlKeyState,
  Win32InputMode: () => Win32InputMode
});
module.exports = __toCommonJS(Win32InputMode_exports);
var import_Types = require("common/Types");
var import_EscapeSequences = require("common/data/EscapeSequences");
/**
 * Copyright (c) 2026 The xterm.js authors. All rights reserved.
 * @license MIT
 *
 * Win32 input mode implementation.
 * @see https://github.com/microsoft/terminal/blob/main/doc/specs/%234999%20-%20Improved%20keyboard%20handling%20in%20Conpty.md
 *
 * Format: CSI Vk ; Sc ; Uc ; Kd ; Cs ; Rc _
 *   Vk: Virtual key code (decimal)
 *   Sc: Scan code (decimal)
 *   Uc: Unicode character (decimal codepoint, 0 if none)
 *   Kd: Key down (1) or up (0)
 *   Cs: Control key state (modifier flags)
 *   Rc: Repeat count (usually 1)
 */
var Win32ControlKeyState = /* @__PURE__ */ ((Win32ControlKeyState2) => {
  Win32ControlKeyState2[Win32ControlKeyState2["RIGHT_ALT_PRESSED"] = 1] = "RIGHT_ALT_PRESSED";
  Win32ControlKeyState2[Win32ControlKeyState2["LEFT_ALT_PRESSED"] = 2] = "LEFT_ALT_PRESSED";
  Win32ControlKeyState2[Win32ControlKeyState2["RIGHT_CTRL_PRESSED"] = 4] = "RIGHT_CTRL_PRESSED";
  Win32ControlKeyState2[Win32ControlKeyState2["LEFT_CTRL_PRESSED"] = 8] = "LEFT_CTRL_PRESSED";
  Win32ControlKeyState2[Win32ControlKeyState2["SHIFT_PRESSED"] = 16] = "SHIFT_PRESSED";
  Win32ControlKeyState2[Win32ControlKeyState2["NUMLOCK_ON"] = 32] = "NUMLOCK_ON";
  Win32ControlKeyState2[Win32ControlKeyState2["SCROLLLOCK_ON"] = 64] = "SCROLLLOCK_ON";
  Win32ControlKeyState2[Win32ControlKeyState2["CAPSLOCK_ON"] = 128] = "CAPSLOCK_ON";
  Win32ControlKeyState2[Win32ControlKeyState2["ENHANCED_KEY"] = 256] = "ENHANCED_KEY";
  return Win32ControlKeyState2;
})(Win32ControlKeyState || {});
class Win32InputMode {
  constructor() {
    /**
     * Mapping from browser KeyboardEvent.code to Win32 virtual key codes.
     * Based on https://docs.microsoft.com/en-us/windows/win32/inputdev/virtual-key-codes
     */
    this._codeToVk = {
      // Letters
      "KeyA": 65,
      "KeyB": 66,
      "KeyC": 67,
      "KeyD": 68,
      "KeyE": 69,
      "KeyF": 70,
      "KeyG": 71,
      "KeyH": 72,
      "KeyI": 73,
      "KeyJ": 74,
      "KeyK": 75,
      "KeyL": 76,
      "KeyM": 77,
      "KeyN": 78,
      "KeyO": 79,
      "KeyP": 80,
      "KeyQ": 81,
      "KeyR": 82,
      "KeyS": 83,
      "KeyT": 84,
      "KeyU": 85,
      "KeyV": 86,
      "KeyW": 87,
      "KeyX": 88,
      "KeyY": 89,
      "KeyZ": 90,
      // Digits
      "Digit0": 48,
      "Digit1": 49,
      "Digit2": 50,
      "Digit3": 51,
      "Digit4": 52,
      "Digit5": 53,
      "Digit6": 54,
      "Digit7": 55,
      "Digit8": 56,
      "Digit9": 57,
      // Function keys
      "F1": 112,
      "F2": 113,
      "F3": 114,
      "F4": 115,
      "F5": 116,
      "F6": 117,
      "F7": 118,
      "F8": 119,
      "F9": 120,
      "F10": 121,
      "F11": 122,
      "F12": 123,
      "F13": 124,
      "F14": 125,
      "F15": 126,
      "F16": 127,
      "F17": 128,
      "F18": 129,
      "F19": 130,
      "F20": 131,
      "F21": 132,
      "F22": 133,
      "F23": 134,
      "F24": 135,
      // Numpad
      "Numpad0": 96,
      "Numpad1": 97,
      "Numpad2": 98,
      "Numpad3": 99,
      "Numpad4": 100,
      "Numpad5": 101,
      "Numpad6": 102,
      "Numpad7": 103,
      "Numpad8": 104,
      "Numpad9": 105,
      "NumpadMultiply": 106,
      "NumpadAdd": 107,
      "NumpadSeparator": 108,
      "NumpadSubtract": 109,
      "NumpadDecimal": 110,
      "NumpadDivide": 111,
      "NumpadEnter": 13,
      // Same as Enter but with ENHANCED_KEY flag
      "NumLock": 144,
      // Navigation
      "ArrowUp": 38,
      "ArrowDown": 40,
      "ArrowLeft": 37,
      "ArrowRight": 39,
      "Home": 36,
      "End": 35,
      "PageUp": 33,
      "PageDown": 34,
      "Insert": 45,
      "Delete": 46,
      // Modifiers
      "ShiftLeft": 16,
      "ShiftRight": 16,
      "ControlLeft": 17,
      "ControlRight": 17,
      "AltLeft": 18,
      "AltRight": 18,
      "MetaLeft": 91,
      "MetaRight": 92,
      "CapsLock": 20,
      "ScrollLock": 145,
      // Special keys
      "Escape": 27,
      "Enter": 13,
      "Tab": 9,
      "Space": 32,
      "Backspace": 8,
      "Pause": 19,
      "ContextMenu": 93,
      "PrintScreen": 44,
      // OEM keys (US keyboard layout)
      "Semicolon": 186,
      // ;:
      "Equal": 187,
      // =+
      "Comma": 188,
      // ,<
      "Minus": 189,
      // -_
      "Period": 190,
      // .>
      "Slash": 191,
      // /?
      "Backquote": 192,
      // `~
      "BracketLeft": 219,
      // [{
      "Backslash": 220,
      // \|
      "BracketRight": 221,
      // ]}
      "Quote": 222,
      // '"
      "IntlBackslash": 226
      // Non-US backslash
    };
    /**
     * Mapping from browser KeyboardEvent.code to approximate Win32 scan codes.
     * Note: Scan codes can vary by keyboard layout. These are approximations
     * based on standard US keyboard layout.
     */
    this._codeToScancode = {
      // Letters (row by row)
      "KeyQ": 16,
      "KeyW": 17,
      "KeyE": 18,
      "KeyR": 19,
      "KeyT": 20,
      "KeyY": 21,
      "KeyU": 22,
      "KeyI": 23,
      "KeyO": 24,
      "KeyP": 25,
      "KeyA": 30,
      "KeyS": 31,
      "KeyD": 32,
      "KeyF": 33,
      "KeyG": 34,
      "KeyH": 35,
      "KeyJ": 36,
      "KeyK": 37,
      "KeyL": 38,
      "KeyZ": 44,
      "KeyX": 45,
      "KeyC": 46,
      "KeyV": 47,
      "KeyB": 48,
      "KeyN": 49,
      "KeyM": 50,
      // Digits
      "Digit1": 2,
      "Digit2": 3,
      "Digit3": 4,
      "Digit4": 5,
      "Digit5": 6,
      "Digit6": 7,
      "Digit7": 8,
      "Digit8": 9,
      "Digit9": 10,
      "Digit0": 11,
      // Function keys
      "F1": 59,
      "F2": 60,
      "F3": 61,
      "F4": 62,
      "F5": 63,
      "F6": 64,
      "F7": 65,
      "F8": 66,
      "F9": 67,
      "F10": 68,
      "F11": 87,
      "F12": 88,
      // Numpad
      "Numpad0": 82,
      "Numpad1": 79,
      "Numpad2": 80,
      "Numpad3": 81,
      "Numpad4": 75,
      "Numpad5": 76,
      "Numpad6": 77,
      "Numpad7": 71,
      "Numpad8": 72,
      "Numpad9": 73,
      "NumpadMultiply": 55,
      "NumpadAdd": 78,
      "NumpadSubtract": 74,
      "NumpadDecimal": 83,
      "NumpadDivide": 53,
      "NumpadEnter": 28,
      "NumLock": 69,
      // Navigation (extended keys)
      "ArrowUp": 72,
      "ArrowDown": 80,
      "ArrowLeft": 75,
      "ArrowRight": 77,
      "Home": 71,
      "End": 79,
      "PageUp": 73,
      "PageDown": 81,
      "Insert": 82,
      "Delete": 83,
      // Modifiers
      "ShiftLeft": 42,
      "ShiftRight": 54,
      "ControlLeft": 29,
      "ControlRight": 29,
      "AltLeft": 56,
      "AltRight": 56,
      "CapsLock": 58,
      "ScrollLock": 70,
      // Special keys
      "Escape": 1,
      "Enter": 28,
      "Tab": 15,
      "Space": 57,
      "Backspace": 14,
      "Pause": 69,
      // OEM keys
      "Semicolon": 39,
      "Equal": 13,
      "Comma": 51,
      "Minus": 12,
      "Period": 52,
      "Slash": 53,
      "Backquote": 41,
      "BracketLeft": 26,
      "Backslash": 43,
      "BracketRight": 27,
      "Quote": 40
    };
    /**
     * Codes that represent enhanced keys (extended keyboard keys).
     */
    this._enhancedKeyCodes = /* @__PURE__ */ new Set([
      "ArrowUp",
      "ArrowDown",
      "ArrowLeft",
      "ArrowRight",
      "Home",
      "End",
      "PageUp",
      "PageDown",
      "Insert",
      "Delete",
      "NumpadEnter",
      "NumpadDivide",
      "ControlRight",
      "AltRight",
      "PrintScreen",
      "Pause",
      "ContextMenu",
      "MetaLeft",
      "MetaRight"
    ]);
    /**
     * Mapping of special keys (ev.key values) to their Unicode control character codes.
     * These keys have multi-character ev.key strings but produce control characters.
     * @see https://docs.microsoft.com/en-us/windows/console/key-event-record-str
     */
    this._keyToControlChar = {
      "Enter": 13,
      // Carriage return
      "Backspace": 8,
      // Backspace
      "Tab": 9,
      // Horizontal tab
      "Escape": 27
      // Escape
    };
  }
  /**
   * Get the Win32 virtual key code for a keyboard event.
   */
  _getVirtualKeyCode(ev) {
    const vk = this._codeToVk[ev.code];
    if (vk !== void 0) {
      return vk;
    }
    return ev.keyCode || 0;
  }
  /**
   * Get the Win32 scan code for a keyboard event.
   * Returns 0 if unknown (scan codes vary by hardware).
   */
  _getScanCode(ev) {
    return this._codeToScancode[ev.code] || 0;
  }
  /**
   * Get the unicode character for a keyboard event.
   * Returns 0 for non-character keys.
   */
  _getUnicodeChar(ev) {
    if (ev.ctrlKey && !ev.altKey && !ev.metaKey) {
      if (ev.key === "Enter") {
        return 10;
      }
      if (ev.key === "Backspace") {
        return 127;
      }
    }
    const controlChar = this._keyToControlChar[ev.key];
    if (controlChar !== void 0) {
      return controlChar;
    }
    if (ev.key.length === 1) {
      const codePoint = ev.key.codePointAt(0) || 0;
      if (ev.ctrlKey && !ev.altKey && !ev.metaKey) {
        if (codePoint >= 65 && codePoint <= 90) {
          return codePoint - 64;
        }
        if (codePoint >= 97 && codePoint <= 122) {
          return codePoint - 96;
        }
      }
      return codePoint;
    }
    return 0;
  }
  /**
   * Get the Win32 control key state flags.
   */
  _getControlKeyState(ev) {
    let state = 0;
    if (ev.shiftKey) {
      state |= 16 /* SHIFT_PRESSED */;
    }
    if (ev.ctrlKey) {
      if (ev.code === "ControlRight") {
        state |= 4 /* RIGHT_CTRL_PRESSED */;
      } else {
        state |= 8 /* LEFT_CTRL_PRESSED */;
      }
    }
    if (ev.altKey) {
      if (ev.code === "AltRight") {
        state |= 1 /* RIGHT_ALT_PRESSED */;
      } else {
        state |= 2 /* LEFT_ALT_PRESSED */;
      }
    }
    if (this._enhancedKeyCodes.has(ev.code)) {
      state |= 256 /* ENHANCED_KEY */;
    }
    return state;
  }
  /**
   * Evaluate a keyboard event using Win32 input mode.
   *
   * @param ev The keyboard event.
   * @param isKeyDown Whether this is a keydown (true) or keyup (false) event.
   * @returns The keyboard result with the encoded key sequence.
   */
  evaluateKeyboardEvent(ev, isKeyDown) {
    const vk = this._getVirtualKeyCode(ev);
    const sc = this._getScanCode(ev);
    const uc = this._getUnicodeChar(ev);
    const kd = isKeyDown ? 1 : 0;
    const cs = this._getControlKeyState(ev);
    const rc = 1;
    return {
      type: import_Types.KeyboardResultType.SEND_KEY,
      cancel: true,
      key: `${import_EscapeSequences.C0.ESC}[${vk};${sc};${uc};${kd};${cs};${rc}_`
    };
  }
}
//# sourceMappingURL=Win32InputMode.js.map
