"use strict";
var import_chai = require("chai");
var import_Win32InputMode = require("common/input/Win32InputMode");
var import_Types = require("common/Types");
/**
 * Copyright (c) 2026 The xterm.js authors. All rights reserved.
 * @license MIT
 */
const ev = (opts) => ({
  altKey: false,
  ctrlKey: false,
  shiftKey: false,
  metaKey: false,
  keyCode: 0,
  code: "",
  key: "",
  type: "keydown",
  ...opts
});
const parse = (seq) => {
  const m = seq.match(/^\x1b\[(\d+);(\d+);(\d+);(\d+);(\d+);(\d+)_$/);
  return m ? { vk: +m[1], sc: +m[2], uc: +m[3], kd: +m[4], cs: +m[5], rc: +m[6] } : null;
};
const win32 = new import_Win32InputMode.Win32InputMode();
const test = (opts, isDown, check) => {
  const result = win32.evaluateKeyboardEvent(ev(opts), isDown);
  const parsed = parse(result.key);
  import_chai.assert.ok(parsed);
  check(parsed);
};
describe("Win32InputMode", () => {
  describe("evaluateKeyboardEvent", () => {
    describe("basic key encoding", () => {
      it("letter key press", () => {
        const result = win32.evaluateKeyboardEvent(ev({ code: "KeyA", key: "a", keyCode: 65 }), true);
        import_chai.assert.strictEqual(result.type, import_Types.KeyboardResultType.SEND_KEY);
        import_chai.assert.strictEqual(result.cancel, true);
        const p = parse(result.key);
        import_chai.assert.ok(p);
        import_chai.assert.deepStrictEqual([p.vk, p.uc, p.kd, p.rc], [65, 97, 1, 1]);
      });
      it("letter key release", () => test({ code: "KeyA", key: "a", keyCode: 65 }, false, (p) => import_chai.assert.strictEqual(p.kd, 0)));
      it("digit key", () => test({ code: "Digit1", key: "1", keyCode: 49 }, true, (p) => import_chai.assert.deepStrictEqual([p.vk, p.uc], [49, 49])));
      it("Enter key", () => test({ code: "Enter", key: "Enter", keyCode: 13 }, true, (p) => import_chai.assert.deepStrictEqual([p.vk, p.uc], [13, 13])));
      it("Escape key", () => test({ code: "Escape", key: "Escape", keyCode: 27 }, true, (p) => import_chai.assert.deepStrictEqual([p.vk, p.uc], [27, 27])));
      it("Space key", () => test({ code: "Space", key: " ", keyCode: 32 }, true, (p) => import_chai.assert.deepStrictEqual([p.vk, p.uc], [32, 32])));
    });
    describe("modifier encoding", () => {
      it("shift", () => test({ code: "KeyA", key: "A", keyCode: 65, shiftKey: true }, true, (p) => import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.SHIFT_PRESSED)));
      it("ctrl left", () => test({ code: "KeyA", key: "a", keyCode: 65, ctrlKey: true }, true, (p) => import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.LEFT_CTRL_PRESSED)));
      it("ctrl right", () => test({ code: "ControlRight", key: "Control", keyCode: 17, ctrlKey: true }, true, (p) => {
        import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.RIGHT_CTRL_PRESSED);
        import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.ENHANCED_KEY);
      }));
      it("alt left", () => test({ code: "KeyA", key: "a", keyCode: 65, altKey: true }, true, (p) => import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.LEFT_ALT_PRESSED)));
      it("alt right", () => test({ code: "AltRight", key: "Alt", keyCode: 18, altKey: true }, true, (p) => {
        import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.RIGHT_ALT_PRESSED);
        import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.ENHANCED_KEY);
      }));
      it("multiple modifiers", () => test({ code: "KeyA", key: "A", keyCode: 65, shiftKey: true, ctrlKey: true, altKey: true }, true, (p) => {
        import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.SHIFT_PRESSED);
        import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.LEFT_CTRL_PRESSED);
        import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.LEFT_ALT_PRESSED);
      }));
    });
    describe("function keys", () => {
      it("F1", () => test({ code: "F1", key: "F1", keyCode: 112 }, true, (p) => import_chai.assert.strictEqual(p.vk, 112)));
      it("F5", () => test({ code: "F5", key: "F5", keyCode: 116 }, true, (p) => import_chai.assert.strictEqual(p.vk, 116)));
      it("F12", () => test({ code: "F12", key: "F12", keyCode: 123 }, true, (p) => import_chai.assert.strictEqual(p.vk, 123)));
      it("Ctrl+F1", () => test({ code: "F1", key: "F1", keyCode: 112, ctrlKey: true }, true, (p) => {
        import_chai.assert.strictEqual(p.vk, 112);
        import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.LEFT_CTRL_PRESSED);
      }));
    });
    describe("navigation keys (ENHANCED_KEY)", () => {
      const navKeys = [
        ["ArrowUp", "ArrowUp", 38, 38],
        ["ArrowDown", "ArrowDown", 40, 40],
        ["ArrowLeft", "ArrowLeft", 37, 37],
        ["ArrowRight", "ArrowRight", 39, 39],
        ["Home", "Home", 36, 36],
        ["End", "End", 35, 35],
        ["PageUp", "PageUp", 33, 33],
        ["PageDown", "PageDown", 34, 34],
        ["Insert", "Insert", 45, 45],
        ["Delete", "Delete", 46, 46]
      ];
      navKeys.forEach(([code, key, keyCode, vk]) => {
        it(code, () => test({ code, key, keyCode }, true, (p) => {
          import_chai.assert.strictEqual(p.vk, vk);
          import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.ENHANCED_KEY);
        }));
      });
      it("Tab", () => test({ code: "Tab", key: "Tab", keyCode: 9 }, true, (p) => import_chai.assert.deepStrictEqual([p.vk, p.uc], [9, 9])));
      it("Backspace", () => test({ code: "Backspace", key: "Backspace", keyCode: 8 }, true, (p) => import_chai.assert.deepStrictEqual([p.vk, p.uc], [8, 8])));
    });
    describe("numpad keys", () => {
      it("Numpad0", () => test({ code: "Numpad0", key: "0", keyCode: 96 }, true, (p) => import_chai.assert.strictEqual(p.vk, 96)));
      it("NumpadEnter (ENHANCED)", () => test({ code: "NumpadEnter", key: "Enter", keyCode: 13 }, true, (p) => {
        import_chai.assert.strictEqual(p.vk, 13);
        import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.ENHANCED_KEY);
      }));
      it("NumpadAdd", () => test({ code: "NumpadAdd", key: "+", keyCode: 107 }, true, (p) => import_chai.assert.strictEqual(p.vk, 107)));
      it("NumpadSubtract", () => test({ code: "NumpadSubtract", key: "-", keyCode: 109 }, true, (p) => import_chai.assert.strictEqual(p.vk, 109)));
      it("NumpadMultiply", () => test({ code: "NumpadMultiply", key: "*", keyCode: 106 }, true, (p) => import_chai.assert.strictEqual(p.vk, 106)));
      it("NumpadDivide (ENHANCED)", () => test({ code: "NumpadDivide", key: "/", keyCode: 111 }, true, (p) => {
        import_chai.assert.strictEqual(p.vk, 111);
        import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.ENHANCED_KEY);
      }));
      it("NumpadDecimal", () => test({ code: "NumpadDecimal", key: ".", keyCode: 110 }, true, (p) => import_chai.assert.strictEqual(p.vk, 110)));
    });
    describe("unicode character", () => {
      it("printable", () => test({ code: "KeyA", key: "a", keyCode: 65 }, true, (p) => import_chai.assert.strictEqual(p.uc, 97)));
      it("shifted", () => test({ code: "KeyA", key: "A", keyCode: 65, shiftKey: true }, true, (p) => import_chai.assert.strictEqual(p.uc, 65)));
      it("non-printable is 0", () => test({ code: "ArrowUp", key: "ArrowUp", keyCode: 38 }, true, (p) => import_chai.assert.strictEqual(p.uc, 0)));
      it("extended ASCII", () => test({ code: "KeyE", key: "\xE9", keyCode: 69 }, true, (p) => import_chai.assert.strictEqual(p.uc, 233)));
      it("symbol", () => test({ code: "Digit4", key: "$", keyCode: 52, shiftKey: true }, true, (p) => import_chai.assert.strictEqual(p.uc, 36)));
    });
    describe("ctrl+letter control characters", () => {
      it("Ctrl+A produces 0x01", () => test({ code: "KeyA", key: "a", keyCode: 65, ctrlKey: true }, true, (p) => import_chai.assert.strictEqual(p.uc, 1)));
      it("Ctrl+C produces 0x03 (ETX)", () => test({ code: "KeyC", key: "c", keyCode: 67, ctrlKey: true }, true, (p) => import_chai.assert.strictEqual(p.uc, 3)));
      it("Ctrl+Z produces 0x1A", () => test({ code: "KeyZ", key: "z", keyCode: 90, ctrlKey: true }, true, (p) => import_chai.assert.strictEqual(p.uc, 26)));
      it("Ctrl+Shift+A (uppercase) produces 0x01", () => test({ code: "KeyA", key: "A", keyCode: 65, ctrlKey: true, shiftKey: true }, true, (p) => import_chai.assert.strictEqual(p.uc, 1)));
      it("Ctrl+Shift+C (uppercase) produces 0x03", () => test({ code: "KeyC", key: "C", keyCode: 67, ctrlKey: true, shiftKey: true }, true, (p) => import_chai.assert.strictEqual(p.uc, 3)));
      it("Ctrl+Alt+C does not produce control char", () => test({ code: "KeyC", key: "c", keyCode: 67, ctrlKey: true, altKey: true }, true, (p) => import_chai.assert.strictEqual(p.uc, 99)));
    });
    describe("scan codes", () => {
      it("letter A", () => test({ code: "KeyA", key: "a", keyCode: 65 }, true, (p) => import_chai.assert.strictEqual(p.sc, 30)));
      it("Escape", () => test({ code: "Escape", key: "Escape", keyCode: 27 }, true, (p) => import_chai.assert.strictEqual(p.sc, 1)));
    });
    describe("sequence format", () => {
      it("valid CSI format", () => {
        const result = win32.evaluateKeyboardEvent(ev({ code: "KeyA", key: "a", keyCode: 65 }), true);
        import_chai.assert.ok(result.key?.startsWith("\x1B[") && result.key.endsWith("_"));
        import_chai.assert.strictEqual(result.key?.slice(2, -1).split(";").length, 6);
      });
    });
    describe("standalone modifier keys", () => {
      it("ShiftLeft", () => test({ code: "ShiftLeft", key: "Shift", keyCode: 16, shiftKey: true }, true, (p) => {
        import_chai.assert.strictEqual(p.vk, 16);
        import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.SHIFT_PRESSED);
      }));
      it("ShiftRight", () => test({ code: "ShiftRight", key: "Shift", keyCode: 16, shiftKey: true }, true, (p) => {
        import_chai.assert.strictEqual(p.vk, 16);
        import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.SHIFT_PRESSED);
      }));
      it("ControlLeft", () => test({ code: "ControlLeft", key: "Control", keyCode: 17, ctrlKey: true }, true, (p) => {
        import_chai.assert.strictEqual(p.vk, 17);
        import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.LEFT_CTRL_PRESSED);
      }));
      it("ControlRight", () => test({ code: "ControlRight", key: "Control", keyCode: 17, ctrlKey: true }, true, (p) => {
        import_chai.assert.strictEqual(p.vk, 17);
        import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.RIGHT_CTRL_PRESSED);
        import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.ENHANCED_KEY);
      }));
      it("AltLeft", () => test({ code: "AltLeft", key: "Alt", keyCode: 18, altKey: true }, true, (p) => {
        import_chai.assert.strictEqual(p.vk, 18);
        import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.LEFT_ALT_PRESSED);
      }));
      it("AltRight", () => test({ code: "AltRight", key: "Alt", keyCode: 18, altKey: true }, true, (p) => {
        import_chai.assert.strictEqual(p.vk, 18);
        import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.RIGHT_ALT_PRESSED);
        import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.ENHANCED_KEY);
      }));
      it("modifier release", () => test({ code: "ShiftLeft", key: "Shift", keyCode: 16 }, false, (p) => import_chai.assert.strictEqual(p.kd, 0)));
    });
    describe("problem keys from spec", () => {
      it("Ctrl+Space", () => test({ code: "Space", key: " ", keyCode: 32, ctrlKey: true }, true, (p) => {
        import_chai.assert.strictEqual(p.vk, 32);
        import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.LEFT_CTRL_PRESSED);
      }));
      it("Shift+Enter", () => test({ code: "Enter", key: "Enter", keyCode: 13, shiftKey: true }, true, (p) => {
        import_chai.assert.strictEqual(p.vk, 13);
        import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.SHIFT_PRESSED);
      }));
      it("Ctrl+Break", () => test({ code: "Pause", key: "Pause", keyCode: 19, ctrlKey: true }, true, (p) => {
        import_chai.assert.strictEqual(p.vk, 19);
        import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.LEFT_CTRL_PRESSED);
      }));
      it("Ctrl+Alt+/", () => test({ code: "Slash", key: "/", keyCode: 191, ctrlKey: true, altKey: true }, true, (p) => {
        import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.LEFT_CTRL_PRESSED);
        import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.LEFT_ALT_PRESSED);
      }));
      it("Ctrl+Enter produces LF (0x0A)", () => test({ code: "Enter", key: "Enter", keyCode: 13, ctrlKey: true }, true, (p) => {
        import_chai.assert.strictEqual(p.vk, 13);
        import_chai.assert.strictEqual(p.uc, 10);
        import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.LEFT_CTRL_PRESSED);
      }));
      it("Ctrl+Backspace produces DEL (0x7F)", () => test({ code: "Backspace", key: "Backspace", keyCode: 8, ctrlKey: true }, true, (p) => {
        import_chai.assert.strictEqual(p.vk, 8);
        import_chai.assert.strictEqual(p.uc, 127);
        import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.LEFT_CTRL_PRESSED);
      }));
    });
    describe("meta key", () => {
      it("MetaLeft", () => test({ code: "MetaLeft", key: "Meta", keyCode: 91, metaKey: true }, true, (p) => {
        import_chai.assert.strictEqual(p.vk, 91);
        import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.ENHANCED_KEY);
      }));
      it("MetaRight", () => test({ code: "MetaRight", key: "Meta", keyCode: 92, metaKey: true }, true, (p) => {
        import_chai.assert.strictEqual(p.vk, 92);
        import_chai.assert.ok(p.cs & import_Win32InputMode.Win32ControlKeyState.ENHANCED_KEY);
      }));
    });
  });
});
//# sourceMappingURL=Win32InputMode.test.js.map
