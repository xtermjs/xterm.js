"use strict";
var import_chai = require("chai");
var import_KittyKeyboard = require("common/input/KittyKeyboard");
function createEvent(partialEvent = {}) {
  return {
    altKey: partialEvent.altKey || false,
    ctrlKey: partialEvent.ctrlKey || false,
    shiftKey: partialEvent.shiftKey || false,
    metaKey: partialEvent.metaKey || false,
    keyCode: partialEvent.keyCode ?? 0,
    code: partialEvent.code || "",
    key: partialEvent.key || "",
    type: partialEvent.type || "keydown"
  };
}
describe("KittyKeyboard", () => {
  let kitty;
  beforeEach(() => {
    kitty = new import_KittyKeyboard.KittyKeyboard();
  });
  describe("shouldUseProtocol", () => {
    it("should return false when flags are 0", () => {
      import_chai.assert.strictEqual(import_KittyKeyboard.KittyKeyboard.shouldUseProtocol(0), false);
    });
    it("should return true when any flag is set", () => {
      import_chai.assert.strictEqual(import_KittyKeyboard.KittyKeyboard.shouldUseProtocol(import_KittyKeyboard.KittyKeyboardFlags.DISAMBIGUATE_ESCAPE_CODES), true);
      import_chai.assert.strictEqual(import_KittyKeyboard.KittyKeyboard.shouldUseProtocol(import_KittyKeyboard.KittyKeyboardFlags.REPORT_EVENT_TYPES), true);
      import_chai.assert.strictEqual(import_KittyKeyboard.KittyKeyboard.shouldUseProtocol(31), true);
    });
  });
  describe("evaluate", () => {
    describe("modifier encoding (value = 1 + modifiers)", () => {
      const flags = import_KittyKeyboard.KittyKeyboardFlags.DISAMBIGUATE_ESCAPE_CODES;
      it("shift+letter sends plain character in DISAMBIGUATE mode", () => {
        const result = kitty.evaluate(createEvent({ key: "A", shiftKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "A");
      });
      it("alt=3 (1+2) still uses CSI u", () => {
        const result = kitty.evaluate(createEvent({ key: "a", altKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[97;3u");
      });
      it("ctrl=5 (1+4)", () => {
        const result = kitty.evaluate(createEvent({ key: "a", ctrlKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[97;5u");
      });
      it("super/meta=9 (1+8)", () => {
        const result = kitty.evaluate(createEvent({ key: "a", metaKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[97;9u");
      });
      it("ctrl+shift=6 (1+4+1)", () => {
        const result = kitty.evaluate(createEvent({ key: "a", ctrlKey: true, shiftKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[97;6u");
      });
      it("ctrl+alt=7 (1+4+2)", () => {
        const result = kitty.evaluate(createEvent({ key: "a", ctrlKey: true, altKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[97;7u");
      });
      it("ctrl+alt+shift=8 (1+4+2+1)", () => {
        const result = kitty.evaluate(createEvent({ key: "a", ctrlKey: true, altKey: true, shiftKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[97;8u");
      });
      it("ctrl+super=13 (1+4+8)", () => {
        const result = kitty.evaluate(createEvent({ key: "a", ctrlKey: true, metaKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[97;13u");
      });
      it("all four modifiers=16 (1+1+2+4+8)", () => {
        const result = kitty.evaluate(createEvent({ key: "a", shiftKey: true, altKey: true, ctrlKey: true, metaKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[97;16u");
      });
      it("no modifiers omits modifier field", () => {
        const result = kitty.evaluate(createEvent({ key: "Escape" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[27u");
      });
    });
    describe("C0 control keys with DISAMBIGUATE_ESCAPE_CODES", () => {
      const flags = import_KittyKeyboard.KittyKeyboardFlags.DISAMBIGUATE_ESCAPE_CODES;
      it("Escape \u2192 CSI 27 u", () => {
        const result = kitty.evaluate(createEvent({ key: "Escape" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[27u");
      });
      it("Enter \u2192 CSI 13 u", () => {
        const result = kitty.evaluate(createEvent({ key: "Enter" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[13u");
      });
      it("Tab \u2192 CSI 9 u", () => {
        const result = kitty.evaluate(createEvent({ key: "Tab" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[9u");
      });
      it("Backspace \u2192 CSI 127 u", () => {
        const result = kitty.evaluate(createEvent({ key: "Backspace" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[127u");
      });
      it("Space \u2192 CSI 32 u", () => {
        const result = kitty.evaluate(createEvent({ key: " " }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[32u");
      });
      it("Shift+Tab \u2192 CSI 9;2 u", () => {
        const result = kitty.evaluate(createEvent({ key: "Tab", shiftKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[9;2u");
      });
      it("Ctrl+Enter \u2192 CSI 13;5 u", () => {
        const result = kitty.evaluate(createEvent({ key: "Enter", ctrlKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[13;5u");
      });
      it("Alt+Escape \u2192 CSI 27;3 u", () => {
        const result = kitty.evaluate(createEvent({ key: "Escape", altKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[27;3u");
      });
    });
    describe("navigation keys", () => {
      const flags = import_KittyKeyboard.KittyKeyboardFlags.DISAMBIGUATE_ESCAPE_CODES;
      it("Insert \u2192 CSI 2 ~", () => {
        const result = kitty.evaluate(createEvent({ key: "Insert" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[2~");
      });
      it("Delete \u2192 CSI 3 ~", () => {
        const result = kitty.evaluate(createEvent({ key: "Delete" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[3~");
      });
      it("PageUp \u2192 CSI 5 ~", () => {
        const result = kitty.evaluate(createEvent({ key: "PageUp" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[5~");
      });
      it("PageDown \u2192 CSI 6 ~", () => {
        const result = kitty.evaluate(createEvent({ key: "PageDown" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[6~");
      });
      it("Home \u2192 CSI H", () => {
        const result = kitty.evaluate(createEvent({ key: "Home" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[H");
      });
      it("End \u2192 CSI F", () => {
        const result = kitty.evaluate(createEvent({ key: "End" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[F");
      });
      it("Shift+PageUp \u2192 CSI 5;2 ~", () => {
        const result = kitty.evaluate(createEvent({ key: "PageUp", shiftKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[5;2~");
      });
      it("Ctrl+Home \u2192 CSI 1;5 H", () => {
        const result = kitty.evaluate(createEvent({ key: "Home", ctrlKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[1;5H");
      });
    });
    describe("arrow keys", () => {
      const flags = import_KittyKeyboard.KittyKeyboardFlags.DISAMBIGUATE_ESCAPE_CODES;
      it("ArrowUp \u2192 CSI A", () => {
        const result = kitty.evaluate(createEvent({ key: "ArrowUp" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[A");
      });
      it("ArrowDown \u2192 CSI B", () => {
        const result = kitty.evaluate(createEvent({ key: "ArrowDown" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[B");
      });
      it("ArrowRight \u2192 CSI C", () => {
        const result = kitty.evaluate(createEvent({ key: "ArrowRight" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[C");
      });
      it("ArrowLeft \u2192 CSI D", () => {
        const result = kitty.evaluate(createEvent({ key: "ArrowLeft" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[D");
      });
      it("Shift+ArrowUp \u2192 CSI 1;2 A", () => {
        const result = kitty.evaluate(createEvent({ key: "ArrowUp", shiftKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[1;2A");
      });
      it("Ctrl+ArrowLeft \u2192 CSI 1;5 D", () => {
        const result = kitty.evaluate(createEvent({ key: "ArrowLeft", ctrlKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[1;5D");
      });
      it("Ctrl+Shift+ArrowRight \u2192 CSI 1;6 C", () => {
        const result = kitty.evaluate(createEvent({ key: "ArrowRight", ctrlKey: true, shiftKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[1;6C");
      });
    });
    describe("function keys F1-F12", () => {
      const flags = import_KittyKeyboard.KittyKeyboardFlags.DISAMBIGUATE_ESCAPE_CODES;
      it("F1 \u2192 CSI P (SS3 form)", () => {
        const result = kitty.evaluate(createEvent({ key: "F1" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1BOP");
      });
      it("F2 \u2192 CSI Q (SS3 form)", () => {
        const result = kitty.evaluate(createEvent({ key: "F2" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1BOQ");
      });
      it("F3 \u2192 CSI R (SS3 form)", () => {
        const result = kitty.evaluate(createEvent({ key: "F3" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1BOR");
      });
      it("F4 \u2192 CSI S (SS3 form)", () => {
        const result = kitty.evaluate(createEvent({ key: "F4" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1BOS");
      });
      it("F5 \u2192 CSI 15 ~", () => {
        const result = kitty.evaluate(createEvent({ key: "F5" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[15~");
      });
      it("F6 \u2192 CSI 17 ~", () => {
        const result = kitty.evaluate(createEvent({ key: "F6" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[17~");
      });
      it("F7 \u2192 CSI 18 ~", () => {
        const result = kitty.evaluate(createEvent({ key: "F7" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[18~");
      });
      it("F8 \u2192 CSI 19 ~", () => {
        const result = kitty.evaluate(createEvent({ key: "F8" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[19~");
      });
      it("F9 \u2192 CSI 20 ~", () => {
        const result = kitty.evaluate(createEvent({ key: "F9" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[20~");
      });
      it("F10 \u2192 CSI 21 ~", () => {
        const result = kitty.evaluate(createEvent({ key: "F10" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[21~");
      });
      it("F11 \u2192 CSI 23 ~", () => {
        const result = kitty.evaluate(createEvent({ key: "F11" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[23~");
      });
      it("F12 \u2192 CSI 24 ~", () => {
        const result = kitty.evaluate(createEvent({ key: "F12" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[24~");
      });
      it("Shift+F1 \u2192 CSI 1;2 P", () => {
        const result = kitty.evaluate(createEvent({ key: "F1", shiftKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[1;2P");
      });
      it("Ctrl+F5 \u2192 CSI 15;5 ~", () => {
        const result = kitty.evaluate(createEvent({ key: "F5", ctrlKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[15;5~");
      });
    });
    describe("extended function keys F13-F35 (Private Use Area)", () => {
      const flags = import_KittyKeyboard.KittyKeyboardFlags.DISAMBIGUATE_ESCAPE_CODES;
      it("F13 \u2192 CSI 57376 u", () => {
        const result = kitty.evaluate(createEvent({ key: "F13" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57376u");
      });
      it("F14 \u2192 CSI 57377 u", () => {
        const result = kitty.evaluate(createEvent({ key: "F14" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57377u");
      });
      it("F20 \u2192 CSI 57383 u", () => {
        const result = kitty.evaluate(createEvent({ key: "F20" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57383u");
      });
      it("F24 \u2192 CSI 57387 u", () => {
        const result = kitty.evaluate(createEvent({ key: "F24" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57387u");
      });
    });
    describe("numpad keys (Private Use Area)", () => {
      const flags = import_KittyKeyboard.KittyKeyboardFlags.DISAMBIGUATE_ESCAPE_CODES;
      it("Numpad0 \u2192 CSI 57399 u", () => {
        const result = kitty.evaluate(createEvent({ key: "0", code: "Numpad0" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57399u");
      });
      it("Numpad1 \u2192 CSI 57400 u", () => {
        const result = kitty.evaluate(createEvent({ key: "1", code: "Numpad1" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57400u");
      });
      it("Numpad9 \u2192 CSI 57408 u", () => {
        const result = kitty.evaluate(createEvent({ key: "9", code: "Numpad9" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57408u");
      });
      it("NumpadDecimal \u2192 CSI 57409 u", () => {
        const result = kitty.evaluate(createEvent({ key: ".", code: "NumpadDecimal" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57409u");
      });
      it("NumpadDivide \u2192 CSI 57410 u", () => {
        const result = kitty.evaluate(createEvent({ key: "/", code: "NumpadDivide" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57410u");
      });
      it("NumpadMultiply \u2192 CSI 57411 u", () => {
        const result = kitty.evaluate(createEvent({ key: "*", code: "NumpadMultiply" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57411u");
      });
      it("NumpadSubtract \u2192 CSI 57412 u", () => {
        const result = kitty.evaluate(createEvent({ key: "-", code: "NumpadSubtract" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57412u");
      });
      it("NumpadAdd \u2192 CSI 57413 u", () => {
        const result = kitty.evaluate(createEvent({ key: "+", code: "NumpadAdd" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57413u");
      });
      it("NumpadEnter \u2192 CSI 57414 u", () => {
        const result = kitty.evaluate(createEvent({ key: "Enter", code: "NumpadEnter" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57414u");
      });
      it("NumpadEqual \u2192 CSI 57415 u", () => {
        const result = kitty.evaluate(createEvent({ key: "=", code: "NumpadEqual" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57415u");
      });
      it("Ctrl+Numpad5 \u2192 CSI 57404;5 u", () => {
        const result = kitty.evaluate(createEvent({ key: "5", code: "Numpad5", ctrlKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57404;5u");
      });
    });
    describe("modifier keys (Private Use Area)", () => {
      const flags = import_KittyKeyboard.KittyKeyboardFlags.REPORT_ALL_KEYS_AS_ESCAPE_CODES;
      it("Left Shift \u2192 CSI 57441 u", () => {
        const result = kitty.evaluate(createEvent({ key: "Shift", code: "ShiftLeft", shiftKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57441;2u");
      });
      it("Right Shift \u2192 CSI 57447 u", () => {
        const result = kitty.evaluate(createEvent({ key: "Shift", code: "ShiftRight", shiftKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57447;2u");
      });
      it("Left Control \u2192 CSI 57442 u", () => {
        const result = kitty.evaluate(createEvent({ key: "Control", code: "ControlLeft", ctrlKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57442;5u");
      });
      it("Right Control \u2192 CSI 57448 u", () => {
        const result = kitty.evaluate(createEvent({ key: "Control", code: "ControlRight", ctrlKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57448;5u");
      });
      it("Left Alt \u2192 CSI 57443 u", () => {
        const result = kitty.evaluate(createEvent({ key: "Alt", code: "AltLeft", altKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57443;3u");
      });
      it("Right Alt \u2192 CSI 57449 u", () => {
        const result = kitty.evaluate(createEvent({ key: "Alt", code: "AltRight", altKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57449;3u");
      });
      it("Left Meta/Super \u2192 CSI 57444 u", () => {
        const result = kitty.evaluate(createEvent({ key: "Meta", code: "MetaLeft", metaKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57444;9u");
      });
      it("Right Meta/Super \u2192 CSI 57450 u", () => {
        const result = kitty.evaluate(createEvent({ key: "Meta", code: "MetaRight", metaKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57450;9u");
      });
      it("CapsLock \u2192 CSI 57358 u", () => {
        const result = kitty.evaluate(createEvent({ key: "CapsLock", code: "CapsLock" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57358u");
      });
      it("NumLock \u2192 CSI 57360 u", () => {
        const result = kitty.evaluate(createEvent({ key: "NumLock", code: "NumLock" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57360u");
      });
      it("ScrollLock \u2192 CSI 57359 u", () => {
        const result = kitty.evaluate(createEvent({ key: "ScrollLock", code: "ScrollLock" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57359u");
      });
    });
    describe("event types (press/repeat/release)", () => {
      const flags = import_KittyKeyboard.KittyKeyboardFlags.DISAMBIGUATE_ESCAPE_CODES | import_KittyKeyboard.KittyKeyboardFlags.REPORT_EVENT_TYPES;
      it("press event (default, no suffix)", () => {
        const result = kitty.evaluate(createEvent({ key: "a" }), flags, import_KittyKeyboard.KittyKeyboardEventType.PRESS);
        import_chai.assert.strictEqual(result.key, "\x1B[97u");
      });
      it("press event explicit :1 when modifiers present", () => {
        const result = kitty.evaluate(createEvent({ key: "a", ctrlKey: true }), flags, import_KittyKeyboard.KittyKeyboardEventType.PRESS);
        import_chai.assert.strictEqual(result.key, "\x1B[97;5u");
      });
      it("repeat event \u2192 :2 suffix", () => {
        const result = kitty.evaluate(createEvent({ key: "a" }), flags, import_KittyKeyboard.KittyKeyboardEventType.REPEAT);
        import_chai.assert.strictEqual(result.key, "\x1B[97;1:2u");
      });
      it("release event \u2192 :3 suffix", () => {
        const result = kitty.evaluate(createEvent({ key: "a" }), flags, import_KittyKeyboard.KittyKeyboardEventType.RELEASE);
        import_chai.assert.strictEqual(result.key, "\x1B[97;1:3u");
      });
      it("release with modifier \u2192 mod:3", () => {
        const result = kitty.evaluate(createEvent({ key: "a", ctrlKey: true }), flags, import_KittyKeyboard.KittyKeyboardEventType.RELEASE);
        import_chai.assert.strictEqual(result.key, "\x1B[97;5:3u");
      });
      it("repeat with modifier \u2192 mod:2", () => {
        const result = kitty.evaluate(createEvent({ key: "a", shiftKey: true, altKey: true }), flags, import_KittyKeyboard.KittyKeyboardEventType.REPEAT);
        import_chai.assert.strictEqual(result.key, "\x1B[97;4:2u");
      });
      it("functional key release \u2192 CSI code;1:3 ~", () => {
        const result = kitty.evaluate(createEvent({ key: "Delete" }), flags, import_KittyKeyboard.KittyKeyboardEventType.RELEASE);
        import_chai.assert.strictEqual(result.key, "\x1B[3;1:3~");
      });
      it("modifier key release includes its own bit cleared", () => {
        const result = kitty.evaluate(createEvent({ key: "Shift", code: "ShiftLeft", shiftKey: false }), flags | import_KittyKeyboard.KittyKeyboardFlags.REPORT_ALL_KEYS_AS_ESCAPE_CODES, import_KittyKeyboard.KittyKeyboardEventType.RELEASE);
        import_chai.assert.strictEqual(result.key, "\x1B[57441;1:3u");
      });
    });
    describe("modifier-only reporting", () => {
      const flags = import_KittyKeyboard.KittyKeyboardFlags.REPORT_EVENT_TYPES;
      it("does not report modifier press without REPORT_ALL_KEYS_AS_ESCAPE_CODES", () => {
        const result = kitty.evaluate(createEvent({ key: "Shift", code: "ShiftLeft", shiftKey: true }), flags);
        import_chai.assert.strictEqual(result.key, void 0);
      });
      it("does not report modifier release without REPORT_ALL_KEYS_AS_ESCAPE_CODES", () => {
        const result = kitty.evaluate(createEvent({ key: "Shift", code: "ShiftLeft", shiftKey: false }), flags, import_KittyKeyboard.KittyKeyboardEventType.RELEASE);
        import_chai.assert.strictEqual(result.key, void 0);
      });
    });
    describe("REPORT_ALL_KEYS_AS_ESCAPE_CODES flag", () => {
      const flags = import_KittyKeyboard.KittyKeyboardFlags.REPORT_ALL_KEYS_AS_ESCAPE_CODES;
      it("lowercase letter \u2192 CSI codepoint u", () => {
        const result = kitty.evaluate(createEvent({ key: "a" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[97u");
      });
      it("uppercase letter uses lowercase codepoint", () => {
        const result = kitty.evaluate(createEvent({ key: "A", shiftKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[97;2u");
      });
      it("digit \u2192 CSI codepoint u", () => {
        const result = kitty.evaluate(createEvent({ key: "5" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[53u");
      });
      it("punctuation \u2192 CSI codepoint u", () => {
        import_chai.assert.strictEqual(kitty.evaluate(createEvent({ key: "." }), flags).key, "\x1B[46u");
        import_chai.assert.strictEqual(kitty.evaluate(createEvent({ key: "," }), flags).key, "\x1B[44u");
        import_chai.assert.strictEqual(kitty.evaluate(createEvent({ key: ";" }), flags).key, "\x1B[59u");
        import_chai.assert.strictEqual(kitty.evaluate(createEvent({ key: "/" }), flags).key, "\x1B[47u");
      });
      it("brackets \u2192 CSI codepoint u", () => {
        import_chai.assert.strictEqual(kitty.evaluate(createEvent({ key: "[" }), flags).key, "\x1B[91u");
        import_chai.assert.strictEqual(kitty.evaluate(createEvent({ key: "]" }), flags).key, "\x1B[93u");
      });
      it("space \u2192 CSI 32 u", () => {
        const result = kitty.evaluate(createEvent({ key: " " }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[32u");
      });
    });
    describe("REPORT_ASSOCIATED_TEXT flag", () => {
      const flags = import_KittyKeyboard.KittyKeyboardFlags.REPORT_ALL_KEYS_AS_ESCAPE_CODES | import_KittyKeyboard.KittyKeyboardFlags.REPORT_ASSOCIATED_TEXT;
      it("regular key includes text codepoint", () => {
        const result = kitty.evaluate(createEvent({ key: "a" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[97;;97u");
      });
      it("shifted key includes shifted text", () => {
        const result = kitty.evaluate(createEvent({ key: "A", shiftKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[97;2;65u");
      });
      it("Ctrl+key omits text (control code)", () => {
        const result = kitty.evaluate(createEvent({ key: "a", ctrlKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[97;5u");
      });
      it("functional key has no text", () => {
        const result = kitty.evaluate(createEvent({ key: "Escape" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[27u");
      });
      it("release event has no text", () => {
        const flagsWithEvents = flags | import_KittyKeyboard.KittyKeyboardFlags.REPORT_EVENT_TYPES;
        const result = kitty.evaluate(createEvent({ key: "a" }), flagsWithEvents, import_KittyKeyboard.KittyKeyboardEventType.RELEASE);
        import_chai.assert.strictEqual(result.key, "\x1B[97;1:3u");
      });
      it("digit with text", () => {
        const result = kitty.evaluate(createEvent({ key: "5" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[53;;53u");
      });
      it("Shift+digit shows shifted symbol", () => {
        const result = kitty.evaluate(createEvent({ key: "%", shiftKey: true, code: "Digit5" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[53;2;37u");
      });
    });
    describe("REPORT_ALTERNATE_KEYS flag", () => {
      const flags = import_KittyKeyboard.KittyKeyboardFlags.REPORT_ALL_KEYS_AS_ESCAPE_CODES | import_KittyKeyboard.KittyKeyboardFlags.REPORT_ALTERNATE_KEYS;
      it("Shift+a includes shifted key \u2192 CSI 97:65 ; 2 u", () => {
        const result = kitty.evaluate(createEvent({ key: "A", shiftKey: true, code: "KeyA" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[97:65;2u");
      });
      it("unshifted key has no alternate", () => {
        const result = kitty.evaluate(createEvent({ key: "a", code: "KeyA" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[97u");
      });
      it("Shift+5 includes shifted key \u2192 CSI 53:37 ; 2 u", () => {
        const result = kitty.evaluate(createEvent({ key: "%", shiftKey: true, code: "Digit5" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[53:37;2u");
      });
      it("functional keys have no shifted alternate", () => {
        const result = kitty.evaluate(createEvent({ key: "Escape", shiftKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[27;2u");
      });
    });
    describe("REPORT_ALTERNATE_KEYS with REPORT_ASSOCIATED_TEXT", () => {
      const flags = import_KittyKeyboard.KittyKeyboardFlags.REPORT_ALL_KEYS_AS_ESCAPE_CODES | import_KittyKeyboard.KittyKeyboardFlags.REPORT_ALTERNATE_KEYS | import_KittyKeyboard.KittyKeyboardFlags.REPORT_ASSOCIATED_TEXT;
      it("Shift+a \u2192 CSI 97:65 ; 2 ; 65 u", () => {
        const result = kitty.evaluate(createEvent({ key: "A", shiftKey: true, code: "KeyA" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[97:65;2;65u");
      });
      it("Shift+a release \u2192 CSI 97:65 ; 2:3 u (no text)", () => {
        const flagsWithEvents = flags | import_KittyKeyboard.KittyKeyboardFlags.REPORT_EVENT_TYPES;
        const result = kitty.evaluate(createEvent({ key: "A", shiftKey: true, code: "KeyA" }), flagsWithEvents, import_KittyKeyboard.KittyKeyboardEventType.RELEASE);
        import_chai.assert.strictEqual(result.key, "\x1B[97:65;2:3u");
      });
    });
    describe("release events without REPORT_EVENT_TYPES", () => {
      const flags = import_KittyKeyboard.KittyKeyboardFlags.DISAMBIGUATE_ESCAPE_CODES;
      it("should not generate key sequence for release events", () => {
        const result = kitty.evaluate(createEvent({ key: "a" }), flags, import_KittyKeyboard.KittyKeyboardEventType.RELEASE);
        import_chai.assert.strictEqual(result.key, void 0);
      });
    });
    describe("edge cases", () => {
      const flags = import_KittyKeyboard.KittyKeyboardFlags.DISAMBIGUATE_ESCAPE_CODES;
      it("shift+letter sends plain character in DISAMBIGUATE mode", () => {
        const result = kitty.evaluate(createEvent({ key: "A", shiftKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "A");
      });
      it("ctrl+shift+a sends lowercase codepoint 97", () => {
        const result = kitty.evaluate(createEvent({ key: "A", ctrlKey: true, shiftKey: true }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[97;6u");
      });
      it("Dead key produces no output", () => {
        const result = kitty.evaluate(createEvent({ key: "Dead" }), flags);
        import_chai.assert.strictEqual(result.key, void 0);
      });
      it("Unidentified key produces no output", () => {
        const result = kitty.evaluate(createEvent({ key: "Unidentified" }), flags);
        import_chai.assert.strictEqual(result.key, void 0);
      });
      it("PrintScreen \u2192 CSI 57361 u", () => {
        const result = kitty.evaluate(createEvent({ key: "PrintScreen" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57361u");
      });
      it("Pause \u2192 CSI 57362 u", () => {
        const result = kitty.evaluate(createEvent({ key: "Pause" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57362u");
      });
      it("ContextMenu \u2192 CSI 57363 u", () => {
        const result = kitty.evaluate(createEvent({ key: "ContextMenu" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57363u");
      });
    });
    describe("media keys (Private Use Area)", () => {
      const flags = import_KittyKeyboard.KittyKeyboardFlags.DISAMBIGUATE_ESCAPE_CODES;
      it("MediaPlayPause \u2192 CSI 57430 u", () => {
        const result = kitty.evaluate(createEvent({ key: "MediaPlayPause" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57430u");
      });
      it("MediaStop \u2192 CSI 57432 u", () => {
        const result = kitty.evaluate(createEvent({ key: "MediaStop" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57432u");
      });
      it("MediaTrackNext \u2192 CSI 57435 u", () => {
        const result = kitty.evaluate(createEvent({ key: "MediaTrackNext" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57435u");
      });
      it("MediaTrackPrevious \u2192 CSI 57436 u", () => {
        const result = kitty.evaluate(createEvent({ key: "MediaTrackPrevious" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57436u");
      });
      it("AudioVolumeDown \u2192 CSI 57438 u", () => {
        const result = kitty.evaluate(createEvent({ key: "AudioVolumeDown" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57438u");
      });
      it("AudioVolumeUp \u2192 CSI 57439 u", () => {
        const result = kitty.evaluate(createEvent({ key: "AudioVolumeUp" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57439u");
      });
      it("AudioVolumeMute \u2192 CSI 57440 u", () => {
        const result = kitty.evaluate(createEvent({ key: "AudioVolumeMute" }), flags);
        import_chai.assert.strictEqual(result.key, "\x1B[57440u");
      });
    });
  });
});
//# sourceMappingURL=KittyKeyboard.test.js.map
