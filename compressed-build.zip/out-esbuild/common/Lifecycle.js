"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var Lifecycle_exports = {};
__export(Lifecycle_exports, {
  Disposable: () => Disposable,
  DisposableStore: () => DisposableStore,
  MutableDisposable: () => MutableDisposable,
  combinedDisposable: () => combinedDisposable,
  dispose: () => dispose,
  toDisposable: () => toDisposable
});
module.exports = __toCommonJS(Lifecycle_exports);
/**
 * Copyright (c) 2024-2026 The xterm.js authors. All rights reserved.
 * @license MIT
 *
 * Minimal lifecycle utilities for xterm.js core.
 * Simplified from VS Code's lifecycle.ts - no tracking/leak detection.
 */
function toDisposable(fn) {
  return { dispose: fn };
}
function dispose(arg) {
  if (!arg) {
    return arg;
  }
  if (Array.isArray(arg)) {
    for (const d of arg) {
      d.dispose();
    }
    return [];
  }
  arg.dispose();
  return arg;
}
function combinedDisposable(...disposables) {
  return toDisposable(() => dispose(disposables));
}
class DisposableStore {
  constructor() {
    this._disposables = /* @__PURE__ */ new Set();
    this._isDisposed = false;
  }
  get isDisposed() {
    return this._isDisposed;
  }
  add(o) {
    if (this._isDisposed) {
      o.dispose();
    } else {
      this._disposables.add(o);
    }
    return o;
  }
  dispose() {
    if (this._isDisposed) {
      return;
    }
    this._isDisposed = true;
    for (const d of this._disposables) {
      d.dispose();
    }
    this._disposables.clear();
  }
  clear() {
    for (const d of this._disposables) {
      d.dispose();
    }
    this._disposables.clear();
  }
}
class Disposable {
  constructor() {
    this._store = new DisposableStore();
  }
  static {
    this.None = Object.freeze({ dispose() {
    } });
  }
  dispose() {
    this._store.dispose();
  }
  _register(o) {
    return this._store.add(o);
  }
}
class MutableDisposable {
  constructor() {
    this._isDisposed = false;
  }
  get value() {
    return this._isDisposed ? void 0 : this._value;
  }
  set value(value) {
    if (this._isDisposed || value === this._value) {
      return;
    }
    this._value?.dispose();
    this._value = value;
  }
  clear() {
    this.value = void 0;
  }
  dispose() {
    this._isDisposed = true;
    this._value?.dispose();
    this._value = void 0;
  }
}
//# sourceMappingURL=Lifecycle.js.map
