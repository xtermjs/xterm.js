"use strict";
var import_chai = require("chai");
var import_TextBlinkStateManager = require("browser/renderer/shared/TextBlinkStateManager");
var import_TestUtils = require("common/TestUtils.test");
var import_Event = require("common/Event");
/**
 * Copyright (c) 2026 The xterm.js authors. All rights reserved.
 * @license MIT
 */
class FakeWindow {
  constructor() {
    this.nextId = 1;
    this.intervals = /* @__PURE__ */ new Map();
  }
  setInterval(callback, _duration) {
    const id = this.nextId++;
    this.intervals.set(id, callback);
    return id;
  }
  clearInterval(id) {
    this.intervals.delete(id);
  }
}
function createManager(duration) {
  const fakeWindow = new FakeWindow();
  let renderCount = 0;
  const coreBrowserService = {
    serviceBrand: void 0,
    isFocused: true,
    dpr: 1,
    onDprChange: new import_Event.Emitter().event,
    onWindowChange: new import_Event.Emitter().event,
    window: fakeWindow,
    mainDocument: {}
  };
  const optionsService = new import_TestUtils.MockOptionsService({ blinkIntervalDuration: duration });
  const manager = new import_TextBlinkStateManager.TextBlinkStateManager(() => {
    renderCount++;
  }, coreBrowserService, optionsService);
  return {
    manager,
    window: fakeWindow,
    getRenderCount: () => renderCount
  };
}
function getOnlyIntervalCallback(window) {
  const iterator = window.intervals.values();
  const first = iterator.next();
  import_chai.assert.ok(!first.done);
  import_chai.assert.ok(iterator.next().done);
  return first.value;
}
describe("TextBlinkStateManager", () => {
  it("starts interval only when needed", () => {
    const { manager, window } = createManager(100);
    import_chai.assert.equal(window.intervals.size, 0);
    manager.setNeedsBlinkInViewport(true);
    import_chai.assert.equal(window.intervals.size, 1);
  });
  it("stops interval and restores blink visibility when no longer needed", () => {
    const { manager, window, getRenderCount } = createManager(100);
    manager.setNeedsBlinkInViewport(true);
    const tick = getOnlyIntervalCallback(window);
    tick();
    const rendersAfterTick = getRenderCount();
    import_chai.assert.equal(manager.isBlinkOn, false);
    manager.setNeedsBlinkInViewport(false);
    import_chai.assert.equal(window.intervals.size, 0);
    import_chai.assert.equal(manager.isBlinkOn, true);
    import_chai.assert.equal(getRenderCount(), rendersAfterTick + 1);
  });
  it("pauses while viewport is hidden and resumes when visible", () => {
    const { manager, window } = createManager(100);
    manager.setNeedsBlinkInViewport(true);
    import_chai.assert.equal(window.intervals.size, 1);
    manager.setViewportVisible(false);
    import_chai.assert.equal(window.intervals.size, 0);
    manager.setViewportVisible(true);
    import_chai.assert.equal(window.intervals.size, 1);
  });
  it("does not start interval when duration is zero", () => {
    const { manager, window } = createManager(0);
    manager.setNeedsBlinkInViewport(true);
    import_chai.assert.equal(window.intervals.size, 0);
  });
});
//# sourceMappingURL=TextBlinkStateManager.test.js.map
