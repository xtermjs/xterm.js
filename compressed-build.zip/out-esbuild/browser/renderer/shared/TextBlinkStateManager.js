"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var TextBlinkStateManager_exports = {};
__export(TextBlinkStateManager_exports, {
  TextBlinkStateManager: () => TextBlinkStateManager
});
module.exports = __toCommonJS(TextBlinkStateManager_exports);
var import_Lifecycle = require("common/Lifecycle");
/**
 * Copyright (c) 2026 The xterm.js authors. All rights reserved.
 * @license MIT
 */
class TextBlinkStateManager extends import_Lifecycle.Disposable {
  constructor(_renderCallback, _coreBrowserService, _optionsService) {
    super();
    this._renderCallback = _renderCallback;
    this._coreBrowserService = _coreBrowserService;
    this._optionsService = _optionsService;
    this._intervalDuration = 0;
    this._blinkOn = true;
    this._needsBlinkInViewport = false;
    this._isViewportVisible = true;
    this._register(this._optionsService.onSpecificOptionChange("blinkIntervalDuration", (duration) => {
      this.setIntervalDuration(duration);
    }));
    this.setIntervalDuration(this._optionsService.rawOptions.blinkIntervalDuration);
    this._register((0, import_Lifecycle.toDisposable)(() => this._clearInterval()));
  }
  get isBlinkOn() {
    return this._blinkOn;
  }
  get isEnabled() {
    return this._intervalDuration > 0;
  }
  setNeedsBlinkInViewport(needsBlinkInViewport) {
    if (this._needsBlinkInViewport === needsBlinkInViewport) {
      return;
    }
    this._needsBlinkInViewport = needsBlinkInViewport;
    this._updateIntervalState();
  }
  setViewportVisible(isVisible) {
    if (this._isViewportVisible === isVisible) {
      return;
    }
    this._isViewportVisible = isVisible;
    this._updateIntervalState();
  }
  setIntervalDuration(duration) {
    if (duration === this._intervalDuration) {
      return;
    }
    this._intervalDuration = duration;
    this._clearInterval();
    this._updateIntervalState();
  }
  _updateIntervalState() {
    const shouldBlink = this._intervalDuration > 0 && this._needsBlinkInViewport && this._isViewportVisible;
    if (shouldBlink) {
      if (this._interval !== void 0) {
        return;
      }
      const wasBlinkOn = this._blinkOn;
      this._blinkOn = true;
      this._interval = this._coreBrowserService.window.setInterval(() => {
        this._blinkOn = !this._blinkOn;
        this._renderCallback();
      }, this._intervalDuration);
      if (!wasBlinkOn) {
        this._renderCallback();
      }
      return;
    }
    this._clearInterval();
    if (!this._blinkOn) {
      this._blinkOn = true;
      this._renderCallback();
    }
  }
  _clearInterval() {
    if (this._interval !== void 0) {
      this._coreBrowserService.window.clearInterval(this._interval);
      this._interval = void 0;
    }
  }
}
//# sourceMappingURL=TextBlinkStateManager.js.map
