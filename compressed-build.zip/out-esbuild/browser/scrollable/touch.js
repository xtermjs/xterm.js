"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
var touch_exports = {};
__export(touch_exports, {
  EventType: () => EventType,
  Gesture: () => Gesture
});
module.exports = __toCommonJS(touch_exports);
var DomUtils = __toESM(require("../Dom"));
var import_Lifecycle = require("common/Lifecycle");
const mainWindow = typeof window === "object" ? window : globalThis;
function tail(array, n = 0) {
  return array[array.length - (1 + n)];
}
function memoize(_target, key, descriptor) {
  let fnKey = null;
  let fn = null;
  if (typeof descriptor.value === "function") {
    fnKey = "value";
    fn = descriptor.value;
    if (fn.length !== 0) {
      console.warn("Memoize should only be used in functions with zero parameters");
    }
  } else if (typeof descriptor.get === "function") {
    fnKey = "get";
    fn = descriptor.get;
  }
  if (!fn || !fnKey) {
    throw new Error("not supported");
  }
  const memoizeKey = `$memoize$${key}`;
  const descriptorAny = descriptor;
  descriptorAny[fnKey] = function(...args) {
    if (!this.hasOwnProperty(memoizeKey)) {
      Object.defineProperty(this, memoizeKey, {
        configurable: false,
        enumerable: false,
        writable: false,
        value: fn.apply(this, args)
      });
    }
    return this[memoizeKey];
  };
}
class LinkedListNode {
  static {
    this.Undefined = new LinkedListNode(void 0);
  }
  constructor(element) {
    this.element = element;
    this.next = LinkedListNode.Undefined;
    this.prev = LinkedListNode.Undefined;
  }
}
class LinkedList {
  constructor() {
    this._first = LinkedListNode.Undefined;
    this._last = LinkedListNode.Undefined;
  }
  push(element) {
    return this._insert(element, true);
  }
  _insert(element, atTheEnd) {
    const newNode = new LinkedListNode(element);
    if (this._first === LinkedListNode.Undefined) {
      this._first = newNode;
      this._last = newNode;
    } else if (atTheEnd) {
      const oldLast = this._last;
      this._last = newNode;
      newNode.prev = oldLast;
      oldLast.next = newNode;
    } else {
      const oldFirst = this._first;
      this._first = newNode;
      newNode.next = oldFirst;
      oldFirst.prev = newNode;
    }
    let didRemove = false;
    return () => {
      if (!didRemove) {
        didRemove = true;
        this._remove(newNode);
      }
    };
  }
  _remove(node) {
    if (node.prev !== LinkedListNode.Undefined && node.next !== LinkedListNode.Undefined) {
      const anchor = node.prev;
      anchor.next = node.next;
      node.next.prev = anchor;
    } else if (node.prev === LinkedListNode.Undefined && node.next === LinkedListNode.Undefined) {
      this._first = LinkedListNode.Undefined;
      this._last = LinkedListNode.Undefined;
    } else if (node.next === LinkedListNode.Undefined) {
      this._last = this._last.prev;
      this._last.next = LinkedListNode.Undefined;
    } else if (node.prev === LinkedListNode.Undefined) {
      this._first = this._first.next;
      this._first.prev = LinkedListNode.Undefined;
    }
  }
  *[Symbol.iterator]() {
    let node = this._first;
    while (node !== LinkedListNode.Undefined) {
      yield node.element;
      node = node.next;
    }
  }
}
var EventType;
((EventType2) => {
  EventType2.TAP = "-xterm-gesturetap";
  EventType2.CHANGE = "-xterm-gesturechange";
  EventType2.START = "-xterm-gesturestart";
  EventType2.END = "-xterm-gesturesend";
  EventType2.CONTEXT_MENU = "-xterm-gesturecontextmenu";
})(EventType || (EventType = {}));
const _Gesture = class _Gesture extends import_Lifecycle.Disposable {
  // ms
  constructor() {
    super();
    this._dispatched = false;
    this._targets = new LinkedList();
    this._ignoreTargets = new LinkedList();
    this._activeTouches = {};
    this._handle = null;
    this._lastSetTapCountTime = 0;
    const targetWindow = mainWindow;
    this._register(DomUtils.addDisposableListener(targetWindow.document, "touchstart", (e) => this._handleTouchStart(e), { passive: false }));
    this._register(DomUtils.addDisposableListener(targetWindow.document, "touchend", (e) => this._handleTouchEnd(targetWindow, e)));
    this._register(DomUtils.addDisposableListener(targetWindow.document, "touchmove", (e) => this._handleTouchMove(e), { passive: false }));
  }
  static {
    this._scrollFriction = -5e-3;
  }
  static {
    this._holdDelay = 700;
  }
  static {
    this._clearTapCountTime = 400;
  }
  static addTarget(element) {
    if (!_Gesture.isTouchDevice()) {
      return import_Lifecycle.Disposable.None;
    }
    if (!_Gesture._instance) {
      _Gesture._instance = new _Gesture();
    }
    const remove = _Gesture._instance._targets.push(element);
    return (0, import_Lifecycle.toDisposable)(remove);
  }
  static ignoreTarget(element) {
    if (!_Gesture.isTouchDevice()) {
      return import_Lifecycle.Disposable.None;
    }
    if (!_Gesture._instance) {
      _Gesture._instance = new _Gesture();
    }
    const remove = _Gesture._instance._ignoreTargets.push(element);
    return (0, import_Lifecycle.toDisposable)(remove);
  }
  static isTouchDevice() {
    return "ontouchstart" in mainWindow || navigator.maxTouchPoints > 0;
  }
  dispose() {
    if (this._handle) {
      this._handle.dispose();
      this._handle = null;
    }
    super.dispose();
  }
  _handleTouchStart(e) {
    const timestamp = Date.now();
    if (this._handle) {
      this._handle.dispose();
      this._handle = null;
    }
    for (let i = 0, len = e.targetTouches.length; i < len; i++) {
      const touch = e.targetTouches.item(i);
      this._activeTouches[touch.identifier] = {
        id: touch.identifier,
        initialTarget: touch.target,
        initialTimeStamp: timestamp,
        initialPageX: touch.pageX,
        initialPageY: touch.pageY,
        rollingTimestamps: [timestamp],
        rollingPageX: [touch.pageX],
        rollingPageY: [touch.pageY]
      };
      const evt = this._newGestureEvent(EventType.START, touch.target);
      evt.pageX = touch.pageX;
      evt.pageY = touch.pageY;
      this._dispatchEvent(evt);
    }
    if (this._dispatched) {
      e.preventDefault();
      e.stopPropagation();
      this._dispatched = false;
    }
  }
  _handleTouchEnd(targetWindow, e) {
    const timestamp = Date.now();
    const activeTouchCount = Object.keys(this._activeTouches).length;
    for (let i = 0, len = e.changedTouches.length; i < len; i++) {
      const touch = e.changedTouches.item(i);
      if (!this._activeTouches.hasOwnProperty(String(touch.identifier))) {
        console.warn("move of an UNKNOWN touch", touch);
        continue;
      }
      const data = this._activeTouches[touch.identifier];
      const holdTime = Date.now() - data.initialTimeStamp;
      if (holdTime < _Gesture._holdDelay && Math.abs(data.initialPageX - tail(data.rollingPageX)) < 30 && Math.abs(data.initialPageY - tail(data.rollingPageY)) < 30) {
        const evt = this._newGestureEvent(EventType.TAP, data.initialTarget);
        evt.pageX = tail(data.rollingPageX);
        evt.pageY = tail(data.rollingPageY);
        this._dispatchEvent(evt);
      } else if (holdTime >= _Gesture._holdDelay && Math.abs(data.initialPageX - tail(data.rollingPageX)) < 30 && Math.abs(data.initialPageY - tail(data.rollingPageY)) < 30) {
        const evt = this._newGestureEvent(EventType.CONTEXT_MENU, data.initialTarget);
        evt.pageX = tail(data.rollingPageX);
        evt.pageY = tail(data.rollingPageY);
        this._dispatchEvent(evt);
      } else if (activeTouchCount === 1) {
        const finalX = tail(data.rollingPageX);
        const finalY = tail(data.rollingPageY);
        const deltaT = tail(data.rollingTimestamps) - data.rollingTimestamps[0];
        const deltaX = finalX - data.rollingPageX[0];
        const deltaY = finalY - data.rollingPageY[0];
        const dispatchTo = [...this._targets].filter((t) => data.initialTarget instanceof Node && t.contains(data.initialTarget));
        this._inertia(
          targetWindow,
          dispatchTo,
          timestamp,
          Math.abs(deltaX) / deltaT,
          deltaX > 0 ? 1 : -1,
          finalX,
          Math.abs(deltaY) / deltaT,
          deltaY > 0 ? 1 : -1,
          finalY
        );
      }
      this._dispatchEvent(this._newGestureEvent(EventType.END, data.initialTarget));
      delete this._activeTouches[touch.identifier];
    }
    if (this._dispatched) {
      e.preventDefault();
      e.stopPropagation();
      this._dispatched = false;
    }
  }
  _newGestureEvent(type, initialTarget) {
    const event = document.createEvent("CustomEvent");
    event.initEvent(type, false, true);
    event.initialTarget = initialTarget;
    event.tapCount = 0;
    return event;
  }
  _dispatchEvent(event) {
    if (event.type === EventType.TAP) {
      const currentTime = (/* @__PURE__ */ new Date()).getTime();
      let setTapCount = 0;
      if (currentTime - this._lastSetTapCountTime > _Gesture._clearTapCountTime) {
        setTapCount = 1;
      } else {
        setTapCount = 2;
      }
      this._lastSetTapCountTime = currentTime;
      event.tapCount = setTapCount;
    } else if (event.type === EventType.CHANGE || event.type === EventType.CONTEXT_MENU) {
      this._lastSetTapCountTime = 0;
    }
    if (event.initialTarget instanceof Node) {
      for (const ignoreTarget of this._ignoreTargets) {
        if (ignoreTarget.contains(event.initialTarget)) {
          return;
        }
      }
      const targets = [];
      for (const target of this._targets) {
        if (target.contains(event.initialTarget)) {
          let depth = 0;
          let now = event.initialTarget;
          while (now && now !== target) {
            depth++;
            now = now.parentElement;
          }
          targets.push([depth, target]);
        }
      }
      targets.sort((a, b) => a[0] - b[0]);
      for (const [, target] of targets) {
        target.dispatchEvent(event);
        this._dispatched = true;
      }
    }
  }
  _inertia(targetWindow, dispatchTo, t1, vX, dirX, x, vY, dirY, y) {
    this._handle = DomUtils.scheduleAtNextAnimationFrame(targetWindow, () => {
      const now = Date.now();
      const deltaT = now - t1;
      let deltaPosX = 0;
      let deltaPosY = 0;
      let stopped = true;
      vX += _Gesture._scrollFriction * deltaT;
      vY += _Gesture._scrollFriction * deltaT;
      if (vX > 0) {
        stopped = false;
        deltaPosX = dirX * vX * deltaT;
      }
      if (vY > 0) {
        stopped = false;
        deltaPosY = dirY * vY * deltaT;
      }
      const evt = this._newGestureEvent(EventType.CHANGE);
      evt.translationX = deltaPosX;
      evt.translationY = deltaPosY;
      dispatchTo.forEach((d) => d.dispatchEvent(evt));
      if (!stopped) {
        this._inertia(targetWindow, dispatchTo, now, vX, dirX, x + deltaPosX, vY, dirY, y + deltaPosY);
      }
    });
  }
  _handleTouchMove(e) {
    const timestamp = Date.now();
    for (let i = 0, len = e.changedTouches.length; i < len; i++) {
      const touch = e.changedTouches.item(i);
      if (!this._activeTouches.hasOwnProperty(String(touch.identifier))) {
        console.warn("end of an UNKNOWN touch", touch);
        continue;
      }
      const data = this._activeTouches[touch.identifier];
      const evt = this._newGestureEvent(EventType.CHANGE, data.initialTarget);
      evt.translationX = touch.pageX - tail(data.rollingPageX);
      evt.translationY = touch.pageY - tail(data.rollingPageY);
      evt.pageX = touch.pageX;
      evt.pageY = touch.pageY;
      this._dispatchEvent(evt);
      if (data.rollingPageX.length > 3) {
        data.rollingPageX.shift();
        data.rollingPageY.shift();
        data.rollingTimestamps.shift();
      }
      data.rollingPageX.push(touch.pageX);
      data.rollingPageY.push(touch.pageY);
      data.rollingTimestamps.push(timestamp);
    }
    if (this._dispatched) {
      e.preventDefault();
      e.stopPropagation();
      this._dispatched = false;
    }
  }
};
__decorateClass([
  memoize
], _Gesture, "isTouchDevice", 1);
let Gesture = _Gesture;
//# sourceMappingURL=touch.js.map
