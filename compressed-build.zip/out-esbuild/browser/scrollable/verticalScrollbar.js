"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var verticalScrollbar_exports = {};
__export(verticalScrollbar_exports, {
  VerticalScrollbar: () => VerticalScrollbar
});
module.exports = __toCommonJS(verticalScrollbar_exports);
var import_abstractScrollbar = require("./abstractScrollbar");
var import_scrollbarState = require("./scrollbarState");
var import_scrollable = require("./scrollable");
class VerticalScrollbar extends import_abstractScrollbar.AbstractScrollbar {
  constructor(scrollable, options, host) {
    const scrollDimensions = scrollable.getScrollDimensions();
    const scrollPosition = scrollable.getCurrentScrollPosition();
    const hasArrows = options.verticalHasArrows;
    super({
      lazyRender: options.lazyRender,
      host,
      scrollbarState: new import_scrollbarState.ScrollbarState(
        hasArrows ? options.verticalScrollbarSize : 0,
        options.vertical === import_scrollable.ScrollbarVisibility.HIDDEN ? 0 : options.verticalScrollbarSize,
        0,
        scrollDimensions.height,
        scrollDimensions.scrollHeight,
        scrollPosition.scrollTop
      ),
      visibility: options.vertical,
      extraScrollbarClassName: "xterm-vertical",
      scrollable,
      scrollByPage: options.scrollByPage
    });
    this._arrowScrollDelta = 0;
    this._setArrows(hasArrows, options.verticalScrollbarSize);
    this._createSlider(0, Math.floor((options.verticalScrollbarSize - options.verticalSliderSize) / 2), options.verticalSliderSize, void 0);
  }
  _updateSlider(sliderSize, sliderPosition) {
    this.slider.setHeight(sliderSize);
    this.slider.setTop(sliderPosition);
  }
  _renderDomNode(largeSize, smallSize) {
    this.domNode.setWidth(smallSize);
    this.domNode.setHeight(largeSize);
    this.domNode.setRight(0);
    this.domNode.setTop(0);
  }
  handleScroll(e) {
    this._shouldRender = this._handleElementScrollSize(e.scrollHeight) || this._shouldRender;
    this._shouldRender = this._handleElementScrollPosition(e.scrollTop) || this._shouldRender;
    this._shouldRender = this._handleElementSize(e.height) || this._shouldRender;
    return this._shouldRender;
  }
  _pointerDownRelativePosition(offsetX, offsetY) {
    return offsetY;
  }
  _sliderPointerPosition(e) {
    return e.pageY;
  }
  _sliderOrthogonalPointerPosition(e) {
    return e.pageX;
  }
  _updateScrollbarSize(size) {
    this.slider.setWidth(size);
  }
  writeScrollPosition(target, scrollPosition) {
    target.scrollTop = scrollPosition;
  }
  _arrowScroll(delta) {
    const currentPosition = this._scrollable.getCurrentScrollPosition();
    this._scrollable.setScrollPositionNow({ scrollTop: currentPosition.scrollTop + delta });
  }
  _setArrows(showArrows, size) {
    this._arrowScrollDelta = size;
    if (!this._arrowUp || !this._arrowDown) {
      const arrowDelta = 0;
      this._arrowUp = this._createArrow({
        className: "xterm-scra xterm-arrow-up",
        top: arrowDelta,
        left: arrowDelta,
        bgWidth: size,
        bgHeight: size,
        handleActivate: () => this._arrowScroll(-this._arrowScrollDelta)
      });
      this._arrowDown = this._createArrow({
        className: "xterm-scra xterm-arrow-down",
        bottom: arrowDelta,
        left: arrowDelta,
        bgWidth: size,
        bgHeight: size,
        handleActivate: () => this._arrowScroll(this._arrowScrollDelta)
      });
    }
    this._updateArrowSize(this._arrowUp, size);
    this._updateArrowSize(this._arrowDown, size);
    if (!this._arrowUp || !this._arrowDown) {
      return;
    }
    const display = showArrows ? "" : "none";
    this._arrowUp.bgDomNode.style.display = display;
    this._arrowUp.domNode.style.display = display;
    this._arrowDown.bgDomNode.style.display = display;
    this._arrowDown.domNode.style.display = display;
  }
  _updateArrowSize(arrow, size) {
    if (!arrow) {
      return;
    }
    arrow.bgDomNode.style.width = `${size}px`;
    arrow.bgDomNode.style.height = `${size}px`;
    arrow.domNode.style.width = `${size}px`;
    arrow.domNode.style.height = `${size}px`;
  }
  updateOptions(options) {
    const arrowSize = options.verticalHasArrows ? options.verticalScrollbarSize : 0;
    this._scrollbarState.setArrowSize(arrowSize);
    this._setArrows(options.verticalHasArrows, options.verticalScrollbarSize);
    this.updateScrollbarSize(options.vertical === import_scrollable.ScrollbarVisibility.HIDDEN ? 0 : options.verticalScrollbarSize);
    this._scrollbarState.setOppositeScrollbarSize(0);
    this._visibilityController.setVisibility(options.vertical);
    this._scrollByPage = options.scrollByPage;
  }
}
//# sourceMappingURL=verticalScrollbar.js.map
