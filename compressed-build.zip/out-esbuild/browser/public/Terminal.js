"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var Terminal_exports = {};
__export(Terminal_exports, {
  Terminal: () => Terminal
});
module.exports = __toCommonJS(Terminal_exports);
var Strings = __toESM(require("browser/LocalizableStrings"));
var import_CoreBrowserTerminal = require("browser/CoreBrowserTerminal");
var import_Lifecycle = require("common/Lifecycle");
var import_AddonManager = require("common/public/AddonManager");
var import_BufferNamespaceApi = require("common/public/BufferNamespaceApi");
var import_ParserApi = require("common/public/ParserApi");
var import_UnicodeApi = require("common/public/UnicodeApi");
/**
 * Copyright (c) 2018 The xterm.js authors. All rights reserved.
 * @license MIT
 */
const CONSTRUCTOR_ONLY_OPTIONS = ["cols", "rows"];
let $value = 0;
class Terminal extends import_Lifecycle.Disposable {
  constructor(options) {
    super();
    this._core = this._register(new import_CoreBrowserTerminal.CoreBrowserTerminal(options));
    this._addonManager = this._register(new import_AddonManager.AddonManager());
    this._publicOptions = { ...this._core.options };
    const getter = (propName) => {
      return this._core.options[propName];
    };
    const setter = (propName, value) => {
      this._checkReadonlyOptions(propName);
      this._core.options[propName] = value;
    };
    for (const propName in this._core.options) {
      const desc = {
        get: getter.bind(this, propName),
        set: setter.bind(this, propName)
      };
      Object.defineProperty(this._publicOptions, propName, desc);
    }
  }
  _checkReadonlyOptions(propName) {
    if (CONSTRUCTOR_ONLY_OPTIONS.includes(propName)) {
      throw new Error(`Option "${propName}" can only be set in the constructor`);
    }
  }
  _checkProposedApi() {
    if (!this._core.optionsService.rawOptions.allowProposedApi) {
      throw new Error("You must set the allowProposedApi option to true to use proposed API");
    }
  }
  get onBell() {
    return this._core.onBell;
  }
  get onBinary() {
    return this._core.onBinary;
  }
  get onCursorMove() {
    return this._core.onCursorMove;
  }
  get onData() {
    return this._core.onData;
  }
  get onKey() {
    return this._core.onKey;
  }
  get onLineFeed() {
    return this._core.onLineFeed;
  }
  get onRender() {
    return this._core.onRender;
  }
  get onResize() {
    return this._core.onResize;
  }
  get onScroll() {
    return this._core.onScroll;
  }
  get onSelectionChange() {
    return this._core.onSelectionChange;
  }
  get onTitleChange() {
    return this._core.onTitleChange;
  }
  get onWriteParsed() {
    return this._core.onWriteParsed;
  }
  get onDimensionsChange() {
    return this._core.onDimensionsChange;
  }
  get element() {
    return this._core.element;
  }
  get screenElement() {
    return this._core.screenElement;
  }
  get parser() {
    return this._parser ??= new import_ParserApi.ParserApi(this._core);
  }
  get unicode() {
    this._checkProposedApi();
    return new import_UnicodeApi.UnicodeApi(this._core);
  }
  get textarea() {
    return this._core.textarea;
  }
  get rows() {
    return this._core.rows;
  }
  get cols() {
    return this._core.cols;
  }
  get buffer() {
    return this._buffer ??= this._register(new import_BufferNamespaceApi.BufferNamespaceApi(this._core));
  }
  get markers() {
    return this._core.markers;
  }
  get modes() {
    const m = this._core.coreService.decPrivateModes;
    let mouseTrackingMode = "none";
    switch (this._core.coreMouseService.activeProtocol) {
      case "X10":
        mouseTrackingMode = "x10";
        break;
      case "VT200":
        mouseTrackingMode = "vt200";
        break;
      case "DRAG":
        mouseTrackingMode = "drag";
        break;
      case "ANY":
        mouseTrackingMode = "any";
        break;
    }
    return {
      applicationCursorKeysMode: m.applicationCursorKeys,
      applicationKeypadMode: m.applicationKeypad,
      bracketedPasteMode: m.bracketedPasteMode,
      insertMode: this._core.coreService.modes.insertMode,
      mouseTrackingMode,
      originMode: m.origin,
      reverseWraparoundMode: m.reverseWraparound,
      sendFocusMode: m.sendFocus,
      showCursor: !this._core.coreService.isCursorHidden,
      synchronizedOutputMode: m.synchronizedOutput,
      win32InputMode: m.win32InputMode,
      wraparoundMode: m.wraparound
    };
  }
  get dimensions() {
    return this._core.dimensions;
  }
  get options() {
    return this._publicOptions;
  }
  set options(options) {
    for (const propName in options) {
      this._publicOptions[propName] = options[propName];
    }
  }
  blur() {
    this._core.blur();
  }
  focus() {
    this._core.focus();
  }
  input(data, wasUserInput = true) {
    this._core.input(data, wasUserInput);
  }
  resize(columns, rows) {
    this._verifyIntegers(columns, rows);
    this._core.resize(columns, rows);
  }
  open(parent) {
    this._core.open(parent);
  }
  attachCustomKeyEventHandler(customKeyEventHandler) {
    this._core.attachCustomKeyEventHandler(customKeyEventHandler);
  }
  attachCustomWheelEventHandler(customWheelEventHandler) {
    this._core.attachCustomWheelEventHandler(customWheelEventHandler);
  }
  registerLinkProvider(linkProvider) {
    return this._core.registerLinkProvider(linkProvider);
  }
  registerCharacterJoiner(handler) {
    return this._core.registerCharacterJoiner(handler);
  }
  deregisterCharacterJoiner(joinerId) {
    this._core.deregisterCharacterJoiner(joinerId);
  }
  registerMarker(cursorYOffset = 0) {
    this._verifyIntegers(cursorYOffset);
    return this._core.registerMarker(cursorYOffset);
  }
  registerDecoration(decorationOptions) {
    this._verifyPositiveIntegers(decorationOptions.x ?? 0, decorationOptions.width ?? 0, decorationOptions.height ?? 0);
    return this._core.registerDecoration(decorationOptions);
  }
  hasSelection() {
    return this._core.hasSelection();
  }
  select(column, row, length) {
    this._verifyIntegers(column, row, length);
    this._core.select(column, row, length);
  }
  getSelection() {
    return this._core.getSelection();
  }
  getSelectionPosition() {
    return this._core.getSelectionPosition();
  }
  clearSelection() {
    this._core.clearSelection();
  }
  selectAll() {
    this._core.selectAll();
  }
  selectLines(start, end) {
    this._verifyIntegers(start, end);
    this._core.selectLines(start, end);
  }
  dispose() {
    super.dispose();
  }
  scrollLines(amount) {
    this._verifyIntegers(amount);
    this._core.scrollLines(amount);
  }
  scrollPages(pageCount) {
    this._verifyIntegers(pageCount);
    this._core.scrollPages(pageCount);
  }
  scrollToTop() {
    this._core.scrollToTop();
  }
  scrollToBottom() {
    this._core.scrollToBottom();
  }
  scrollToLine(line) {
    this._verifyIntegers(line);
    this._core.scrollToLine(line);
  }
  clear() {
    this._core.clear();
  }
  write(data, callback) {
    this._core.write(data, callback);
  }
  writeln(data, callback) {
    this._core.write(data);
    this._core.write("\r\n", callback);
  }
  paste(data) {
    this._core.paste(data);
  }
  refresh(start, end) {
    this._verifyIntegers(start, end);
    this._core.refresh(start, end);
  }
  reset() {
    this._core.reset();
  }
  clearTextureAtlas() {
    this._core.clearTextureAtlas();
  }
  loadAddon(addon) {
    this._addonManager.loadAddon(this, addon);
  }
  static get strings() {
    return {
      get promptLabel() {
        return Strings.promptLabel.get();
      },
      set promptLabel(value) {
        Strings.promptLabel.set(value);
      },
      get tooMuchOutput() {
        return Strings.tooMuchOutput.get();
      },
      set tooMuchOutput(value) {
        Strings.tooMuchOutput.set(value);
      }
    };
  }
  _verifyIntegers(...values) {
    for ($value of values) {
      if ($value === Infinity || isNaN($value) || $value % 1 !== 0) {
        throw new Error("This API only accepts integers");
      }
    }
  }
  _verifyPositiveIntegers(...values) {
    for ($value of values) {
      if ($value && ($value === Infinity || isNaN($value) || $value % 1 !== 0 || $value < 0)) {
        throw new Error("This API only accepts positive integers");
      }
    }
  }
}
//# sourceMappingURL=Terminal.js.map
