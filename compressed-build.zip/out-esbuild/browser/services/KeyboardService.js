"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
var __decorateParam = (index, decorator) => (target, key) => decorator(target, key, index);
var KeyboardService_exports = {};
__export(KeyboardService_exports, {
  KeyboardService: () => KeyboardService
});
module.exports = __toCommonJS(KeyboardService_exports);
var import_Keyboard = require("common/input/Keyboard");
var import_KittyKeyboard = require("common/input/KittyKeyboard");
var import_Win32InputMode = require("common/input/Win32InputMode");
var import_Platform = require("common/Platform");
var import_Services2 = require("common/services/Services");
/**
 * Copyright (c) 2025 The xterm.js authors. All rights reserved.
 * @license MIT
 */
let KeyboardService = class {
  constructor(_coreService, _optionsService) {
    this._coreService = _coreService;
    this._optionsService = _optionsService;
  }
  _getWin32InputMode() {
    this._win32InputMode ??= new import_Win32InputMode.Win32InputMode();
    return this._win32InputMode;
  }
  _getKittyKeyboard() {
    this._kittyKeyboard ??= new import_KittyKeyboard.KittyKeyboard();
    return this._kittyKeyboard;
  }
  evaluateKeyDown(event) {
    if (this.useWin32InputMode) {
      return this._getWin32InputMode().evaluateKeyboardEvent(event, true);
    }
    const kittyFlags = this._coreService.kittyKeyboard.flags;
    return this.useKitty ? this._getKittyKeyboard().evaluate(event, kittyFlags, event.repeat ? import_KittyKeyboard.KittyKeyboardEventType.REPEAT : import_KittyKeyboard.KittyKeyboardEventType.PRESS) : (0, import_Keyboard.evaluateKeyboardEvent)(event, this._coreService.decPrivateModes.applicationCursorKeys, import_Platform.isMac, this._optionsService.rawOptions.macOptionIsMeta);
  }
  evaluateKeyUp(event) {
    if (this.useWin32InputMode) {
      return this._getWin32InputMode().evaluateKeyboardEvent(event, false);
    }
    const kittyFlags = this._coreService.kittyKeyboard.flags;
    if (this.useKitty && kittyFlags & import_KittyKeyboard.KittyKeyboardFlags.REPORT_EVENT_TYPES) {
      return this._getKittyKeyboard().evaluate(event, kittyFlags, import_KittyKeyboard.KittyKeyboardEventType.RELEASE);
    }
    return void 0;
  }
  get useKitty() {
    const kittyFlags = this._coreService.kittyKeyboard.flags;
    return !!(this._optionsService.rawOptions.vtExtensions?.kittyKeyboard && import_KittyKeyboard.KittyKeyboard.shouldUseProtocol(kittyFlags));
  }
  get useWin32InputMode() {
    return !!(this._optionsService.rawOptions.vtExtensions?.win32InputMode && this._coreService.decPrivateModes.win32InputMode);
  }
};
KeyboardService = __decorateClass([
  __decorateParam(0, import_Services2.ICoreService),
  __decorateParam(1, import_Services2.IOptionsService)
], KeyboardService);
//# sourceMappingURL=KeyboardService.js.map
