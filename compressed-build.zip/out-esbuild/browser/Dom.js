"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var Dom_exports = {};
__export(Dom_exports, {
  WindowIntervalTimer: () => WindowIntervalTimer,
  addDisposableListener: () => addDisposableListener,
  addStandardDisposableListener: () => addStandardDisposableListener,
  eventType: () => eventType,
  getDomNodePagePosition: () => getDomNodePagePosition,
  getWindow: () => getWindow,
  scheduleAtNextAnimationFrame: () => scheduleAtNextAnimationFrame
});
module.exports = __toCommonJS(Dom_exports);
var import_Async = require("common/Async");
/**
 * Copyright (c) 2026 The xterm.js authors. All rights reserved.
 * @license MIT
 *
 * Minimal DOM helpers for xterm.js browser code.
 */
function getWindow(e) {
  const candidateNode = e;
  if (candidateNode?.ownerDocument?.defaultView) {
    return candidateNode.ownerDocument.defaultView;
  }
  const candidateEvent = e;
  if (candidateEvent?.view) {
    return candidateEvent.view;
  }
  return window;
}
class DomListener {
  constructor(node, type, handler, options) {
    this._node = node;
    this._type = type;
    this._handler = handler;
    this._options = options;
    node.addEventListener(type, handler, options);
  }
  dispose() {
    if (!this._node || !this._handler) {
      return;
    }
    this._node.removeEventListener(this._type, this._handler, this._options);
    this._node = null;
    this._handler = null;
  }
}
function addDisposableListener(node, type, handler, useCaptureOrOptions) {
  return new DomListener(node, type, handler, useCaptureOrOptions);
}
function addStandardDisposableListener(node, type, handler, useCapture) {
  return addDisposableListener(node, type, handler, useCapture);
}
const eventType = {
  CLICK: "click",
  MOUSE_DOWN: "mousedown",
  MOUSE_OVER: "mouseover",
  MOUSE_LEAVE: "mouseleave",
  KEY_DOWN: "keydown",
  KEY_UP: "keyup",
  INPUT: "input",
  BLUR: "blur",
  FOCUS: "focus",
  CHANGE: "change",
  POINTER_DOWN: "pointerdown",
  POINTER_MOVE: "pointermove",
  POINTER_UP: "pointerup",
  MOUSE_WHEEL: "wheel",
  WHEEL: "wheel"
};
function getDomNodePagePosition(domNode) {
  const bb = domNode.getBoundingClientRect();
  const win = getWindow(domNode);
  return {
    left: bb.left + win.scrollX,
    top: bb.top + win.scrollY,
    width: bb.width,
    height: bb.height
  };
}
class AnimationFrameQueueItem {
  constructor(_runner, priority) {
    this._runner = _runner;
    this.priority = priority;
    this._canceled = false;
  }
  dispose() {
    this._canceled = true;
  }
  execute() {
    if (this._canceled) {
      return;
    }
    try {
      this._runner();
    } catch (e) {
      console.error(e);
    }
  }
  static sort(a, b) {
    return b.priority - a.priority;
  }
}
const animationFrameState = /* @__PURE__ */ new Map();
function getAnimationFrameState(targetWindow) {
  let state = animationFrameState.get(targetWindow);
  if (!state) {
    state = {
      next: [],
      current: [],
      animFrameRequested: false,
      inAnimationFrameRunner: false
    };
    animationFrameState.set(targetWindow, state);
  }
  return state;
}
function animationFrameRunner(targetWindow) {
  const state = getAnimationFrameState(targetWindow);
  state.animFrameRequested = false;
  state.current = state.next;
  state.next = [];
  state.inAnimationFrameRunner = true;
  while (state.current.length > 0) {
    state.current.sort(AnimationFrameQueueItem.sort);
    const top = state.current.shift();
    top.execute();
  }
  state.inAnimationFrameRunner = false;
}
function scheduleAtNextAnimationFrame(targetWindow, runner, priority = 0) {
  const state = getAnimationFrameState(targetWindow);
  const item = new AnimationFrameQueueItem(runner, priority);
  state.next.push(item);
  if (!state.animFrameRequested) {
    state.animFrameRequested = true;
    targetWindow.requestAnimationFrame(() => animationFrameRunner(targetWindow));
  }
  return item;
}
class WindowIntervalTimer extends import_Async.IntervalTimer {
  constructor(node) {
    super();
    this._defaultTarget = node ? getWindow(node) : void 0;
  }
  cancelAndSet(runner, interval, targetWindow) {
    super.cancelAndSet(runner, interval, targetWindow ?? this._defaultTarget ?? window);
  }
}
//# sourceMappingURL=Dom.js.map
