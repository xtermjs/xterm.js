"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var import_test = __toESM(require("@playwright/test"));
var import_assert = require("assert");
var import_TestUtils = require("../../../test/playwright/TestUtils");
/**
 * Copyright (c) 2024 The xterm.js authors. All rights reserved.
 * @license MIT
 */
let ctx;
import_test.default.beforeAll(async ({ browser }) => {
  ctx = await (0, import_TestUtils.createTestContext)(browser);
  ctx.page.setViewportSize({ width: 1024, height: 768 });
  await (0, import_TestUtils.openTerminal)(ctx);
});
import_test.default.afterAll(async () => await ctx.page.close());
import_test.default.describe("ProgressAddon", () => {
  import_test.default.beforeEach(async function() {
    await ctx.page.evaluate(`
      window.progressStack = [];
      window.term.reset();
      window.progressAddon?.dispose();
      window.progressAddon = new ProgressAddon();
      window.term.loadAddon(window.progressAddon);
      window.progressAddon.onChange(progress => window.progressStack.push(progress));
    `);
  });
  (0, import_test.default)("initial values should be 0;0", async () => {
    (0, import_assert.deepStrictEqual)(await ctx.page.evaluate("window.progressAddon.progress"), { state: 0, value: 0 });
  });
  (0, import_test.default)("state 0: remove", async () => {
    await ctx.proxy.write("\x1B]9;4;0\x1B\\");
    (0, import_assert.deepStrictEqual)(await ctx.page.evaluate("window.progressStack"), [{ state: 0, value: 0 }]);
    await ctx.proxy.write("\x1B]9;4;0;12\x1B\\");
    (0, import_assert.deepStrictEqual)(await ctx.page.evaluate("window.progressStack"), [{ state: 0, value: 0 }, { state: 0, value: 0 }]);
  });
  (0, import_test.default)("state 1: set", async () => {
    await ctx.proxy.write("\x1B]9;4;1;10\x1B\\");
    (0, import_assert.deepStrictEqual)(await ctx.page.evaluate("window.progressStack"), [{ state: 1, value: 10 }]);
    await ctx.proxy.write("\x1B]9;4;1;50\x1B\\");
    (0, import_assert.deepStrictEqual)(await ctx.page.evaluate("window.progressStack"), [{ state: 1, value: 10 }, { state: 1, value: 50 }]);
    await ctx.proxy.write("\x1B]9;4;1;23\x1B\\");
    (0, import_assert.deepStrictEqual)(await ctx.page.evaluate("window.progressStack"), [{ state: 1, value: 10 }, { state: 1, value: 50 }, { state: 1, value: 23 }]);
  });
  (0, import_test.default)("state 1: set - special sequence handling", async () => {
    await ctx.proxy.write("\x1B]9;4;1\x1B\\");
    (0, import_assert.deepStrictEqual)(await ctx.page.evaluate("window.progressStack"), [{ state: 1, value: 0 }]);
    await ctx.proxy.write("\x1B]9;4;1;12x\x1B\\");
    (0, import_assert.deepStrictEqual)(await ctx.page.evaluate("window.progressStack"), [{ state: 1, value: 0 }]);
    await ctx.proxy.write("\x1B]9;4;1;123\x1B\\");
    (0, import_assert.deepStrictEqual)(await ctx.page.evaluate("window.progressStack"), [{ state: 1, value: 0 }, { state: 1, value: 100 }]);
  });
  (0, import_test.default)("state 2: error - preserve previous value on empty/0", async () => {
    await ctx.proxy.write("\x1B]9;4;1;12\x1B\\");
    await ctx.proxy.write("\x1B]9;4;2\x1B\\");
    await ctx.proxy.write("\x1B]9;4;2;\x1B\\");
    await ctx.proxy.write("\x1B]9;4;2;0\x1B\\");
    (0, import_assert.deepStrictEqual)(
      await ctx.page.evaluate("window.progressStack"),
      [{ state: 1, value: 12 }, { state: 2, value: 12 }, { state: 2, value: 12 }, { state: 2, value: 12 }]
    );
  });
  (0, import_test.default)("state 2: error - with new value", async () => {
    await ctx.proxy.write("\x1B]9;4;1;12\x1B\\");
    await ctx.proxy.write("\x1B]9;4;2;25\x1B\\");
    await ctx.proxy.write("\x1B]9;4;2;123\x1B\\");
    (0, import_assert.deepStrictEqual)(
      await ctx.page.evaluate("window.progressStack"),
      [{ state: 1, value: 12 }, { state: 2, value: 25 }, { state: 2, value: 100 }]
    );
  });
  (0, import_test.default)("state 3: indeterminate - keeps value untouched", async () => {
    await ctx.proxy.write("\x1B]9;4;1;12\x1B\\");
    await ctx.proxy.write("\x1B]9;4;3\x1B\\");
    await ctx.proxy.write("\x1B]9;4;3;123\x1B\\");
    (0, import_assert.deepStrictEqual)(
      await ctx.page.evaluate("window.progressStack"),
      [{ state: 1, value: 12 }, { state: 3, value: 12 }, { state: 3, value: 12 }]
    );
  });
  (0, import_test.default)("state 4: pause - preserve previous value on empty/0", async () => {
    await ctx.proxy.write("\x1B]9;4;1;12\x1B\\");
    await ctx.proxy.write("\x1B]9;4;4\x1B\\");
    await ctx.proxy.write("\x1B]9;4;4;\x1B\\");
    await ctx.proxy.write("\x1B]9;4;4;0\x1B\\");
    (0, import_assert.deepStrictEqual)(
      await ctx.page.evaluate("window.progressStack"),
      [{ state: 1, value: 12 }, { state: 4, value: 12 }, { state: 4, value: 12 }, { state: 4, value: 12 }]
    );
  });
  (0, import_test.default)("state 4: pause - with new value", async () => {
    await ctx.proxy.write("\x1B]9;4;1;12\x1B\\");
    await ctx.proxy.write("\x1B]9;4;4;25\x1B\\");
    await ctx.proxy.write("\x1B]9;4;4;123\x1B\\");
    (0, import_assert.deepStrictEqual)(
      await ctx.page.evaluate("window.progressStack"),
      [{ state: 1, value: 12 }, { state: 4, value: 25 }, { state: 4, value: 100 }]
    );
  });
  (0, import_test.default)("invalid sequences should not emit anything", async () => {
    await ctx.proxy.write("\x1B]9;4;5;12\x1B\\");
    await ctx.proxy.write("\x1B]9;4;1; 123xxxx\x1B\\");
    (0, import_assert.deepStrictEqual)(await ctx.page.evaluate("window.progressStack"), []);
  });
});
//# sourceMappingURL=ProgressAddon.test.js.map
