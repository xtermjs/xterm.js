"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var ProgressAddon_exports = {};
__export(ProgressAddon_exports, {
  ProgressAddon: () => ProgressAddon
});
module.exports = __toCommonJS(ProgressAddon_exports);
/**
 * Copyright (c) 2024 The xterm.js authors. All rights reserved.
 * @license MIT
 */
var ProgressType = /* @__PURE__ */ ((ProgressType2) => {
  ProgressType2[ProgressType2["REMOVE"] = 0] = "REMOVE";
  ProgressType2[ProgressType2["SET"] = 1] = "SET";
  ProgressType2[ProgressType2["ERROR"] = 2] = "ERROR";
  ProgressType2[ProgressType2["INDETERMINATE"] = 3] = "INDETERMINATE";
  ProgressType2[ProgressType2["PAUSE"] = 4] = "PAUSE";
  return ProgressType2;
})(ProgressType || {});
function toInt(s) {
  let v = 0;
  for (let i = 0; i < s.length; ++i) {
    const c = s.charCodeAt(i);
    if (c < 48 || 57 < c) {
      return -1;
    }
    v = v * 10 + c - 48;
  }
  return v;
}
class ProgressAddon {
  constructor() {
    this._st = 0 /* REMOVE */;
    this._pr = 0;
  }
  dispose() {
    this._seqHandler?.dispose();
    this._onChange?.dispose();
  }
  activate(terminal) {
    this._seqHandler = terminal.parser.registerOscHandler(9, (data) => {
      if (!data.startsWith("4;")) {
        return false;
      }
      const parts = data.split(";");
      if (parts.length > 3) {
        return true;
      }
      if (parts.length === 2) {
        parts.push("");
      }
      const st = toInt(parts[1]);
      const pr = toInt(parts[2]);
      switch (st) {
        case 0 /* REMOVE */:
          this.progress = { state: st, value: 0 };
          break;
        case 1 /* SET */:
          if (pr < 0) return true;
          this.progress = { state: st, value: pr };
          break;
        case 2 /* ERROR */:
        case 4 /* PAUSE */:
          if (pr < 0) return true;
          this.progress = { state: st, value: pr || this._pr };
          break;
        case 3 /* INDETERMINATE */:
          this.progress = { state: st, value: this._pr };
          break;
      }
      return true;
    });
    this._onChange = new terminal._core._onData.constructor();
    this.onChange = this._onChange.event;
  }
  get progress() {
    return { state: this._st, value: this._pr };
  }
  set progress(progress) {
    if (progress.state < 0 || progress.state > 4) {
      console.warn(`progress state out of bounds, not applied`);
      return;
    }
    this._st = progress.state;
    this._pr = Math.min(Math.max(progress.value, 0), 100);
    this._onChange?.fire({ state: this._st, value: this._pr });
  }
}
//# sourceMappingURL=ProgressAddon.js.map
