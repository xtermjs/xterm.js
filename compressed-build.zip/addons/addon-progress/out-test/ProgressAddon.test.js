"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const test_1 = __importDefault(require("@playwright/test"));
const assert_1 = require("assert");
const TestUtils_1 = require("../../../test/playwright/TestUtils");
let ctx;
test_1.default.beforeAll(async ({ browser }) => {
    ctx = await (0, TestUtils_1.createTestContext)(browser);
    ctx.page.setViewportSize({ width: 1024, height: 768 });
    await (0, TestUtils_1.openTerminal)(ctx);
});
test_1.default.afterAll(async () => await ctx.page.close());
test_1.default.describe('ProgressAddon', () => {
    test_1.default.beforeEach(async function () {
        await ctx.page.evaluate(`
      window.progressStack = [];
      window.term.reset();
      window.progressAddon?.dispose();
      window.progressAddon = new ProgressAddon();
      window.term.loadAddon(window.progressAddon);
      window.progressAddon.onChange(progress => window.progressStack.push(progress));
    `);
    });
    (0, test_1.default)('initial values should be 0;0', async () => {
        (0, assert_1.deepStrictEqual)(await ctx.page.evaluate('window.progressAddon.progress'), { state: 0, value: 0 });
    });
    (0, test_1.default)('state 0: remove', async () => {
        await ctx.proxy.write('\x1b]9;4;0\x1b\\');
        (0, assert_1.deepStrictEqual)(await ctx.page.evaluate('window.progressStack'), [{ state: 0, value: 0 }]);
        await ctx.proxy.write('\x1b]9;4;0;12\x1b\\');
        (0, assert_1.deepStrictEqual)(await ctx.page.evaluate('window.progressStack'), [{ state: 0, value: 0 }, { state: 0, value: 0 }]);
    });
    (0, test_1.default)('state 1: set', async () => {
        await ctx.proxy.write('\x1b]9;4;1;10\x1b\\');
        (0, assert_1.deepStrictEqual)(await ctx.page.evaluate('window.progressStack'), [{ state: 1, value: 10 }]);
        await ctx.proxy.write('\x1b]9;4;1;50\x1b\\');
        (0, assert_1.deepStrictEqual)(await ctx.page.evaluate('window.progressStack'), [{ state: 1, value: 10 }, { state: 1, value: 50 }]);
        await ctx.proxy.write('\x1b]9;4;1;23\x1b\\');
        (0, assert_1.deepStrictEqual)(await ctx.page.evaluate('window.progressStack'), [{ state: 1, value: 10 }, { state: 1, value: 50 }, { state: 1, value: 23 }]);
    });
    (0, test_1.default)('state 1: set - special sequence handling', async () => {
        await ctx.proxy.write('\x1b]9;4;1\x1b\\');
        (0, assert_1.deepStrictEqual)(await ctx.page.evaluate('window.progressStack'), [{ state: 1, value: 0 }]);
        await ctx.proxy.write('\x1b]9;4;1;12x\x1b\\');
        (0, assert_1.deepStrictEqual)(await ctx.page.evaluate('window.progressStack'), [{ state: 1, value: 0 }]);
        await ctx.proxy.write('\x1b]9;4;1;123\x1b\\');
        (0, assert_1.deepStrictEqual)(await ctx.page.evaluate('window.progressStack'), [{ state: 1, value: 0 }, { state: 1, value: 100 }]);
    });
    (0, test_1.default)('state 2: error - preserve previous value on empty/0', async () => {
        await ctx.proxy.write('\x1b]9;4;1;12\x1b\\');
        await ctx.proxy.write('\x1b]9;4;2\x1b\\');
        await ctx.proxy.write('\x1b]9;4;2;\x1b\\');
        await ctx.proxy.write('\x1b]9;4;2;0\x1b\\');
        (0, assert_1.deepStrictEqual)(await ctx.page.evaluate('window.progressStack'), [{ state: 1, value: 12 }, { state: 2, value: 12 }, { state: 2, value: 12 }, { state: 2, value: 12 }]);
    });
    (0, test_1.default)('state 2: error - with new value', async () => {
        await ctx.proxy.write('\x1b]9;4;1;12\x1b\\');
        await ctx.proxy.write('\x1b]9;4;2;25\x1b\\');
        await ctx.proxy.write('\x1b]9;4;2;123\x1b\\');
        (0, assert_1.deepStrictEqual)(await ctx.page.evaluate('window.progressStack'), [{ state: 1, value: 12 }, { state: 2, value: 25 }, { state: 2, value: 100 }]);
    });
    (0, test_1.default)('state 3: indeterminate - keeps value untouched', async () => {
        await ctx.proxy.write('\x1b]9;4;1;12\x1b\\');
        await ctx.proxy.write('\x1b]9;4;3\x1b\\');
        await ctx.proxy.write('\x1b]9;4;3;123\x1b\\');
        (0, assert_1.deepStrictEqual)(await ctx.page.evaluate('window.progressStack'), [{ state: 1, value: 12 }, { state: 3, value: 12 }, { state: 3, value: 12 }]);
    });
    (0, test_1.default)('state 4: pause - preserve previous value on empty/0', async () => {
        await ctx.proxy.write('\x1b]9;4;1;12\x1b\\');
        await ctx.proxy.write('\x1b]9;4;4\x1b\\');
        await ctx.proxy.write('\x1b]9;4;4;\x1b\\');
        await ctx.proxy.write('\x1b]9;4;4;0\x1b\\');
        (0, assert_1.deepStrictEqual)(await ctx.page.evaluate('window.progressStack'), [{ state: 1, value: 12 }, { state: 4, value: 12 }, { state: 4, value: 12 }, { state: 4, value: 12 }]);
    });
    (0, test_1.default)('state 4: pause - with new value', async () => {
        await ctx.proxy.write('\x1b]9;4;1;12\x1b\\');
        await ctx.proxy.write('\x1b]9;4;4;25\x1b\\');
        await ctx.proxy.write('\x1b]9;4;4;123\x1b\\');
        (0, assert_1.deepStrictEqual)(await ctx.page.evaluate('window.progressStack'), [{ state: 1, value: 12 }, { state: 4, value: 25 }, { state: 4, value: 100 }]);
    });
    (0, test_1.default)('invalid sequences should not emit anything', async () => {
        await ctx.proxy.write('\x1b]9;4;5;12\x1b\\');
        await ctx.proxy.write('\x1b]9;4;1; 123xxxx\x1b\\');
        (0, assert_1.deepStrictEqual)(await ctx.page.evaluate('window.progressStack'), []);
    });
});
//# sourceMappingURL=ProgressAddon.test.js.map