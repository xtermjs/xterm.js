"use strict";
/**
 * Copyright (c) 2023 The xterm.js authors. All rights reserved.
 * @license MIT
 *
 * UnicodeVersionProvider for V15 with grapeme cluster handleing.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnicodeGraphemesAddon = void 0;
const UnicodeGraphemeProvider_1 = require("./UnicodeGraphemeProvider");
class UnicodeGraphemesAddon {
    _provider15Graphemes;
    _provider15;
    _unicode;
    _oldVersion = '';
    activate(terminal) {
        var _a, _b;
        (_a = this._provider15) !== null && _a !== void 0 ? _a : (this._provider15 = new UnicodeGraphemeProvider_1.UnicodeGraphemeProvider(false));
        (_b = this._provider15Graphemes) !== null && _b !== void 0 ? _b : (this._provider15Graphemes = new UnicodeGraphemeProvider_1.UnicodeGraphemeProvider(true));
        const unicode = terminal.unicode;
        this._unicode = unicode;
        unicode.register(this._provider15);
        unicode.register(this._provider15Graphemes);
        this._oldVersion = unicode.activeVersion;
        unicode.activeVersion = '15-graphemes';
    }
    dispose() {
        if (this._unicode) {
            this._unicode.activeVersion = this._oldVersion;
        }
    }
}
exports.UnicodeGraphemesAddon = UnicodeGraphemesAddon;
