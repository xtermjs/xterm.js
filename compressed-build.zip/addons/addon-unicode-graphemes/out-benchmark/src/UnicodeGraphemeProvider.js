"use strict";
/**
 * Copyright (c) 2023 The xterm.js authors. All rights reserved.
 * @license MIT
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnicodeGraphemeProvider = void 0;
const UnicodeService_1 = require("common/services/UnicodeService");
const UC = __importStar(require("./third-party/UnicodeProperties"));
class UnicodeGraphemeProvider {
    version;
    ambiguousCharsAreWide = false;
    handleGraphemes;
    constructor(handleGraphemes = true) {
        this.version = handleGraphemes ? '15-graphemes' : '15';
        this.handleGraphemes = handleGraphemes;
    }
    static _plainNarrowProperties = UnicodeService_1.UnicodeService.createPropertyValue(UC.GRAPHEME_BREAK_Other, 1, false);
    charProperties(codepoint, preceding) {
        // Optimize the simple ASCII case, under the condition that
        // UnicodeService.extractCharKind(preceding) === GRAPHEME_BREAK_Other
        // (which also covers the case that preceding === 0).
        if ((codepoint >= 32 && codepoint < 127) && (preceding >> 3) === 0) {
            return UnicodeGraphemeProvider._plainNarrowProperties;
        }
        let charInfo = UC.getInfo(codepoint);
        let w = UC.infoToWidthInfo(charInfo);
        let shouldJoin = false;
        if (w >= 2) {
            // Treat emoji_presentation_selector as WIDE.
            w = w === 3 || this.ambiguousCharsAreWide || codepoint === 0xfe0f ? 2 : 1;
        }
        else {
            w = 1;
        }
        if (preceding !== 0) {
            const oldWidth = UnicodeService_1.UnicodeService.extractWidth(preceding);
            if (this.handleGraphemes) {
                charInfo = UC.shouldJoin(UnicodeService_1.UnicodeService.extractCharKind(preceding), charInfo);
            }
            else {
                charInfo = w === 0 ? 1 : 0;
            }
            shouldJoin = charInfo > 0;
            if (shouldJoin) {
                if (oldWidth > w) {
                    w = oldWidth;
                }
                else if (charInfo === 32) { // UC.GRAPHEME_BREAK_SAW_Regional_Pair)
                    w = 2;
                }
            }
        }
        return UnicodeService_1.UnicodeService.createPropertyValue(charInfo, w, shouldJoin);
    }
    wcwidth(codepoint) {
        const charInfo = UC.getInfo(codepoint);
        const w = UC.infoToWidthInfo(charInfo);
        const kind = (charInfo & UC.GRAPHEME_BREAK_MASK) >> UC.GRAPHEME_BREAK_SHIFT;
        if (kind === UC.GRAPHEME_BREAK_Extend || kind === UC.GRAPHEME_BREAK_Prepend) {
            return 0;
        }
        if (w >= 2 && (w === 3 || this.ambiguousCharsAreWide)) {
            return 2;
        }
        return 1;
    }
}
exports.UnicodeGraphemeProvider = UnicodeGraphemeProvider;
