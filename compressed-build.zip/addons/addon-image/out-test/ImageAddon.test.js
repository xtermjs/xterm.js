"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const test_1 = __importDefault(require("@playwright/test"));
const fs_1 = require("fs");
const sixel_1 = require("sixel");
const TestUtils_1 = require("../../../test/playwright/TestUtils");
const assert_1 = require("assert");
const TESTDATA = (() => {
    const data8 = (0, fs_1.readFileSync)('./addons/addon-image/fixture/palette.blob');
    const data32 = new Uint32Array(data8.buffer);
    const palette = new Set();
    for (let i = 0; i < data32.length; ++i)
        palette.add(data32[i]);
    const sixel = (0, sixel_1.sixelEncode)(data8, 640, 80, [...palette]);
    return {
        width: 640,
        height: 80,
        bytes: data8,
        palette: [...palette],
        sixel
    };
})();
const SIXEL_SEQ_0 = (0, sixel_1.introducer)(0) + TESTDATA.sixel + sixel_1.FINALIZER;
const TESTDATA_IIP = [
    [(0, fs_1.readFileSync)('./addons/addon-image/fixture/iip/palette.iip', { encoding: 'utf-8' }), [640, 80]],
    [(0, fs_1.readFileSync)('./addons/addon-image/fixture/iip/spinfox.iip', { encoding: 'utf-8' }), [148, 148]],
    [(0, fs_1.readFileSync)('./addons/addon-image/fixture/iip/w3c_gif.iip', { encoding: 'utf-8' }), [72, 48]],
    [(0, fs_1.readFileSync)('./addons/addon-image/fixture/iip/w3c_jpg.iip', { encoding: 'utf-8' }), [72, 48]],
    [(0, fs_1.readFileSync)('./addons/addon-image/fixture/iip/w3c_png.iip', { encoding: 'utf-8' }), [72, 48]]
];
let ctx;
test_1.default.beforeAll(async ({ browser }) => {
    ctx = await (0, TestUtils_1.createTestContext)(browser);
    await (0, TestUtils_1.openTerminal)(ctx, { cols: 80, rows: 24 });
});
test_1.default.afterAll(async () => await ctx.page.close());
test_1.default.describe('ImageAddon', () => {
    test_1.default.beforeEach(async ({}, testInfo) => {
        if (ctx.browser.browserType().name() === 'webkit') {
            testInfo.skip();
            return;
        }
        await ctx.page.evaluate(`
      window.term.reset()
      window.imageAddon?.dispose();
      window.imageAddon = new ImageAddon({ sixelPaletteLimit: 512 });
      window.term.loadAddon(window.imageAddon);
    `);
    });
    (0, test_1.default)('test for private accessors', async () => {
        const accessors = [
            '_core',
            '_core._renderService',
            '_core._inputHandler',
            '_core._inputHandler._parser',
            '_core._inputHandler._curAttrData',
            '_core._inputHandler._dirtyRowTracker',
            '_core._themeService.colors',
            '_core._coreBrowserService'
        ];
        for (const prop of accessors) {
            (0, assert_1.strictEqual)(await ctx.page.evaluate('(() => { const v = window.term.' + prop + '; return v !== undefined && v !== null; })()'), true, `problem at ${prop}`);
        }
        (0, assert_1.strictEqual)(await ctx.page.evaluate('window.term._core.buffer.lines.get(0)._data instanceof Uint32Array'), true);
        (0, assert_1.strictEqual)(await ctx.page.evaluate('window.term._core.buffer.lines.get(0)._extendedAttrs instanceof Object'), true);
        (0, assert_1.strictEqual)(await ctx.page.evaluate('window.term._core._inputHandler._curAttrData.constructor.name'), '_AttributeData');
        (0, assert_1.strictEqual)(await ctx.page.evaluate('window.term._core._inputHandler._parser.constructor.name'), 'EscapeSequenceParser');
    });
    test_1.default.describe('ctor options', () => {
        (0, test_1.default)('empty settings should load defaults', async () => {
            const DEFAULT_OPTIONS = {
                enableSizeReports: true,
                pixelLimit: 16777216,
                sixelSupport: true,
                sixelScrolling: true,
                sixelPaletteLimit: 512, // set to 512 to get example image working
                sixelSizeLimit: 25000000,
                storageLimit: 128,
                showPlaceholder: true,
                iipSupport: true,
                iipSizeLimit: 20000000,
                kittySupport: true,
                kittySizeLimit: 20000000
            };
            (0, assert_1.deepStrictEqual)(await ctx.page.evaluate(`window.imageAddon._opts`), DEFAULT_OPTIONS);
        });
        (0, test_1.default)('custom settings should overload defaults', async () => {
            const customSettings = {
                enableSizeReports: false,
                pixelLimit: 5,
                sixelSupport: false,
                sixelScrolling: false,
                sixelPaletteLimit: 1024,
                sixelSizeLimit: 1000,
                storageLimit: 10,
                showPlaceholder: false,
                iipSupport: false,
                iipSizeLimit: 1000,
                kittySupport: false,
                kittySizeLimit: 1000
            };
            await ctx.page.evaluate(opts => {
                window.imageAddonCustom = new ImageAddon(opts.opts);
                window.term.loadAddon(window.imageAddonCustom);
            }, { opts: customSettings });
            (0, assert_1.deepStrictEqual)(await ctx.page.evaluate(`window.imageAddonCustom._opts`), customSettings);
        });
    });
    test_1.default.describe('scrolling & cursor modes', () => {
        (0, test_1.default)('testdata default (scrolling with VT240 cursor pos)', async () => {
            const dim = await getDimensions();
            await ctx.proxy.write(SIXEL_SEQ_0);
            (0, assert_1.deepStrictEqual)(await getCursor(), [0, Math.floor(TESTDATA.height / dim.cellHeight)]);
            await ctx.proxy.write('#'.repeat(10) + SIXEL_SEQ_0);
            (0, assert_1.deepStrictEqual)(await getCursor(), [10, Math.floor(TESTDATA.height / dim.cellHeight) * 2]);
        });
        (0, test_1.default)('write testdata noScrolling', async () => {
            await ctx.proxy.write('\x1b[?80h' + SIXEL_SEQ_0);
            (0, assert_1.deepStrictEqual)(await getCursor(), [0, 0]);
            await ctx.proxy.write(SIXEL_SEQ_0);
            (0, assert_1.deepStrictEqual)(await getCursor(), [0, 0]);
        });
        (0, test_1.default)('testdata cursor always at VT240 pos', async () => {
            const dim = await getDimensions();
            await ctx.proxy.write(SIXEL_SEQ_0);
            (0, assert_1.deepStrictEqual)(await getCursor(), [0, Math.floor(TESTDATA.height / dim.cellHeight)]);
            await ctx.proxy.write('#'.repeat(10) + SIXEL_SEQ_0);
            (0, assert_1.deepStrictEqual)(await getCursor(), [10, Math.floor(TESTDATA.height / dim.cellHeight) * 2]);
            await ctx.proxy.write('#'.repeat(30) + SIXEL_SEQ_0);
            (0, assert_1.deepStrictEqual)(await getCursor(), [10 + 30, Math.floor(TESTDATA.height / dim.cellHeight) * 3]);
        });
    });
    test_1.default.describe('image lifecycle & eviction', () => {
        (0, test_1.default)('delete image once scrolled off', async () => {
            await ctx.proxy.write(SIXEL_SEQ_0);
            (0, TestUtils_1.pollFor)(ctx.page, 'window.imageAddon._storage._images.size', 1);
            await ctx.page.evaluate(scrollback => new Promise(res => window.term.write('\n'.repeat(scrollback), res)), (await getScrollbackPlusRows() - 1));
            await (0, TestUtils_1.timeout)(100);
            (0, TestUtils_1.pollFor)(ctx.page, 'window.imageAddon._storage._images.size', 1);
            await ctx.page.evaluate(() => new Promise(res => window.term.write('\n', res)));
            (0, TestUtils_1.pollFor)(ctx.page, 'window.imageAddon._storage._images.size', 0);
        });
        (0, test_1.default)('get storageUsage', async () => {
            (0, assert_1.strictEqual)(await ctx.page.evaluate('window.imageAddon.storageUsage'), 0);
            await ctx.proxy.write(SIXEL_SEQ_0);
            (0, assert_1.ok)(Math.abs((await ctx.page.evaluate('window.imageAddon.storageUsage')) - 640 * 80 * 4 / 1000000) < 0.05);
        });
        (0, test_1.default)('get/set storageLimit', async () => {
            (0, assert_1.strictEqual)(await ctx.page.evaluate('window.imageAddon.storageLimit'), 128);
            (0, assert_1.strictEqual)(await ctx.page.evaluate('window.imageAddon.storageLimit = 1'), 1);
            (0, assert_1.strictEqual)(await ctx.page.evaluate('window.imageAddon.storageLimit'), 1);
        });
        (0, test_1.default)('remove images by storage limit pressure', async () => {
            (0, assert_1.strictEqual)(await ctx.page.evaluate('window.imageAddon.storageLimit = 1'), 1);
            await ctx.proxy.write(SIXEL_SEQ_0);
            await ctx.proxy.write(SIXEL_SEQ_0);
            await ctx.proxy.write(SIXEL_SEQ_0);
            await ctx.proxy.write(SIXEL_SEQ_0);
            await (0, TestUtils_1.timeout)(100);
            const usage = await ctx.page.evaluate('window.imageAddon.storageUsage');
            await ctx.proxy.write(SIXEL_SEQ_0);
            await ctx.proxy.write(SIXEL_SEQ_0);
            await ctx.proxy.write(SIXEL_SEQ_0);
            await ctx.proxy.write(SIXEL_SEQ_0);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await ctx.page.evaluate('window.imageAddon.storageUsage'), usage);
            (0, assert_1.strictEqual)(usage < 1, true);
        });
        (0, test_1.default)('set storageLimit removes images synchronously', async () => {
            await ctx.proxy.write(SIXEL_SEQ_0 + SIXEL_SEQ_0 + SIXEL_SEQ_0);
            const usage = await ctx.page.evaluate('window.imageAddon.storageUsage');
            const newUsage = await ctx.page.evaluate('window.imageAddon.storageLimit = 0.5; window.imageAddon.storageUsage');
            (0, assert_1.strictEqual)(newUsage < usage, true);
            (0, assert_1.strictEqual)(newUsage < 0.5, true);
        });
        (0, test_1.default)('clear alternate images on buffer change', async () => {
            (0, assert_1.strictEqual)(await ctx.page.evaluate('window.imageAddon.storageUsage'), 0);
            await ctx.proxy.write('\x1b[?1049h' + SIXEL_SEQ_0);
            (0, assert_1.ok)(Math.abs((await ctx.page.evaluate('window.imageAddon.storageUsage')) - 640 * 80 * 4 / 1000000) < 0.05);
            await ctx.proxy.write('\x1b[?1049l');
            (0, assert_1.strictEqual)(await ctx.page.evaluate('window.imageAddon.storageUsage'), 0);
        });
        (0, test_1.default)('evict tiles by in-place overwrites (only full overwrite tested)', async () => {
            await (0, TestUtils_1.timeout)(50);
            await ctx.proxy.write('\x1b[H' + SIXEL_SEQ_0 + '\x1b[100;100H');
            await (0, TestUtils_1.timeout)(50);
            let usage = await ctx.page.evaluate('window.imageAddon.storageUsage');
            while (usage === 0) {
                await (0, TestUtils_1.timeout)(50);
                usage = await ctx.page.evaluate('window.imageAddon.storageUsage');
            }
            await ctx.proxy.write('\x1b[H' + SIXEL_SEQ_0 + '\x1b[100;100H');
            await (0, TestUtils_1.timeout)(200);
            (0, assert_1.strictEqual)(await ctx.page.evaluate('window.imageAddon.storageUsage'), usage);
        });
        (0, test_1.default)('manual eviction on alternate buffer must not miss images', async () => {
            await ctx.proxy.write('\x1b[?1049h');
            await ctx.proxy.write(SIXEL_SEQ_0 + SIXEL_SEQ_0 + SIXEL_SEQ_0 + SIXEL_SEQ_0 + SIXEL_SEQ_0 + SIXEL_SEQ_0);
            await (0, TestUtils_1.timeout)(100);
            const usage = await ctx.page.evaluate('window.imageAddon.storageUsage');
            await ctx.proxy.write(SIXEL_SEQ_0 + SIXEL_SEQ_0 + SIXEL_SEQ_0 + SIXEL_SEQ_0 + SIXEL_SEQ_0 + SIXEL_SEQ_0);
            await ctx.proxy.write(SIXEL_SEQ_0 + SIXEL_SEQ_0 + SIXEL_SEQ_0 + SIXEL_SEQ_0 + SIXEL_SEQ_0 + SIXEL_SEQ_0);
            await (0, TestUtils_1.timeout)(100);
            const newUsage = await ctx.page.evaluate('window.imageAddon.storageUsage');
            (0, assert_1.strictEqual)(newUsage, usage);
        });
    });
    test_1.default.describe('IIP support - testimages', () => {
        (0, test_1.default)('palette.png', async () => {
            await ctx.proxy.write(TESTDATA_IIP[0][0]);
            (0, assert_1.deepStrictEqual)(await getOrigSize(1), TESTDATA_IIP[0][1]);
        });
        (0, test_1.default)('spinfox.png', async () => {
            await ctx.proxy.write(TESTDATA_IIP[1][0]);
            (0, assert_1.deepStrictEqual)(await getOrigSize(1), TESTDATA_IIP[1][1]);
        });
        (0, test_1.default)('w3c gif', async () => {
            await ctx.proxy.write(TESTDATA_IIP[2][0]);
            (0, assert_1.deepStrictEqual)(await getOrigSize(1), TESTDATA_IIP[2][1]);
        });
        (0, test_1.default)('w3c jpeg', async () => {
            await ctx.proxy.write(TESTDATA_IIP[3][0]);
            (0, assert_1.deepStrictEqual)(await getOrigSize(1), TESTDATA_IIP[3][1]);
        });
        (0, test_1.default)('w3c png', async () => {
            await ctx.proxy.write(TESTDATA_IIP[4][0]);
            (0, assert_1.deepStrictEqual)(await getOrigSize(1), TESTDATA_IIP[4][1]);
        });
    });
});
async function getDimensions() {
    const dimensions = await ctx.page.evaluate(`term.dimensions`);
    return {
        cellWidth: Math.round(dimensions.css.cell.width),
        cellHeight: Math.round(dimensions.css.cell.height),
        width: Math.round(dimensions.css.canvas.width),
        height: Math.round(dimensions.css.canvas.height)
    };
}
async function getCursor() {
    return ctx.page.evaluate('[window.term.buffer.active.cursorX, window.term.buffer.active.cursorY]');
}
async function getImageStorageLength() {
    return ctx.page.evaluate('window.imageAddon._storage._images.size');
}
async function getScrollbackPlusRows() {
    return ctx.page.evaluate('window.term.options.scrollback + window.term.rows');
}
async function getOrigSize(id) {
    return ctx.page.evaluate(`[
    window.imageAddon._storage._images.get(${id}).orig.width,
    window.imageAddon._storage._images.get(${id}).orig.height
  ]`);
}
//# sourceMappingURL=ImageAddon.test.js.map