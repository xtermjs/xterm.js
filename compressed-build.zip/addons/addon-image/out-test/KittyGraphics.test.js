"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const test_1 = __importDefault(require("@playwright/test"));
const fs_1 = require("fs");
const TestUtils_1 = require("../../../test/playwright/TestUtils");
const assert_1 = require("assert");
const KITTY_BLACK_1X1_BASE64 = (0, fs_1.readFileSync)('./addons/addon-image/fixture/kitty/black-1x1.png').toString('base64');
const KITTY_BLACK_1X1_BYTES = Array.from((0, fs_1.readFileSync)('./addons/addon-image/fixture/kitty/black-1x1.png'));
const KITTY_RGB_3X1_BASE64 = (0, fs_1.readFileSync)('./addons/addon-image/fixture/kitty/rgb-3x1.png').toString('base64');
const KITTY_MULTICOLOR_200X100_BASE64 = (0, fs_1.readFileSync)('./addons/addon-image/fixture/kitty/multicolor-200x100.png').toString('base64');
const KITTY_MULTICOLOR_200X100_BYTES = Array.from((0, fs_1.readFileSync)('./addons/addon-image/fixture/kitty/multicolor-200x100.png'));
const RAW_RGB_1X1_BLACK = Buffer.from([0, 0, 0]).toString('base64');
const RAW_RGB_1X1_RED = Buffer.from([255, 0, 0]).toString('base64');
const RAW_RGB_3X1 = Buffer.from([
    255, 0, 0,
    0, 255, 0,
    0, 0, 255
]).toString('base64');
const RAW_RGB_2X2 = Buffer.from([
    255, 0, 0, 0, 255, 0,
    0, 0, 255, 255, 255, 0
]).toString('base64');
const RAW_RGB_5X1 = Buffer.from([
    255, 0, 0,
    0, 255, 0,
    0, 0, 255,
    255, 255, 0,
    255, 0, 255
]).toString('base64');
const RAW_RGB_4X2 = Buffer.from([
    255, 0, 0, 0, 255, 0, 0, 0, 255, 255, 255, 0,
    255, 0, 255, 0, 255, 255, 128, 128, 128, 255, 255, 255
]).toString('base64');
const RAW_RGBA_1X1_WHITE = Buffer.from([255, 255, 255, 255]).toString('base64');
const RAW_RGBA_1X1_RED = Buffer.from([255, 0, 0, 255]).toString('base64');
const RAW_RGBA_1X1_TRANSPARENT = Buffer.from([0, 0, 0, 0]).toString('base64');
const RAW_RGBA_3X1 = Buffer.from([
    255, 0, 0, 255,
    0, 255, 0, 255,
    0, 0, 255, 255
]).toString('base64');
const RAW_RGBA_2X2 = Buffer.from([
    255, 0, 0, 255, 0, 255, 0, 255,
    0, 0, 255, 255, 255, 255, 0, 255
]).toString('base64');
const RAW_RGBA_5X1 = Buffer.from([
    255, 0, 0, 255,
    0, 255, 0, 255,
    0, 0, 255, 255,
    255, 255, 0, 255,
    255, 0, 255, 255
]).toString('base64');
let ctx;
test_1.default.beforeAll(async ({ browser }) => {
    ctx = await (0, TestUtils_1.createTestContext)(browser);
    await (0, TestUtils_1.openTerminal)(ctx, { cols: 80, rows: 24 });
});
test_1.default.afterAll(async () => await ctx.page.close());
test_1.default.describe('Kitty Graphics Protocol', () => {
    test_1.default.beforeEach(async ({}, testInfo) => {
        if (ctx.browser.browserType().name() === 'webkit') {
            testInfo.skip();
            return;
        }
        await ctx.page.evaluate(`
      window.term.reset()
      window.imageAddon?.dispose();
      window.imageAddon = new ImageAddon({ sixelPaletteLimit: 512 });
      window.term.loadAddon(window.imageAddon);
    `);
    });
    test_1.default.describe('Basic transmission and storage', () => {
        (0, test_1.default)('stores 1x1 black PNG with a=T (transmit and display)', async () => {
            const seq = `\x1b_Ga=T,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`;
            await ctx.proxy.write(seq);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
            (0, assert_1.deepStrictEqual)(await getOrigSize(1), [1, 1]);
        });
        (0, test_1.default)('stores 3x1 RGB PNG with a=T', async () => {
            const seq = `\x1b_Ga=T,f=100;${KITTY_RGB_3X1_BASE64}\x1b\\`;
            await ctx.proxy.write(seq);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
            (0, assert_1.deepStrictEqual)(await getOrigSize(1), [3, 1]);
        });
        (0, test_1.default)('transmit only (a=t) does not display but stores in handler', async () => {
            const seq = `\x1b_Ga=t,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`;
            await ctx.proxy.write(seq);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.size`), 1);
        });
        (0, test_1.default)('uses specified image ID', async () => {
            const seq = `\x1b_Ga=t,f=100,i=42;${KITTY_BLACK_1X1_BASE64}\x1b\\`;
            await ctx.proxy.write(seq);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.has(42)`), true);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.has(1)`), false);
        });
        (0, test_1.default)('assigns auto-incrementing IDs when not specified', async () => {
            await ctx.proxy.write(`\x1b_Ga=t,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await ctx.proxy.write(`\x1b_Ga=t,f=100;${KITTY_RGB_3X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.size`), 2);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.has(1)`), true);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.has(2)`), true);
        });
        (0, test_1.default)('defaults to transmit action when action is omitted', async () => {
            const seq = `\x1b_Gf=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`;
            await ctx.proxy.write(seq);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.size`), 1);
        });
        (0, test_1.default)('ignores command when action is empty string', async () => {
            const seq = `\x1b_Ga=,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`;
            await ctx.proxy.write(seq);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.size`), 0);
        });
    });
    test_1.default.describe('Chunked transmission', () => {
        (0, test_1.default)('handles chunked transmission (m=1)', async () => {
            const half = Math.floor(KITTY_BLACK_1X1_BASE64.length / 2);
            const part1 = KITTY_BLACK_1X1_BASE64.substring(0, half);
            const part2 = KITTY_BLACK_1X1_BASE64.substring(half);
            const seq1 = `\x1b_Ga=T,f=100,i=99,m=1;${part1}\x1b\\`;
            const seq2 = `\x1b_Ga=T,f=100,i=99;${part2}\x1b\\`;
            await ctx.proxy.write(seq1);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 0);
            await ctx.proxy.write(seq2);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
        });
        (0, test_1.default)('verifies chunked data is assembled correctly', async () => {
            const half = Math.floor(KITTY_BLACK_1X1_BASE64.length / 2);
            const part1 = KITTY_BLACK_1X1_BASE64.substring(0, half);
            const part2 = KITTY_BLACK_1X1_BASE64.substring(half);
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=99,m=1;${part1}\x1b\\`);
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=99;${part2}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const storedData = await ctx.page.evaluate(async () => {
                const blob = window.imageAddon._handlers.get('kitty').images.get(99).data;
                const buffer = await blob.arrayBuffer();
                return Array.from(new Uint8Array(buffer));
            });
            (0, assert_1.deepStrictEqual)(storedData, KITTY_BLACK_1X1_BYTES);
        });
        (0, test_1.default)('enforces size limit across chunked transmissions', async () => {
            await ctx.page.evaluate(() => {
                window.smallLimitAddon = new ImageAddon({
                    kittySupport: true,
                    kittySizeLimit: 100
                });
                window.term.loadAddon(window.smallLimitAddon);
            });
            const half = Math.floor(KITTY_BLACK_1X1_BASE64.length / 2);
            const part1 = KITTY_BLACK_1X1_BASE64.substring(0, half);
            const part2 = KITTY_BLACK_1X1_BASE64.substring(half);
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=777,m=1;${part1}\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=777;${part2}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.smallLimitAddon._handlers.get('kitty').images.has(777)`), false);
            await ctx.page.evaluate(() => {
                window.smallLimitAddon.dispose();
            });
        });
        (0, test_1.default)('chunked a=T works when subsequent chunks omit i= (spec pattern)', async () => {
            const half = Math.floor(KITTY_BLACK_1X1_BASE64.length / 2);
            const part1 = KITTY_BLACK_1X1_BASE64.substring(0, half);
            const part2 = KITTY_BLACK_1X1_BASE64.substring(half);
            await ctx.proxy.write(`\x1b_Ga=T,f=100,i=400,m=1;${part1}\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 0);
            await ctx.proxy.write(`\x1b_Gm=0;${part2}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
        });
        (0, test_1.default)('chunked a=t works when subsequent chunks omit i= (spec pattern)', async () => {
            const half = Math.floor(KITTY_BLACK_1X1_BASE64.length / 2);
            const part1 = KITTY_BLACK_1X1_BASE64.substring(0, half);
            const part2 = KITTY_BLACK_1X1_BASE64.substring(half);
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=401,m=1;${part1}\x1b\\`);
            await ctx.proxy.write(`\x1b_Gm=0;${part2}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.has(401)`), true);
        });
        (0, test_1.default)('chunked data without i= on subsequent chunks is assembled correctly', async () => {
            const half = Math.floor(KITTY_BLACK_1X1_BASE64.length / 2);
            const part1 = KITTY_BLACK_1X1_BASE64.substring(0, half);
            const part2 = KITTY_BLACK_1X1_BASE64.substring(half);
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=402,m=1;${part1}\x1b\\`);
            await ctx.proxy.write(`\x1b_Gm=0;${part2}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const storedData = await ctx.page.evaluate(async () => {
                const blob = window.imageAddon._handlers.get('kitty').images.get(402).data;
                const buffer = await blob.arrayBuffer();
                return Array.from(new Uint8Array(buffer));
            });
            (0, assert_1.deepStrictEqual)(storedData, KITTY_BLACK_1X1_BYTES);
        });
        (0, test_1.default)('three-chunk transfer with only m= on middle and last chunks', async () => {
            const third = Math.floor(KITTY_BLACK_1X1_BASE64.length / 3);
            const part1 = KITTY_BLACK_1X1_BASE64.substring(0, third);
            const part2End = third + Math.floor((KITTY_BLACK_1X1_BASE64.length - third) / 2);
            const alignedPart2End = part2End - (part2End - third) % 4 + third;
            const part2 = KITTY_BLACK_1X1_BASE64.substring(third, alignedPart2End);
            const part3 = KITTY_BLACK_1X1_BASE64.substring(alignedPart2End);
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=403,m=1;${part1}\x1b\\`);
            await ctx.proxy.write(`\x1b_Gm=1;${part2}\x1b\\`);
            await ctx.proxy.write(`\x1b_Gm=0;${part3}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const storedData = await ctx.page.evaluate(async () => {
                const blob = window.imageAddon._handlers.get('kitty').images.get(403).data;
                const buffer = await blob.arrayBuffer();
                return Array.from(new Uint8Array(buffer));
            });
            (0, assert_1.deepStrictEqual)(storedData, KITTY_BLACK_1X1_BYTES);
        });
        (0, test_1.default)('chunked a=T without i= on any chunk works (no response)', async () => {
            const half = Math.floor(KITTY_BLACK_1X1_BASE64.length / 2);
            const part1 = KITTY_BLACK_1X1_BASE64.substring(0, half);
            const part2 = KITTY_BLACK_1X1_BASE64.substring(half);
            await ctx.proxy.write(`\x1b_Ga=T,f=100,m=1;${part1}\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 0);
            await ctx.proxy.write(`\x1b_Gm=0;${part2}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
        });
        (0, test_1.default)('chunked transfer responds OK on final chunk when i= on first only', async () => {
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            const half = Math.floor(KITTY_BLACK_1X1_BASE64.length / 2);
            const part1 = KITTY_BLACK_1X1_BASE64.substring(0, half);
            const part2 = KITTY_BLACK_1X1_BASE64.substring(half);
            await ctx.proxy.write(`\x1b_Ga=T,f=100,i=405,m=1;${part1}\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            let response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response, '');
            await ctx.proxy.write(`\x1b_Gm=0;${part2}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response, '\x1b_Gi=405;OK\x1b\\');
        });
    });
    test_1.default.describe('Delete commands', () => {
        (0, test_1.default)('delete command (a=d,d=i) removes specific image by id', async () => {
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=10;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.size`), 1);
            await ctx.proxy.write(`\x1b_Ga=d,d=i,i=10\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.size`), 0);
        });
        (0, test_1.default)('delete command (a=d) removes all images when no id specified', async () => {
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=1;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=2;${KITTY_RGB_3X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.size`), 2);
            await ctx.proxy.write(`\x1b_Ga=d\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.size`), 0);
        });
        (0, test_1.default)('delete by id aborts in-flight chunked upload', async () => {
            const half = Math.floor(KITTY_BLACK_1X1_BASE64.length / 2);
            const part1 = KITTY_BLACK_1X1_BASE64.substring(0, half);
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=50,m=1;${part1}\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').pendingTransmissions.size`), 1);
            await ctx.proxy.write(`\x1b_Ga=d,d=i,i=50\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').pendingTransmissions.size`), 0);
        });
        (0, test_1.default)('delete by id only aborts targeted upload, not others', async () => {
            const half = Math.floor(KITTY_BLACK_1X1_BASE64.length / 2);
            const part1 = KITTY_BLACK_1X1_BASE64.substring(0, half);
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=55,m=1;${part1}\x1b\\`);
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=56,m=1;${part1}\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').pendingTransmissions.size`), 2);
            await ctx.proxy.write(`\x1b_Ga=d,d=i,i=55\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').pendingTransmissions.size`), 1);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').pendingTransmissions.has(56)`), true);
        });
        (0, test_1.default)('delete all aborts in-flight chunked upload', async () => {
            const half = Math.floor(KITTY_BLACK_1X1_BASE64.length / 2);
            const part1 = KITTY_BLACK_1X1_BASE64.substring(0, half);
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=60,m=1;${part1}\x1b\\`);
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=61,m=1;${part1}\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').pendingTransmissions.size`), 2);
            await ctx.proxy.write(`\x1b_Ga=d\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').pendingTransmissions.size`), 0);
        });
        (0, test_1.default)('d=i selector deletes specific image by id', async () => {
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=80;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=81;${KITTY_RGB_3X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.size`), 2);
            await ctx.proxy.write(`\x1b_Ga=d,d=i,i=80\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.size`), 1);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.has(81)`), true);
        });
        (0, test_1.default)('d=I selector deletes specific image by id (uppercase)', async () => {
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=82;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=83;${KITTY_RGB_3X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.size`), 2);
            await ctx.proxy.write(`\x1b_Ga=d,d=I,i=82\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.size`), 1);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.has(83)`), true);
        });
        (0, test_1.default)('d=a selector deletes all images', async () => {
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=84;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=85;${KITTY_RGB_3X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.size`), 2);
            await ctx.proxy.write(`\x1b_Ga=d,d=a\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.size`), 0);
        });
        (0, test_1.default)('d=A selector deletes all images (uppercase)', async () => {
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=86;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=87;${KITTY_RGB_3X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.size`), 2);
            await ctx.proxy.write(`\x1b_Ga=d,d=A\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.size`), 0);
        });
        (0, test_1.default)('d=a selector also removes displayed images from storage', async () => {
            await ctx.proxy.write(`\x1b_Ga=T,f=100,i=88;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
            await ctx.proxy.write(`\x1b_Ga=d,d=a\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 0);
        });
        (0, test_1.default)('d=i selector also removes displayed image from storage', async () => {
            await ctx.proxy.write(`\x1b_Ga=T,f=100,i=89;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
            await ctx.proxy.write(`\x1b_Ga=d,d=i,i=89\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 0);
        });
        (0, test_1.default)('d=i without id does nothing', async () => {
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=90;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.size`), 1);
            await ctx.proxy.write(`\x1b_Ga=d,d=i\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.size`), 1);
        });
        (0, test_1.default)('d=i selector clears pixels from canvas', async () => {
            await ctx.proxy.write(`\x1b_Ga=T,f=100,i=92,q=1;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 0, 0), [0, 0, 0, 255]);
            await ctx.proxy.write(`\x1b_Ga=d,d=i,i=92\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await getPixel(0, 0, 0, 0), null);
        });
        (0, test_1.default)('d=a selector clears all pixels from canvas', async () => {
            await ctx.proxy.write(`\x1b_Ga=T,f=100,i=93,q=1;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 0, 0), [0, 0, 0, 255]);
            await ctx.proxy.write(`\x1b_Ga=d,d=a\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await getPixel(0, 0, 0, 0), null);
        });
        (0, test_1.default)('unsupported delete selector is ignored', async () => {
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=91;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.size`), 1);
            await ctx.proxy.write(`\x1b_Ga=d,d=c\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.size`), 1);
        });
        (0, test_1.default)('chunks sent after delete are not assembled with previous data', async () => {
            const half = Math.floor(KITTY_BLACK_1X1_BASE64.length / 2);
            const part1 = KITTY_BLACK_1X1_BASE64.substring(0, half);
            const part2 = KITTY_BLACK_1X1_BASE64.substring(half);
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=70,m=1;${part1}\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').pendingTransmissions.size`), 1);
            await ctx.proxy.write(`\x1b_Ga=d\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=70;${part2}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.has(70)`), true);
            const storedSize = await ctx.page.evaluate(async () => {
                const blob = window.imageAddon._handlers.get('kitty').images.get(70).data;
                return blob.size;
            });
            (0, assert_1.ok)(storedSize < KITTY_BLACK_1X1_BYTES.length, 'stored data should be smaller than full image (only second half)');
        });
    });
    test_1.default.describe('Query support (a=q)', () => {
        (0, test_1.default)('responds with OK for capability query without payload', async () => {
            let response = '';
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write('\x1b_Gi=31,a=q;\x1b\\');
            await (0, TestUtils_1.timeout)(100);
            response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response, '\x1b_Gi=31;OK\x1b\\');
        });
        (0, test_1.default)('responds with OK for valid PNG query', async () => {
            let response = '';
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write(`\x1b_Gi=42,a=q,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response, '\x1b_Gi=42;OK\x1b\\');
        });
        (0, test_1.default)('query does NOT store the image (unlike transmit)', async () => {
            await ctx.page.evaluate(() => {
                window.term.onData(() => { });
            });
            await ctx.proxy.write(`\x1b_Gi=50,a=q,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.has(50)`), false);
        });
        (0, test_1.default)('responds with error for invalid base64', async () => {
            let response = '';
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write('\x1b_Gi=60,a=q,f=100;!!!invalid!!!\x1b\\');
            await (0, TestUtils_1.timeout)(100);
            response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response.startsWith('\x1b_Gi=60;EINVAL:'), true);
        });
        (0, test_1.default)('responds with error for RGB data without dimensions', async () => {
            let response = '';
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write('\x1b_Gi=70,a=q,f=24;AAAA\x1b\\');
            await (0, TestUtils_1.timeout)(100);
            response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response, '\x1b_Gi=70;EINVAL:width and height required for raw pixel data\x1b\\');
        });
        (0, test_1.default)('suppresses OK response when q=1', async () => {
            await ctx.page.evaluate(() => {
                window.kittyGotResponse = false;
                window.term.onData(() => { window.kittyGotResponse = true; });
            });
            await ctx.proxy.write(`\x1b_Gi=80,a=q,q=1,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await ctx.page.evaluate('window.kittyGotResponse'), false);
        });
        (0, test_1.default)('suppresses error response when q=2', async () => {
            await ctx.page.evaluate(() => {
                window.kittyGotResponse = false;
                window.term.onData(() => { window.kittyGotResponse = true; });
            });
            await ctx.proxy.write('\x1b_Gi=90,a=q,q=2,f=100;!!!invalid!!!\x1b\\');
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await ctx.page.evaluate('window.kittyGotResponse'), false);
        });
        (0, test_1.default)('responds with EINVAL when both i and I keys are specified', async () => {
            let response = '';
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write(`\x1b_Gi=100,I=200,a=q,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response, '\x1b_Gi=100;EINVAL:cannot specify both i and I keys\x1b\\');
        });
        (0, test_1.default)('responds with EINVAL for i+I conflict even without payload', async () => {
            let response = '';
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write('\x1b_Gi=101,I=201,a=d\x1b\\');
            await (0, TestUtils_1.timeout)(100);
            response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response, '\x1b_Gi=101;EINVAL:cannot specify both i and I keys\x1b\\');
        });
    });
    test_1.default.describe('Error responses for transmit and display', () => {
        (0, test_1.default)('a=t sends EINVAL on decode error when id is specified', async () => {
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write('\x1b_Gi=110,a=t,f=100;!!!invalid!!!\x1b\\');
            await (0, TestUtils_1.timeout)(100);
            const response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response, '\x1b_Gi=110;EINVAL:invalid base64 data\x1b\\');
        });
        (0, test_1.default)('a=t sends no response on decode error without id', async () => {
            await ctx.page.evaluate(() => {
                window.kittyGotResponse = false;
                window.term.onData(() => { window.kittyGotResponse = true; });
            });
            await ctx.proxy.write('\x1b_Ga=t,f=100;!!!invalid!!!\x1b\\');
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await ctx.page.evaluate('window.kittyGotResponse'), false);
        });
        (0, test_1.default)('a=T sends EINVAL on decode error when id is specified', async () => {
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write('\x1b_Gi=120,a=T,f=100;!!!invalid!!!\x1b\\');
            await (0, TestUtils_1.timeout)(100);
            const response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response, '\x1b_Gi=120;EINVAL:invalid base64 data\x1b\\');
        });
        (0, test_1.default)('a=T sends no response on decode error without id', async () => {
            await ctx.page.evaluate(() => {
                window.kittyGotResponse = false;
                window.term.onData(() => { window.kittyGotResponse = true; });
            });
            await ctx.proxy.write('\x1b_Ga=T,f=100;!!!invalid!!!\x1b\\');
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await ctx.page.evaluate('window.kittyGotResponse'), false);
        });
        (0, test_1.default)('a=T sends EINVAL when raw pixel render fails (missing dimensions)', async () => {
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write(`\x1b_Gi=130,a=T,f=24;${RAW_RGB_1X1_BLACK}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response.startsWith('\x1b_Gi=130;EINVAL:'), true);
        });
        (0, test_1.default)('a=T sends OK on successful render with id', async () => {
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write(`\x1b_Gi=140,a=T,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response, '\x1b_Gi=140;OK\x1b\\');
        });
        (0, test_1.default)('a=t sends OK on successful transmit with id', async () => {
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write(`\x1b_Gi=150,a=t,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response, '\x1b_Gi=150;OK\x1b\\');
        });
        (0, test_1.default)('a=t EINVAL suppressed by q=2', async () => {
            await ctx.page.evaluate(() => {
                window.kittyGotResponse = false;
                window.term.onData(() => { window.kittyGotResponse = true; });
            });
            await ctx.proxy.write('\x1b_Gi=160,a=t,q=2,f=100;!!!invalid!!!\x1b\\');
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await ctx.page.evaluate('window.kittyGotResponse'), false);
        });
        (0, test_1.default)('a=T EINVAL suppressed by q=2', async () => {
            await ctx.page.evaluate(() => {
                window.kittyGotResponse = false;
                window.term.onData(() => { window.kittyGotResponse = true; });
            });
            await ctx.proxy.write('\x1b_Gi=170,a=T,q=2,f=100;!!!invalid!!!\x1b\\');
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await ctx.page.evaluate('window.kittyGotResponse'), false);
        });
        (0, test_1.default)('a=t OK suppressed by q=1', async () => {
            await ctx.page.evaluate(() => {
                window.kittyGotResponse = false;
                window.term.onData(() => { window.kittyGotResponse = true; });
            });
            await ctx.proxy.write(`\x1b_Gi=180,a=t,q=1,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await ctx.page.evaluate('window.kittyGotResponse'), false);
        });
        (0, test_1.default)('a=T OK suppressed by q=1', async () => {
            await ctx.page.evaluate(() => {
                window.kittyGotResponse = false;
                window.term.onData(() => { window.kittyGotResponse = true; });
            });
            await ctx.proxy.write(`\x1b_Gi=190,a=T,q=1,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await ctx.page.evaluate('window.kittyGotResponse'), false);
        });
    });
    test_1.default.describe('Transmission medium rejection', () => {
        (0, test_1.default)('query rejects t=f (file transmission)', async () => {
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write(`\x1b_Gi=200,a=q,t=f,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response.startsWith('\x1b_Gi=200;EINVAL:'), true);
        });
        (0, test_1.default)('query rejects t=s (shared memory)', async () => {
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write(`\x1b_Gi=201,a=q,t=s,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response.startsWith('\x1b_Gi=201;EINVAL:'), true);
        });
        (0, test_1.default)('query rejects t=t (temp file)', async () => {
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write(`\x1b_Gi=202,a=q,t=t,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response.startsWith('\x1b_Gi=202;EINVAL:'), true);
        });
        (0, test_1.default)('query accepts t=d (direct transmission)', async () => {
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write(`\x1b_Gi=203,a=q,t=d,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response, '\x1b_Gi=203;OK\x1b\\');
        });
        (0, test_1.default)('query without t key defaults to direct (OK)', async () => {
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write(`\x1b_Gi=204,a=q,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response, '\x1b_Gi=204;OK\x1b\\');
        });
        (0, test_1.default)('transmit rejects t=f with id (EINVAL response)', async () => {
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write(`\x1b_Gi=300,a=t,t=f,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response.startsWith('\x1b_Gi=300;EINVAL:'), true);
        });
        (0, test_1.default)('transmit rejects t=s with id (EINVAL response)', async () => {
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write(`\x1b_Gi=301,a=t,t=s,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response.startsWith('\x1b_Gi=301;EINVAL:'), true);
        });
        (0, test_1.default)('transmit rejects t=t with id (EINVAL response)', async () => {
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write(`\x1b_Gi=302,a=t,t=t,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response.startsWith('\x1b_Gi=302;EINVAL:'), true);
        });
        (0, test_1.default)('transmit rejects t=f without id (no response)', async () => {
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write(`\x1b_Ga=t,t=f,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response, '');
        });
        (0, test_1.default)('transmit+display rejects t=f with id (EINVAL response)', async () => {
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write(`\x1b_Gi=310,a=T,t=f,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response.startsWith('\x1b_Gi=310;EINVAL:'), true);
        });
        (0, test_1.default)('transmit+display rejects t=s with id (EINVAL response)', async () => {
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write(`\x1b_Gi=311,a=T,t=s,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response.startsWith('\x1b_Gi=311;EINVAL:'), true);
        });
        (0, test_1.default)('transmit+display rejects t=t with id (EINVAL response)', async () => {
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write(`\x1b_Gi=312,a=T,t=t,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response.startsWith('\x1b_Gi=312;EINVAL:'), true);
        });
        (0, test_1.default)('transmit+display rejects t=f without id (no response)', async () => {
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write(`\x1b_Ga=T,t=f,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response, '');
        });
    });
    test_1.default.describe('Placement action (a=p)', () => {
        (0, test_1.default)('displays a previously transmitted image at cursor', async () => {
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=210;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 0);
            await ctx.proxy.write(`\x1b_Ga=p,i=210\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
            (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 0, 0), [0, 0, 0, 255]);
        });
        (0, test_1.default)('responds OK on successful placement', async () => {
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=211;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write(`\x1b_Ga=p,i=211\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response, '\x1b_Gi=211;OK\x1b\\');
        });
        (0, test_1.default)('responds ENOENT for non-existent image id', async () => {
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write(`\x1b_Ga=p,i=9999\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response, '\x1b_Gi=9999;ENOENT:image not found\x1b\\');
        });
        (0, test_1.default)('without id sends no response', async () => {
            await ctx.page.evaluate(() => {
                window.kittyGotResponse = false;
                window.term.onData(() => { window.kittyGotResponse = true; });
            });
            await ctx.proxy.write(`\x1b_Ga=p\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await ctx.page.evaluate('window.kittyGotResponse'), false);
        });
        (0, test_1.default)('places at specified column/row size (c/r)', async () => {
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=212;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            await ctx.proxy.write(`\x1b_Ga=p,i=212,c=5,r=3\x1b\\`);
            await (0, TestUtils_1.timeout)(200);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
            (0, assert_1.deepStrictEqual)(await getCursor(), [5, 2]);
        });
        (0, test_1.default)('cursor advances past placed image (default C=0)', async () => {
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=213;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.deepStrictEqual)(await getCursor(), [0, 0]);
            await ctx.proxy.write(`\x1b_Ga=p,i=213\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.deepStrictEqual)(await getCursor(), [1, 0]);
        });
        (0, test_1.default)('cursor does not move when C=1', async () => {
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=214;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.deepStrictEqual)(await getCursor(), [0, 0]);
            await ctx.proxy.write(`\x1b_Ga=p,i=214,c=5,r=3,C=1\x1b\\`);
            await (0, TestUtils_1.timeout)(200);
            (0, assert_1.deepStrictEqual)(await getCursor(), [0, 0]);
        });
        (0, test_1.default)('supports z-index (negative = bottom layer)', async () => {
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=215;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            await ctx.proxy.write(`\x1b_Ga=p,i=215,z=-1\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._storage._images.get(1).layer`), 'bottom');
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._storage._images.get(1).zIndex`), -1);
        });
        (0, test_1.default)('supports source crop via x/y', async () => {
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=216;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            await ctx.proxy.write(`\x1b_Ga=p,i=216,x=20,y=0,w=20,h=50\x1b\\`);
            await (0, TestUtils_1.timeout)(200);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
            (0, assert_1.deepStrictEqual)(await getOrigSize(1), [20, 50]);
            (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 0, 0), [255, 128, 0, 255]);
        });
        (0, test_1.default)('supports sub-cell offset via X/Y', async () => {
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=217;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            await ctx.proxy.write(`\x1b_Ga=p,i=217,X=5,Y=3\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 0, 0), [0, 0, 0, 0]);
            (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 4, 2), [0, 0, 0, 0]);
            (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 5, 3), [0, 0, 0, 255]);
        });
        (0, test_1.default)('multiple placements of same image create separate displays', async () => {
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=218;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 0);
            await ctx.proxy.write(`\x1b_Ga=p,i=218,p=1\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
            await ctx.proxy.write('\x1b[3;1H');
            await ctx.proxy.write(`\x1b_Ga=p,i=218,p=2\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 2);
        });
        (0, test_1.default)('image data remains available after placement for future placements', async () => {
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=219;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            await ctx.proxy.write(`\x1b_Ga=p,i=219\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            await ctx.proxy.write('\x1b[2;1H');
            await ctx.proxy.write(`\x1b_Ga=p,i=219\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            await ctx.proxy.write('\x1b[3;1H');
            await ctx.proxy.write(`\x1b_Ga=p,i=219\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.has(219)`), true);
        });
        (0, test_1.default)('OK response suppressed by q=1', async () => {
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=220;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            await ctx.page.evaluate(() => {
                window.kittyGotResponse = false;
                window.term.onData(() => { window.kittyGotResponse = true; });
            });
            await ctx.proxy.write(`\x1b_Ga=p,i=220,q=1\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await ctx.page.evaluate('window.kittyGotResponse'), false);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
        });
        (0, test_1.default)('ENOENT error suppressed by q=2', async () => {
            await ctx.page.evaluate(() => {
                window.kittyGotResponse = false;
                window.term.onData(() => { window.kittyGotResponse = true; });
            });
            await ctx.proxy.write(`\x1b_Ga=p,i=9998,q=2\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await ctx.page.evaluate('window.kittyGotResponse'), false);
        });
        (0, test_1.default)('ENOENT still reported when q=1 (only suppresses OK)', async () => {
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write(`\x1b_Ga=p,i=9997,q=1\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response, '\x1b_Gi=9997;ENOENT:image not found\x1b\\');
        });
        (0, test_1.default)('renders pixels correctly when placing a PNG image', async () => {
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=221;${KITTY_RGB_3X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            await ctx.proxy.write(`\x1b_Ga=p,i=221\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const pixels = await getPixels(0, 0, 0, 0, 3, 1);
            (0, assert_1.deepStrictEqual)(pixels?.slice(0, 4), [255, 0, 0, 255]);
            (0, assert_1.deepStrictEqual)(pixels?.slice(4, 8), [0, 255, 0, 255]);
            (0, assert_1.deepStrictEqual)(pixels?.slice(8, 12), [0, 0, 255, 255]);
        });
        (0, test_1.default)('renders pixels correctly when placing raw RGB image', async () => {
            await ctx.proxy.write(`\x1b_Ga=t,f=24,s=3,v=1,i=222;${RAW_RGB_3X1}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            await ctx.proxy.write(`\x1b_Ga=p,i=222\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const pixels = await getPixels(0, 0, 0, 0, 3, 1);
            (0, assert_1.deepStrictEqual)(pixels?.slice(0, 4), [255, 0, 0, 255]);
            (0, assert_1.deepStrictEqual)(pixels?.slice(4, 8), [0, 255, 0, 255]);
            (0, assert_1.deepStrictEqual)(pixels?.slice(8, 12), [0, 0, 255, 255]);
        });
        (0, test_1.default)('renders pixels correctly when placing raw RGBA image', async () => {
            await ctx.proxy.write(`\x1b_Ga=t,f=32,s=3,v=1,i=223;${RAW_RGBA_3X1}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            await ctx.proxy.write(`\x1b_Ga=p,i=223\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const pixels = await getPixels(0, 0, 0, 0, 3, 1);
            (0, assert_1.deepStrictEqual)(pixels?.slice(0, 4), [255, 0, 0, 255]);
            (0, assert_1.deepStrictEqual)(pixels?.slice(4, 8), [0, 255, 0, 255]);
            (0, assert_1.deepStrictEqual)(pixels?.slice(8, 12), [0, 0, 255, 255]);
        });
        (0, test_1.default)('response includes placement id when p is specified', async () => {
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=224;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            await ctx.page.evaluate(() => {
                window.kittyResponse = '';
                window.term.onData((data) => { window.kittyResponse = data; });
            });
            await ctx.proxy.write(`\x1b_Ga=p,i=224,p=42\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const response = await ctx.page.evaluate('window.kittyResponse');
            (0, assert_1.strictEqual)(response, '\x1b_Gi=224,p=42;OK\x1b\\');
        });
        (0, test_1.default)('only c specified computes r from aspect ratio', async () => {
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=225;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            await ctx.proxy.write(`\x1b_Ga=p,i=225,c=10\x1b\\`);
            await (0, TestUtils_1.timeout)(200);
            const cursor = await getCursor();
            const cellDims = await ctx.page.evaluate(() => {
                const d = window.term._core._renderService.dimensions.css.cell;
                return [d.width, d.height];
            });
            const expectedR = Math.ceil((100 / 200) * 10 * cellDims[0] / cellDims[1]);
            (0, assert_1.deepStrictEqual)(cursor, [10, expectedR - 1]);
        });
        (0, test_1.default)('only r specified computes c from aspect ratio', async () => {
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=226;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            await ctx.proxy.write(`\x1b_Ga=p,i=226,r=5\x1b\\`);
            await (0, TestUtils_1.timeout)(200);
            const cursor = await getCursor();
            const cellDims = await ctx.page.evaluate(() => {
                const d = window.term._core._renderService.dimensions.css.cell;
                return [d.width, d.height];
            });
            const expectedC = Math.ceil((200 / 100) * 5 * cellDims[1] / cellDims[0]);
            (0, assert_1.deepStrictEqual)(cursor, [expectedC, 4]);
        });
    });
    test_1.default.describe('Cursor positioning', () => {
        (0, test_1.default)('cursor advances past 1x1 image', async () => {
            const cursorBefore = await getCursor();
            const seq = `\x1b_Ga=T,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`;
            await ctx.proxy.write(seq);
            await (0, TestUtils_1.timeout)(100);
            const cursorAfter = await getCursor();
            (0, assert_1.deepStrictEqual)(cursorBefore, [0, 0]);
            (0, assert_1.deepStrictEqual)(cursorAfter, [1, 0]);
        });
        (0, test_1.default)('cursor advances with text before image', async () => {
            await ctx.proxy.write('Hello');
            (0, assert_1.deepStrictEqual)(await getCursor(), [5, 0]);
            await ctx.proxy.write(`\x1b_Ga=T,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.deepStrictEqual)(await getCursor(), [6, 0]);
        });
        (0, test_1.default)('cursor advances with text after image', async () => {
            await ctx.proxy.write(`\x1b_Ga=T,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.deepStrictEqual)(await getCursor(), [1, 0]);
            await ctx.proxy.write('World');
            (0, assert_1.deepStrictEqual)(await getCursor(), [6, 0]);
        });
        (0, test_1.default)('cursor position with multiple images on same line', async () => {
            await ctx.proxy.write(`\x1b_Ga=T,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.deepStrictEqual)(await getCursor(), [1, 0]);
            await ctx.proxy.write('###');
            (0, assert_1.deepStrictEqual)(await getCursor(), [4, 0]);
            await ctx.proxy.write(`\x1b_Ga=T,f=100;${KITTY_RGB_3X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(50);
            (0, assert_1.deepStrictEqual)(await getCursor(), [5, 0]);
        });
        (0, test_1.default)('cursor advances on newline after image', async () => {
            await ctx.proxy.write(`\x1b_Ga=T,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.deepStrictEqual)(await getCursor(), [1, 0]);
            await ctx.proxy.write('\n');
            (0, assert_1.deepStrictEqual)(await getCursor(), [1, 1]);
        });
        (0, test_1.default)('cursor should move right by cols when c specified', async () => {
            await ctx.proxy.write(`\x1b_Ga=T,f=100,c=5;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const cursor = await getCursor();
            (0, assert_1.strictEqual)(cursor[0], 5);
        });
        (0, test_1.default)('cursor should move down by rows when r specified', async () => {
            await ctx.proxy.write(`\x1b_Ga=T,f=100,r=3;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const cursor = await getCursor();
            (0, assert_1.strictEqual)(cursor[1], 2);
        });
        (0, test_1.default)('cursor should move by cols AND rows when both specified', async () => {
            await ctx.proxy.write(`\x1b_Ga=T,f=100,c=4,r=2;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.deepStrictEqual)(await getCursor(), [4, 1]);
        });
        (0, test_1.default)('cursor should NOT move when C=1 is specified', async () => {
            await ctx.proxy.write(`\x1b_Ga=T,f=100,c=5,r=3,C=1;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.deepStrictEqual)(await getCursor(), [0, 0]);
        });
        (0, test_1.default)('cursor should calculate cols/rows from image size when not specified', async () => {
            const dim = await getDimensions();
            await ctx.proxy.write(`\x1b_Ga=T,f=100;${KITTY_RGB_3X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const expectedCols = Math.ceil(3 / dim.cellWidth);
            const cursor = await getCursor();
            (0, assert_1.strictEqual)(cursor[0], expectedCols, 'cursor should advance by image columns');
            (0, assert_1.strictEqual)(cursor[1], 0, 'cursor should stay on row 0 for single-row image');
        });
    });
    test_1.default.describe('Z-index layer placement', () => {
        (0, test_1.default)('default placement (no z key) stores image on top layer', async () => {
            await ctx.proxy.write(`\x1b_Ga=T,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._storage._images.get(1).layer`), 'top');
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._storage._images.get(1).zIndex`), 0);
        });
        (0, test_1.default)('z=0 stores image on top layer', async () => {
            await ctx.proxy.write(`\x1b_Ga=T,f=100,z=0;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._storage._images.get(1).layer`), 'top');
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._storage._images.get(1).zIndex`), 0);
        });
        (0, test_1.default)('z=1 (positive) stores image on top layer', async () => {
            await ctx.proxy.write(`\x1b_Ga=T,f=100,z=1;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._storage._images.get(1).layer`), 'top');
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._storage._images.get(1).zIndex`), 1);
        });
        (0, test_1.default)('z=-1 uses bottom layer even when allowTransparency is disabled', async () => {
            await ctx.page.evaluate(`window.term.options.allowTransparency = false`);
            await ctx.proxy.write(`\x1b_Ga=T,f=100,z=-1;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._storage._images.get(1).layer`), 'bottom');
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._storage._images.get(1).zIndex`), -1);
        });
        (0, test_1.default)('z=-1 (negative) stores image on bottom layer when allowTransparency is enabled', async () => {
            await ctx.page.evaluate(`window.term.options.allowTransparency = true`);
            await ctx.proxy.write(`\x1b_Ga=T,f=100,z=-1;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._storage._images.get(1).layer`), 'bottom');
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._storage._images.get(1).zIndex`), -1);
        });
        (0, test_1.default)('z=-100 (large negative) stores image on bottom layer when allowTransparency is enabled', async () => {
            await ctx.page.evaluate(`window.term.options.allowTransparency = true`);
            await ctx.proxy.write(`\x1b_Ga=T,f=100,z=-100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._storage._images.get(1).layer`), 'bottom');
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._storage._images.get(1).zIndex`), -100);
        });
        (0, test_1.default)('top layer canvas has correct CSS class', async () => {
            await ctx.proxy.write(`\x1b_Ga=T,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const hasClass = await ctx.page.evaluate(() => {
                const el = document.querySelector('.xterm-image-layer-top');
                return el !== null;
            });
            (0, assert_1.strictEqual)(hasClass, true);
        });
        (0, test_1.default)('bottom layer canvas has correct CSS class', async () => {
            await ctx.page.evaluate(`window.term.options.allowTransparency = true`);
            await ctx.proxy.write(`\x1b_Ga=T,f=100,z=-1;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const hasClass = await ctx.page.evaluate(() => {
                const el = document.querySelector('.xterm-image-layer-bottom');
                return el !== null;
            });
            (0, assert_1.strictEqual)(hasClass, true);
        });
        (0, test_1.default)('bottom layer canvas is before text canvas in DOM order', async () => {
            await ctx.page.evaluate(`window.term.options.allowTransparency = true`);
            await ctx.proxy.write(`\x1b_Ga=T,f=100,z=-1;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            const isFirst = await ctx.page.evaluate(() => {
                const screen = document.querySelector('.xterm-screen');
                return screen?.firstElementChild?.classList.contains('xterm-image-layer-bottom') ?? false;
            });
            (0, assert_1.strictEqual)(isFirst, true);
        });
    });
    test_1.default.describe('Pixel verification', () => {
        (0, test_1.default)('renders 1x1 black PNG at cursor position', async () => {
            const seq = `\x1b_Ga=T,f=100;${KITTY_BLACK_1X1_BASE64}\x1b\\`;
            await ctx.proxy.write(seq);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 0, 0), [0, 0, 0, 255]);
        });
        (0, test_1.default)('renders 3x1 RGB PNG (red, green, blue pixels)', async () => {
            const seq = `\x1b_Ga=T,f=100;${KITTY_RGB_3X1_BASE64}\x1b\\`;
            await ctx.proxy.write(seq);
            await (0, TestUtils_1.timeout)(100);
            const pixels = await getPixels(0, 0, 0, 0, 3, 1);
            (0, assert_1.deepStrictEqual)(pixels?.slice(0, 4), [255, 0, 0, 255]);
            (0, assert_1.deepStrictEqual)(pixels?.slice(4, 8), [0, 255, 0, 255]);
            (0, assert_1.deepStrictEqual)(pixels?.slice(8, 12), [0, 0, 255, 255]);
        });
    });
    test_1.default.describe('Larger image (200x100 multicolor PNG)', () => {
        test_1.default.describe('Basic transmission and storage', () => {
            (0, test_1.default)('stores 200x100 PNG with a=T', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=100;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
                await (0, TestUtils_1.timeout)(200);
                (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
                (0, assert_1.deepStrictEqual)(await getOrigSize(1), [200, 100]);
            });
            (0, test_1.default)('transmit only (a=t) stores 200x100 image without display', async () => {
                await ctx.proxy.write(`\x1b_Ga=t,f=100;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
                await (0, TestUtils_1.timeout)(200);
                (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.size`), 1);
            });
            (0, test_1.default)('stores with specified image ID', async () => {
                await ctx.proxy.write(`\x1b_Ga=t,f=100,i=400;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
                await (0, TestUtils_1.timeout)(200);
                (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.has(400)`), true);
            });
        });
        test_1.default.describe('Chunked transmission', () => {
            (0, test_1.default)('handles 2-chunk transmission', async () => {
                const half = Math.floor(KITTY_MULTICOLOR_200X100_BASE64.length / 2);
                const part1 = KITTY_MULTICOLOR_200X100_BASE64.substring(0, half);
                const part2 = KITTY_MULTICOLOR_200X100_BASE64.substring(half);
                await ctx.proxy.write(`\x1b_Ga=T,f=100,i=500,m=1;${part1}\x1b\\`);
                await (0, TestUtils_1.timeout)(50);
                (0, assert_1.strictEqual)(await getImageStorageLength(), 0);
                await ctx.proxy.write(`\x1b_Ga=T,f=100,i=500;${part2}\x1b\\`);
                await (0, TestUtils_1.timeout)(200);
                (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
                (0, assert_1.deepStrictEqual)(await getOrigSize(1), [200, 100]);
            });
            (0, test_1.default)('handles 3-chunk transmission', async () => {
                const third = Math.floor(KITTY_MULTICOLOR_200X100_BASE64.length / 3);
                const p1 = KITTY_MULTICOLOR_200X100_BASE64.substring(0, third);
                const p2 = KITTY_MULTICOLOR_200X100_BASE64.substring(third, third * 2);
                const p3 = KITTY_MULTICOLOR_200X100_BASE64.substring(third * 2);
                await ctx.proxy.write(`\x1b_Ga=T,f=100,i=501,m=1;${p1}\x1b\\`);
                await (0, TestUtils_1.timeout)(50);
                await ctx.proxy.write(`\x1b_Ga=T,f=100,i=501,m=1;${p2}\x1b\\`);
                await (0, TestUtils_1.timeout)(50);
                await ctx.proxy.write(`\x1b_Ga=T,f=100,i=501;${p3}\x1b\\`);
                await (0, TestUtils_1.timeout)(200);
                (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
                (0, assert_1.deepStrictEqual)(await getOrigSize(1), [200, 100]);
            });
            (0, test_1.default)('verifies chunked data assembles correctly', async () => {
                const half = Math.floor(KITTY_MULTICOLOR_200X100_BASE64.length / 2);
                const part1 = KITTY_MULTICOLOR_200X100_BASE64.substring(0, half);
                const part2 = KITTY_MULTICOLOR_200X100_BASE64.substring(half);
                await ctx.proxy.write(`\x1b_Ga=t,f=100,i=502,m=1;${part1}\x1b\\`);
                await ctx.proxy.write(`\x1b_Ga=t,f=100,i=502;${part2}\x1b\\`);
                await (0, TestUtils_1.timeout)(200);
                const storedData = await ctx.page.evaluate(async () => {
                    const blob = window.imageAddon._handlers.get('kitty').images.get(502).data;
                    const buffer = await blob.arrayBuffer();
                    return Array.from(new Uint8Array(buffer));
                });
                (0, assert_1.deepStrictEqual)(storedData, KITTY_MULTICOLOR_200X100_BYTES);
            });
        });
        test_1.default.describe('Cursor positioning', () => {
            (0, test_1.default)('cursor advances past multi-cell image', async () => {
                const dim = await getDimensions();
                await ctx.proxy.write(`\x1b_Ga=T,f=100;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
                await (0, TestUtils_1.timeout)(200);
                const expectedCols = Math.ceil(200 / dim.cellWidth);
                const expectedRows = Math.ceil(100 / dim.cellHeight) - 1;
                const cursor = await getCursor();
                (0, assert_1.strictEqual)(cursor[0], expectedCols, 'cursor should advance by image columns');
                (0, assert_1.strictEqual)(cursor[1], expectedRows, 'cursor should be on last row of image');
            });
            (0, test_1.default)('cursor does not move with C=1', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=100,C=1;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
                await (0, TestUtils_1.timeout)(200);
                (0, assert_1.deepStrictEqual)(await getCursor(), [0, 0]);
            });
            (0, test_1.default)('cursor uses explicit c and r over image dimensions', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=100,c=10,r=5;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
                await (0, TestUtils_1.timeout)(200);
                (0, assert_1.deepStrictEqual)(await getCursor(), [10, 4]);
            });
        });
        test_1.default.describe('Pixel verification', () => {
            (0, test_1.default)('renders red rectangle at top-left origin (0,0)', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=100;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
                await (0, TestUtils_1.timeout)(200);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 0, 0), [255, 0, 0, 255]);
            });
            (0, test_1.default)('renders top row colors at rectangle centers', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=100;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
                await (0, TestUtils_1.timeout)(200);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 10, 25), [255, 0, 0, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 30, 25), [255, 128, 0, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 50, 25), [255, 255, 0, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 70, 25), [0, 255, 0, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 90, 25), [0, 128, 0, 255]);
            });
            (0, test_1.default)('renders bottom row colors at rectangle centers', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=100;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
                await (0, TestUtils_1.timeout)(200);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 10, 75), [255, 192, 203, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 30, 75), [165, 42, 42, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 50, 75), [128, 0, 0, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 70, 75), [128, 128, 0, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 90, 75), [0, 128, 128, 255]);
            });
            (0, test_1.default)('renders correct colors at rectangle boundaries', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=100;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
                await (0, TestUtils_1.timeout)(200);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 19, 0), [255, 0, 0, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 20, 0), [255, 128, 0, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 199, 49), [255, 0, 255, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 0, 50), [255, 192, 203, 255]);
            });
            (0, test_1.default)('renders correct color at bottom-right corner', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=100;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
                await (0, TestUtils_1.timeout)(200);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 199, 99), [255, 255, 255, 255]);
            });
            (0, test_1.default)('renders a strip of top-row pixels via getPixels', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=100;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
                await (0, TestUtils_1.timeout)(200);
                const pixels = await getPixels(0, 0, 18, 0, 3, 1);
                (0, assert_1.deepStrictEqual)(pixels?.slice(0, 4), [255, 0, 0, 255]);
                (0, assert_1.deepStrictEqual)(pixels?.slice(4, 8), [255, 0, 0, 255]);
                (0, assert_1.deepStrictEqual)(pixels?.slice(8, 12), [255, 128, 0, 255]);
            });
            (0, test_1.default)('applies source crop via x/y/w/h before display', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=100,x=20,y=0,w=20,h=50;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
                await (0, TestUtils_1.timeout)(200);
                (0, assert_1.deepStrictEqual)(await getOrigSize(1), [20, 50]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 0, 0), [255, 128, 0, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 19, 49), [255, 128, 0, 255]);
            });
            (0, test_1.default)('scales cropped source region to c/r placement rectangle', async () => {
                if (ctx.browser.browserType().name() === 'firefox') {
                    test_1.default.skip();
                }
                await ctx.proxy.write(`\x1b_Ga=T,f=100,x=1,y=0,w=1,h=1,c=4,r=2;${KITTY_RGB_3X1_BASE64}\x1b\\`);
                await (0, TestUtils_1.timeout)(200);
                (0, assert_1.deepStrictEqual)(await getCursor(), [4, 1]);
                const left = await getPixel(0, 0, 2, 10);
                const right = await getPixel(0, 0, 25, 10);
                (0, assert_1.deepStrictEqual)(left, [0, 255, 0, 255]);
                (0, assert_1.deepStrictEqual)(right, [0, 255, 0, 255]);
            });
            (0, test_1.default)('applies sub-cell offset via X/Y within first cell', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=100,X=5,Y=3;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 0, 0), [0, 0, 0, 0]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 4, 2), [0, 0, 0, 0]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 5, 3), [0, 0, 0, 255]);
            });
            (0, test_1.default)('w=0 is treated as unset (displays full width)', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=100,w=0;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
                await (0, TestUtils_1.timeout)(200);
                (0, assert_1.deepStrictEqual)(await getOrigSize(1), [200, 100]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 0, 0), [255, 0, 0, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 199, 99), [255, 255, 255, 255]);
            });
            (0, test_1.default)('h=0 is treated as unset (displays full height)', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=100,h=0;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
                await (0, TestUtils_1.timeout)(200);
                (0, assert_1.deepStrictEqual)(await getOrigSize(1), [200, 100]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 0, 0), [255, 0, 0, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 0, 50), [255, 192, 203, 255]);
            });
            (0, test_1.default)('x exceeding image width produces no display', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=100,x=999;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
                await (0, TestUtils_1.timeout)(200);
                (0, assert_1.strictEqual)(await getImageStorageLength(), 0);
            });
            (0, test_1.default)('negative x/y values are clamped to 0', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=100,x=-10,y=-10;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
                await (0, TestUtils_1.timeout)(200);
                (0, assert_1.deepStrictEqual)(await getOrigSize(1), [200, 100]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 0, 0), [255, 0, 0, 255]);
            });
            (0, test_1.default)('combined crop and sub-cell offset', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=100,x=20,y=0,w=20,h=50,X=5,Y=3;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
                await (0, TestUtils_1.timeout)(200);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 0, 0), [0, 0, 0, 0]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 4, 2), [0, 0, 0, 0]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 5, 3), [255, 128, 0, 255]);
            });
            (0, test_1.default)('sub-cell offset with explicit c/r advances cursor correctly', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=100,X=5,Y=3,c=4,r=2;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                (0, assert_1.deepStrictEqual)(await getCursor(), [4, 1]);
            });
        });
        test_1.default.describe('Query support', () => {
            (0, test_1.default)('responds with OK for valid 200x100 PNG query', async () => {
                await ctx.page.evaluate(() => {
                    window.kittyResponse = '';
                    window.term.onData((data) => { window.kittyResponse = data; });
                });
                await ctx.proxy.write(`\x1b_Gi=600,a=q,f=100;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
                await (0, TestUtils_1.timeout)(200);
                const response = await ctx.page.evaluate('window.kittyResponse');
                (0, assert_1.strictEqual)(response, '\x1b_Gi=600;OK\x1b\\');
            });
            (0, test_1.default)('query does not store the 200x100 image', async () => {
                await ctx.page.evaluate(() => {
                    window.term.onData(() => { });
                });
                await ctx.proxy.write(`\x1b_Gi=601,a=q,f=100;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
                await (0, TestUtils_1.timeout)(200);
                (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.has(601)`), false);
            });
        });
        test_1.default.describe('Delete commands', () => {
            (0, test_1.default)('delete removes 200x100 image by id', async () => {
                await ctx.proxy.write(`\x1b_Ga=t,f=100,i=700;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
                await (0, TestUtils_1.timeout)(200);
                (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.has(700)`), true);
                await ctx.proxy.write(`\x1b_Ga=d,d=i,i=700\x1b\\`);
                await (0, TestUtils_1.timeout)(50);
                (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.has(700)`), false);
            });
        });
    });
    test_1.default.describe('Raw RGB pixel format (f=24)', () => {
        test_1.default.describe('Pixel verification', () => {
            (0, test_1.default)('renders 1x1 black pixel with alpha set to 255', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=24,s=1,v=1;${RAW_RGB_1X1_BLACK}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 0, 0), [0, 0, 0, 255]);
            });
            (0, test_1.default)('renders 1x1 red pixel with alpha set to 255', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=24,s=1,v=1;${RAW_RGB_1X1_RED}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 0, 0), [255, 0, 0, 255]);
            });
            (0, test_1.default)('renders 3x1 strip (red, green, blue)', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=24,s=3,v=1;${RAW_RGB_3X1}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                const pixels = await getPixels(0, 0, 0, 0, 3, 1);
                (0, assert_1.deepStrictEqual)(pixels?.slice(0, 4), [255, 0, 0, 255]);
                (0, assert_1.deepStrictEqual)(pixels?.slice(4, 8), [0, 255, 0, 255]);
                (0, assert_1.deepStrictEqual)(pixels?.slice(8, 12), [0, 0, 255, 255]);
            });
            (0, test_1.default)('renders 2x2 grid with correct pixel layout', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=24,s=2,v=2;${RAW_RGB_2X2}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 0, 0), [255, 0, 0, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 1, 0), [0, 255, 0, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 0, 1), [0, 0, 255, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 1, 1), [255, 255, 0, 255]);
            });
            (0, test_1.default)('renders 5x1 row with block+remainder pixel layout', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=24,s=5,v=1;${RAW_RGB_5X1}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 0, 0), [255, 0, 0, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 1, 0), [0, 255, 0, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 2, 0), [0, 0, 255, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 3, 0), [255, 255, 0, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 4, 0), [255, 0, 255, 255]);
            });
            (0, test_1.default)('renders 4x2 grid with multi-block pixel layout', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=24,s=4,v=2;${RAW_RGB_4X2}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 0, 0), [255, 0, 0, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 1, 0), [0, 255, 0, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 2, 0), [0, 0, 255, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 3, 0), [255, 255, 0, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 0, 1), [255, 0, 255, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 1, 1), [0, 255, 255, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 2, 1), [128, 128, 128, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 3, 1), [255, 255, 255, 255]);
            });
        });
        test_1.default.describe('Storage and dimensions', () => {
            (0, test_1.default)('stores image with correct original dimensions (3x1)', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=24,s=3,v=1;${RAW_RGB_3X1}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
                (0, assert_1.deepStrictEqual)(await getOrigSize(1), [3, 1]);
            });
            (0, test_1.default)('stores image with correct original dimensions (2x2)', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=24,s=2,v=2;${RAW_RGB_2X2}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
                (0, assert_1.deepStrictEqual)(await getOrigSize(1), [2, 2]);
            });
            (0, test_1.default)('stores image with correct original dimensions (5x1)', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=24,s=5,v=1;${RAW_RGB_5X1}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
                (0, assert_1.deepStrictEqual)(await getOrigSize(1), [5, 1]);
            });
            (0, test_1.default)('stores image with correct original dimensions (4x2)', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=24,s=4,v=2;${RAW_RGB_4X2}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
                (0, assert_1.deepStrictEqual)(await getOrigSize(1), [4, 2]);
            });
        });
        test_1.default.describe('Validation', () => {
            (0, test_1.default)('does not render without width (s=)', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=24,v=1;${RAW_RGB_1X1_BLACK}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                (0, assert_1.strictEqual)(await getImageStorageLength(), 0);
            });
            (0, test_1.default)('does not render without height (v=)', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=24,s=1;${RAW_RGB_1X1_BLACK}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                (0, assert_1.strictEqual)(await getImageStorageLength(), 0);
            });
            (0, test_1.default)('does not render without either dimension', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=24;${RAW_RGB_1X1_BLACK}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                (0, assert_1.strictEqual)(await getImageStorageLength(), 0);
            });
            (0, test_1.default)('does not render with insufficient byte count', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=24,s=2,v=2;${RAW_RGB_1X1_BLACK}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                (0, assert_1.strictEqual)(await getImageStorageLength(), 0);
            });
            (0, test_1.default)('query returns EINVAL without dimensions', async () => {
                await ctx.page.evaluate(() => {
                    window.kittyResponse = '';
                    window.term.onData((data) => { window.kittyResponse = data; });
                });
                await ctx.proxy.write(`\x1b_Gi=200,a=q,f=24;${RAW_RGB_1X1_BLACK}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                const response = await ctx.page.evaluate('window.kittyResponse');
                (0, assert_1.strictEqual)(response, '\x1b_Gi=200;EINVAL:width and height required for raw pixel data\x1b\\');
            });
            (0, test_1.default)('query returns EINVAL for insufficient pixel data', async () => {
                await ctx.page.evaluate(() => {
                    window.kittyResponse = '';
                    window.term.onData((data) => { window.kittyResponse = data; });
                });
                await ctx.proxy.write(`\x1b_Gi=201,a=q,f=24,s=2,v=2;${RAW_RGB_1X1_BLACK}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                const response = await ctx.page.evaluate('window.kittyResponse');
                (0, assert_1.strictEqual)(response, '\x1b_Gi=201;EINVAL:insufficient pixel data\x1b\\');
            });
            (0, test_1.default)('query returns OK for valid RGB data with correct dimensions', async () => {
                await ctx.page.evaluate(() => {
                    window.kittyResponse = '';
                    window.term.onData((data) => { window.kittyResponse = data; });
                });
                await ctx.proxy.write(`\x1b_Gi=202,a=q,f=24,s=1,v=1;${RAW_RGB_1X1_RED}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                const response = await ctx.page.evaluate('window.kittyResponse');
                (0, assert_1.strictEqual)(response, '\x1b_Gi=202;OK\x1b\\');
            });
        });
    });
    test_1.default.describe('Raw RGBA pixel format (f=32)', () => {
        test_1.default.describe('Pixel verification', () => {
            (0, test_1.default)('renders 1x1 opaque white pixel', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=32,s=1,v=1;${RAW_RGBA_1X1_WHITE}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 0, 0), [255, 255, 255, 255]);
            });
            (0, test_1.default)('renders 1x1 opaque red pixel', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=32,s=1,v=1;${RAW_RGBA_1X1_RED}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 0, 0), [255, 0, 0, 255]);
            });
            (0, test_1.default)('preserves full transparency (alpha=0)', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=32,s=1,v=1;${RAW_RGBA_1X1_TRANSPARENT}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                const pixel = await getPixel(0, 0, 0, 0);
                (0, assert_1.strictEqual)(pixel?.[3], 0);
            });
            (0, test_1.default)('renders 3x1 strip (red, green, blue opaque)', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=32,s=3,v=1;${RAW_RGBA_3X1}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                const pixels = await getPixels(0, 0, 0, 0, 3, 1);
                (0, assert_1.deepStrictEqual)(pixels?.slice(0, 4), [255, 0, 0, 255]);
                (0, assert_1.deepStrictEqual)(pixels?.slice(4, 8), [0, 255, 0, 255]);
                (0, assert_1.deepStrictEqual)(pixels?.slice(8, 12), [0, 0, 255, 255]);
            });
            (0, test_1.default)('renders 2x2 grid with correct pixel layout', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=32,s=2,v=2;${RAW_RGBA_2X2}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 0, 0), [255, 0, 0, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 1, 0), [0, 255, 0, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 0, 1), [0, 0, 255, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 1, 1), [255, 255, 0, 255]);
            });
            (0, test_1.default)('renders 5x1 row with zero-copy pixel layout', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=32,s=5,v=1;${RAW_RGBA_5X1}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 0, 0), [255, 0, 0, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 1, 0), [0, 255, 0, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 2, 0), [0, 0, 255, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 3, 0), [255, 255, 0, 255]);
                (0, assert_1.deepStrictEqual)(await getPixel(0, 0, 4, 0), [255, 0, 255, 255]);
            });
        });
        test_1.default.describe('Storage and dimensions', () => {
            (0, test_1.default)('stores image with correct original dimensions (3x1)', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=32,s=3,v=1;${RAW_RGBA_3X1}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
                (0, assert_1.deepStrictEqual)(await getOrigSize(1), [3, 1]);
            });
            (0, test_1.default)('stores image with correct original dimensions (2x2)', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=32,s=2,v=2;${RAW_RGBA_2X2}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
                (0, assert_1.deepStrictEqual)(await getOrigSize(1), [2, 2]);
            });
            (0, test_1.default)('stores image with correct original dimensions (5x1)', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=32,s=5,v=1;${RAW_RGBA_5X1}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
                (0, assert_1.deepStrictEqual)(await getOrigSize(1), [5, 1]);
            });
        });
        test_1.default.describe('Validation', () => {
            (0, test_1.default)('does not render without width (s=)', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=32,v=1;${RAW_RGBA_1X1_RED}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                (0, assert_1.strictEqual)(await getImageStorageLength(), 0);
            });
            (0, test_1.default)('does not render without height (v=)', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=32,s=1;${RAW_RGBA_1X1_RED}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                (0, assert_1.strictEqual)(await getImageStorageLength(), 0);
            });
            (0, test_1.default)('does not render without either dimension', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=32;${RAW_RGBA_1X1_RED}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                (0, assert_1.strictEqual)(await getImageStorageLength(), 0);
            });
            (0, test_1.default)('does not render with insufficient byte count', async () => {
                await ctx.proxy.write(`\x1b_Ga=T,f=32,s=2,v=2;${RAW_RGBA_1X1_RED}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                (0, assert_1.strictEqual)(await getImageStorageLength(), 0);
            });
            (0, test_1.default)('query returns EINVAL without dimensions', async () => {
                await ctx.page.evaluate(() => {
                    window.kittyResponse = '';
                    window.term.onData((data) => { window.kittyResponse = data; });
                });
                await ctx.proxy.write(`\x1b_Gi=300,a=q,f=32;${RAW_RGBA_1X1_RED}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                const response = await ctx.page.evaluate('window.kittyResponse');
                (0, assert_1.strictEqual)(response, '\x1b_Gi=300;EINVAL:width and height required for raw pixel data\x1b\\');
            });
            (0, test_1.default)('query returns EINVAL for insufficient pixel data', async () => {
                await ctx.page.evaluate(() => {
                    window.kittyResponse = '';
                    window.term.onData((data) => { window.kittyResponse = data; });
                });
                await ctx.proxy.write(`\x1b_Gi=301,a=q,f=32,s=2,v=2;${RAW_RGBA_1X1_RED}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                const response = await ctx.page.evaluate('window.kittyResponse');
                (0, assert_1.strictEqual)(response, '\x1b_Gi=301;EINVAL:insufficient pixel data\x1b\\');
            });
            (0, test_1.default)('query returns OK for valid RGBA data with correct dimensions', async () => {
                await ctx.page.evaluate(() => {
                    window.kittyResponse = '';
                    window.term.onData((data) => { window.kittyResponse = data; });
                });
                await ctx.proxy.write(`\x1b_Gi=302,a=q,f=32,s=1,v=1;${RAW_RGBA_1X1_RED}\x1b\\`);
                await (0, TestUtils_1.timeout)(100);
                const response = await ctx.page.evaluate('window.kittyResponse');
                (0, assert_1.strictEqual)(response, '\x1b_Gi=302;OK\x1b\\');
            });
        });
    });
    test_1.default.describe('Eviction and memory leak prevention', () => {
        (0, test_1.default)('re-transmit with same i= cleans up old storage entry', async () => {
            await ctx.proxy.write(`\x1b_Ga=T,f=100,i=50;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.has(50)`), true);
            const oldStorageId = await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty')._kittyIdToStorageId.get(50)`);
            (0, assert_1.ok)(oldStorageId !== undefined);
            await ctx.proxy.write(`\x1b_Ga=T,f=100,i=50;${KITTY_RGB_3X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.has(50)`), true);
            const newStorageId = await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty')._kittyIdToStorageId.get(50)`);
            (0, assert_1.ok)(newStorageId !== undefined);
            (0, assert_1.ok)(newStorageId !== oldStorageId);
        });
        (0, test_1.default)('memory limit eviction cleans Kitty handler maps', async () => {
            await ctx.page.evaluate(`
        window.term.reset();
        window.imageAddon?.dispose();
        window.term.resize(80, 48);
        window.imageAddon = new ImageAddon({ storageLimit: 0.5 });
        window.term.loadAddon(window.imageAddon);
      `);
            const positions = [[1, 1], [30, 1], [1, 9], [30, 9], [1, 17], [30, 17]];
            for (let n = 0; n < 6; n++) {
                const [c, r] = positions[n];
                const id = 60 + n;
                await ctx.proxy.write(`\x1b[${r};${c}H\x1b_Ga=T,f=100,i=${id},C=1;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
            }
            await (0, TestUtils_1.pollFor)(ctx.page, 'window.imageAddon._storage._images.size', 6);
            await ctx.proxy.write(`\x1b[25;1H\x1b_Ga=T,f=100,i=66,C=1;${KITTY_MULTICOLOR_200X100_BASE64}\x1b\\`);
            await (0, TestUtils_1.pollFor)(ctx.page, `window.imageAddon._handlers.get('kitty').images.has(60)`, false);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty')._kittyIdToStorageId.has(60)`), false);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.has(66)`), true);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty')._kittyIdToStorageId.has(66)`), true);
            await ctx.page.evaluate('window.term.resize(80, 24)');
        });
        (0, test_1.default)('scrollback eviction cleans Kitty handler maps', async () => {
            await ctx.page.evaluate(`
        window.term.reset();
        window.imageAddon?.dispose();
        window.imageAddon = new ImageAddon();
        window.term.loadAddon(window.imageAddon);
      `);
            await ctx.proxy.write(`\x1b_Ga=T,f=100,i=70;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty').images.has(70)`), true);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty')._kittyIdToStorageId.has(70)`), true);
            await ctx.page.evaluate(() => new Promise(res => {
                const term = window.term;
                const amount = term.options.scrollback + term.rows + 10;
                term.write('\n'.repeat(amount), res);
            }));
            await (0, TestUtils_1.pollFor)(ctx.page, `window.imageAddon._handlers.get('kitty').images.has(70)`, false);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty')._kittyIdToStorageId.has(70)`), false);
        });
        (0, test_1.default)('re-transmit with a=t then a=T cleans old storage before display', async () => {
            await ctx.proxy.write(`\x1b_Ga=T,f=100,i=80;${KITTY_BLACK_1X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await getImageStorageLength(), 1);
            const oldStorageId = await ctx.page.evaluate(`window.imageAddon._handlers.get('kitty')._kittyIdToStorageId.get(80)`);
            (0, assert_1.ok)(oldStorageId !== undefined);
            await ctx.proxy.write(`\x1b_Ga=t,f=100,i=80;${KITTY_RGB_3X1_BASE64}\x1b\\`);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.strictEqual)(await ctx.page.evaluate(`window.imageAddon._storage._images.has(${oldStorageId})`), false);
        });
    });
});
async function getDimensions() {
    const dimensions = await ctx.page.evaluate(`term.dimensions`);
    return {
        cellWidth: Math.round(dimensions.css.cell.width),
        cellHeight: Math.round(dimensions.css.cell.height),
        width: Math.round(dimensions.css.canvas.width),
        height: Math.round(dimensions.css.canvas.height)
    };
}
async function getCursor() {
    return ctx.page.evaluate('[window.term.buffer.active.cursorX, window.term.buffer.active.cursorY]');
}
async function getImageStorageLength() {
    return ctx.page.evaluate('window.imageAddon._storage._images.size');
}
async function getOrigSize(id) {
    return ctx.page.evaluate(`[
    window.imageAddon._storage._images.get(${id}).orig.width,
    window.imageAddon._storage._images.get(${id}).orig.height
  ]`);
}
async function getPixel(col, row, x, y) {
    return ctx.page.evaluate(([col, row, x, y]) => {
        const canvas = window.imageAddon.getImageAtBufferCell(col, row);
        if (!canvas)
            return null;
        const ctx2d = canvas.getContext('2d');
        if (!ctx2d)
            return null;
        return Array.from(ctx2d.getImageData(x, y, 1, 1).data);
    }, [col, row, x, y]);
}
async function getPixels(col, row, x, y, w, h) {
    return ctx.page.evaluate(([col, row, x, y, w, h]) => {
        const canvas = window.imageAddon.getImageAtBufferCell(col, row);
        if (!canvas)
            return null;
        const ctx2d = canvas.getContext('2d');
        if (!ctx2d)
            return null;
        return Array.from(ctx2d.getImageData(x, y, w, h).data);
    }, [col, row, x, y, w, h]);
}
//# sourceMappingURL=KittyGraphics.test.js.map