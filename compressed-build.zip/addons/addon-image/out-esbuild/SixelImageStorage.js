"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var SixelImageStorage_exports = {};
__export(SixelImageStorage_exports, {
  SixelImageStorage: () => SixelImageStorage
});
module.exports = __toCommonJS(SixelImageStorage_exports);
var import_ImageStorage = require("./ImageStorage");
/**
 * Copyright (c) 2020 The xterm.js authors. All rights reserved.
 * @license MIT
 */
class SixelImageStorage {
  constructor(_storage, _opts, _renderer, _terminal) {
    this._storage = _storage;
    this._opts = _opts;
    this._renderer = _renderer;
    this._terminal = _terminal;
  }
  /**
   * Add a sixel image to storage.
   * Cursor behavior depends on the sixelScrolling option (DECSET 80).
   */
  addImage(img) {
    this._storage.addImage(img, this._opts.sixelScrolling);
  }
  /**
   * Only advance text cursor.
   * This is an edge case from empty sixels carrying only a height but no pixels.
   * Partially fixes https://github.com/jerch/xterm-addon-image/issues/37.
   */
  advanceCursor(height) {
    if (this._opts.sixelScrolling) {
      let cellSize = this._renderer.cellSize;
      if (cellSize.width === -1 || cellSize.height === -1) {
        cellSize = import_ImageStorage.CELL_SIZE_DEFAULT;
      }
      const rows = Math.ceil(height / cellSize.height);
      for (let i = 1; i < rows; ++i) {
        this._terminal._core._inputHandler.lineFeed();
      }
    }
  }
}
//# sourceMappingURL=SixelImageStorage.js.map
