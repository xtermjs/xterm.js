"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var IIPImageStorage_exports = {};
__export(IIPImageStorage_exports, {
  IIPImageStorage: () => IIPImageStorage
});
module.exports = __toCommonJS(IIPImageStorage_exports);
/**
 * Copyright (c) 2023 The xterm.js authors. All rights reserved.
 * @license MIT
 */
class IIPImageStorage {
  constructor(_storage) {
    this._storage = _storage;
  }
  /**
   * Add an IIP image to storage.
   * Always uses scrolling mode — cursor advances past the image.
   */
  addImage(img) {
    this._storage.addImage(img, true);
  }
}
//# sourceMappingURL=IIPImageStorage.js.map
