"use strict";
var import_chai = require("chai");
var import_KittyGraphicsTypes = require("./KittyGraphicsTypes");
/**
 * Copyright (c) 2026 The xterm.js authors. All rights reserved.
 * @license MIT
 */
describe("KittyGraphicsTypes", () => {
  describe("parseKittyCommand", () => {
    it("should parse control data with action and format", () => {
      const cmd = (0, import_KittyGraphicsTypes.parseKittyCommand)("a=T,f=100");
      import_chai.assert.strictEqual(cmd.action, "T");
      import_chai.assert.strictEqual(cmd.format, 100);
    });
    it("should parse control data with all options", () => {
      const cmd = (0, import_KittyGraphicsTypes.parseKittyCommand)("a=t,f=32,i=5,s=10,v=20,c=3,r=2,m=1,q=2");
      import_chai.assert.strictEqual(cmd.action, "t");
      import_chai.assert.strictEqual(cmd.format, 32);
      import_chai.assert.strictEqual(cmd.id, 5);
      import_chai.assert.strictEqual(cmd.width, 10);
      import_chai.assert.strictEqual(cmd.height, 20);
      import_chai.assert.strictEqual(cmd.columns, 3);
      import_chai.assert.strictEqual(cmd.rows, 2);
      import_chai.assert.strictEqual(cmd.more, 1);
      import_chai.assert.strictEqual(cmd.quiet, 2);
    });
    it("should handle empty control data", () => {
      const cmd = (0, import_KittyGraphicsTypes.parseKittyCommand)("");
      import_chai.assert.strictEqual(cmd.action, void 0);
      import_chai.assert.strictEqual(cmd.format, void 0);
    });
    it("should parse transmit action", () => {
      const cmd = (0, import_KittyGraphicsTypes.parseKittyCommand)("a=t,f=100");
      import_chai.assert.strictEqual(cmd.action, import_KittyGraphicsTypes.KittyAction.TRANSMIT);
      import_chai.assert.strictEqual(cmd.format, import_KittyGraphicsTypes.KittyFormat.PNG);
    });
    it("should parse delete action", () => {
      const cmd = (0, import_KittyGraphicsTypes.parseKittyCommand)("a=d,i=5");
      import_chai.assert.strictEqual(cmd.action, import_KittyGraphicsTypes.KittyAction.DELETE);
      import_chai.assert.strictEqual(cmd.id, 5);
    });
    it("should parse empty action as empty string", () => {
      const cmd = (0, import_KittyGraphicsTypes.parseKittyCommand)("a=,f=100");
      import_chai.assert.strictEqual(cmd.action, "");
      import_chai.assert.strictEqual(cmd.format, 100);
    });
    it("should leave action undefined when key is not present", () => {
      const cmd = (0, import_KittyGraphicsTypes.parseKittyCommand)("f=100,i=5");
      import_chai.assert.strictEqual(cmd.action, void 0);
      import_chai.assert.strictEqual(cmd.format, 100);
      import_chai.assert.strictEqual(cmd.id, 5);
    });
    it("should parse compression key", () => {
      const cmd = (0, import_KittyGraphicsTypes.parseKittyCommand)("a=t,f=32,o=z");
      import_chai.assert.strictEqual(cmd.action, "t");
      import_chai.assert.strictEqual(cmd.format, 32);
      import_chai.assert.strictEqual(cmd.compression, "z");
    });
    it("should parse cursor movement key", () => {
      const cmd = (0, import_KittyGraphicsTypes.parseKittyCommand)("a=T,f=100,C=1");
      import_chai.assert.strictEqual(cmd.cursorMovement, 1);
    });
    it("should parse cursor movement key C=0", () => {
      const cmd = (0, import_KittyGraphicsTypes.parseKittyCommand)("a=T,f=100,C=0");
      import_chai.assert.strictEqual(cmd.cursorMovement, 0);
    });
    it("should parse x and y offset", () => {
      const cmd = (0, import_KittyGraphicsTypes.parseKittyCommand)("a=T,x=10,y=20");
      import_chai.assert.strictEqual(cmd.x, 10);
      import_chai.assert.strictEqual(cmd.y, 20);
    });
    it("should handle keys without values", () => {
      const cmd = (0, import_KittyGraphicsTypes.parseKittyCommand)("a=t,f=,i=5");
      import_chai.assert.strictEqual(cmd.action, "t");
      import_chai.assert.ok(isNaN(cmd.format));
      import_chai.assert.strictEqual(cmd.id, 5);
    });
    it("should parse z-index key with positive value", () => {
      const cmd = (0, import_KittyGraphicsTypes.parseKittyCommand)("a=T,f=100,z=10");
      import_chai.assert.strictEqual(cmd.zIndex, 10);
    });
    it("should parse z-index key with zero", () => {
      const cmd = (0, import_KittyGraphicsTypes.parseKittyCommand)("a=T,f=100,z=0");
      import_chai.assert.strictEqual(cmd.zIndex, 0);
    });
    it("should parse z-index key with negative value", () => {
      const cmd = (0, import_KittyGraphicsTypes.parseKittyCommand)("a=T,f=100,z=-1");
      import_chai.assert.strictEqual(cmd.zIndex, -1);
    });
    it("should leave zIndex undefined when not specified", () => {
      const cmd = (0, import_KittyGraphicsTypes.parseKittyCommand)("a=T,f=100");
      import_chai.assert.strictEqual(cmd.zIndex, void 0);
    });
    it("should parse delete selector key", () => {
      const cmd = (0, import_KittyGraphicsTypes.parseKittyCommand)("a=d,d=i,i=5");
      import_chai.assert.strictEqual(cmd.action, "d");
      import_chai.assert.strictEqual(cmd.deleteSelector, "i");
      import_chai.assert.strictEqual(cmd.id, 5);
    });
    it("should parse uppercase delete selector", () => {
      const cmd = (0, import_KittyGraphicsTypes.parseKittyCommand)("a=d,d=A");
      import_chai.assert.strictEqual(cmd.deleteSelector, "A");
    });
    it("should parse delete selector d=a (all)", () => {
      const cmd = (0, import_KittyGraphicsTypes.parseKittyCommand)("a=d,d=a");
      import_chai.assert.strictEqual(cmd.deleteSelector, "a");
    });
    it("should leave deleteSelector undefined when not specified", () => {
      const cmd = (0, import_KittyGraphicsTypes.parseKittyCommand)("a=d,i=5");
      import_chai.assert.strictEqual(cmd.deleteSelector, void 0);
    });
    it("should parse placement id key", () => {
      const cmd = (0, import_KittyGraphicsTypes.parseKittyCommand)("a=d,d=i,i=5,p=3");
      import_chai.assert.strictEqual(cmd.placementId, 3);
      import_chai.assert.strictEqual(cmd.deleteSelector, "i");
      import_chai.assert.strictEqual(cmd.id, 5);
    });
    it("should leave placementId undefined when not specified", () => {
      const cmd = (0, import_KittyGraphicsTypes.parseKittyCommand)("a=d,d=i,i=5");
      import_chai.assert.strictEqual(cmd.placementId, void 0);
    });
    it("should parse image number key", () => {
      const cmd = (0, import_KittyGraphicsTypes.parseKittyCommand)("a=t,f=100,I=42");
      import_chai.assert.strictEqual(cmd.imageNumber, 42);
    });
  });
});
//# sourceMappingURL=KittyGraphicsTypes.test.js.map
