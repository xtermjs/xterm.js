"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var KittyImageStorage_exports = {};
__export(KittyImageStorage_exports, {
  KittyImageStorage: () => KittyImageStorage
});
module.exports = __toCommonJS(KittyImageStorage_exports);
/**
 * Copyright (c) 2026 The xterm.js authors. All rights reserved.
 * @license MIT
 */
class KittyImageStorage {
  constructor(_storage) {
    this._storage = _storage;
    this._nextImageId = 1;
    this._images = /* @__PURE__ */ new Map();
    // TODO: Support multiple placements per image. The kitty spec identifies
    // placements by an (image id, placement id) pair — same i + different p
    // values should coexist, and same i + same p should replace the prior
    // placement. Currently we track only one storage entry per kitty image id,
    // so multiple placements of the same image overwrite each other. Fixing
    // this requires changing these maps to Map<number, Map<number, number>>
    // (kittyId → placementId → storageId) and updating addImage/deleteById
    // accordingly. The underlying shared ImageStorage would also need to
    // support multiple entries per logical image.
    this._kittyIdToStorageId = /* @__PURE__ */ new Map();
    this._storageIdToKittyId = /* @__PURE__ */ new Map();
    this._handleStorageImageDeleted = (storageId) => {
      const kittyId = this._storageIdToKittyId.get(storageId);
      if (kittyId !== void 0) {
        this._kittyIdToStorageId.delete(kittyId);
        this._storageIdToKittyId.delete(storageId);
        this._images.delete(kittyId);
      }
    };
    this._previousOnImageDeleted = this._storage.onImageDeleted;
    this._wrappedOnImageDeleted = (storageId) => {
      this._previousOnImageDeleted?.(storageId);
      this._handleStorageImageDeleted(storageId);
    };
    this._storage.onImageDeleted = this._wrappedOnImageDeleted;
  }
  static {
    this._maxStoredImages = 256;
  }
  reset() {
    this._nextImageId = 1;
    this._images.clear();
    this._kittyIdToStorageId.clear();
    this._storageIdToKittyId.clear();
  }
  dispose() {
    this.reset();
    if (this._storage.onImageDeleted === this._wrappedOnImageDeleted) {
      this._storage.onImageDeleted = this._previousOnImageDeleted;
    }
  }
  storeImage(id, imageData) {
    const imageId = id ?? this._nextImageId++;
    const oldStorageId = this._kittyIdToStorageId.get(imageId);
    if (oldStorageId !== void 0) {
      this._storage.deleteImage(oldStorageId);
      this._kittyIdToStorageId.delete(imageId);
      this._storageIdToKittyId.delete(oldStorageId);
    }
    if (!this._images.has(imageId) && this._images.size >= KittyImageStorage._maxStoredImages) {
      this._evictUndisplayedImages();
    }
    this._images.set(imageId, {
      ...imageData,
      id: imageId
    });
    return imageId;
  }
  addImage(kittyId, image, scrolling, layer, zIndex) {
    const oldStorageId = this._kittyIdToStorageId.get(kittyId);
    if (oldStorageId !== void 0) {
      this._storageIdToKittyId.delete(oldStorageId);
    }
    const storageId = this._storage.addImage(image, scrolling, layer, zIndex);
    this._kittyIdToStorageId.set(kittyId, storageId);
    this._storageIdToKittyId.set(storageId, kittyId);
  }
  getImage(kittyId) {
    return this._images.get(kittyId);
  }
  deleteById(kittyId) {
    this._images.delete(kittyId);
    const storageId = this._kittyIdToStorageId.get(kittyId);
    if (storageId !== void 0) {
      this._storage.deleteImage(storageId);
      this._kittyIdToStorageId.delete(kittyId);
      this._storageIdToKittyId.delete(storageId);
    }
  }
  deleteAll() {
    this._images.clear();
    for (const storageId of this._kittyIdToStorageId.values()) {
      this._storage.deleteImage(storageId);
    }
    this._kittyIdToStorageId.clear();
    this._storageIdToKittyId.clear();
  }
  get images() {
    return this._images;
  }
  get kittyIdToStorageId() {
    return this._kittyIdToStorageId;
  }
  get lastImageId() {
    return this._nextImageId - 1;
  }
  _evictUndisplayedImages() {
    for (const [kittyId] of this._images) {
      if (this._images.size <= KittyImageStorage._maxStoredImages / 2) {
        break;
      }
      if (!this._kittyIdToStorageId.has(kittyId)) {
        this._images.delete(kittyId);
      }
    }
  }
}
//# sourceMappingURL=KittyImageStorage.js.map
