"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var KittyGraphicsHandler_exports = {};
__export(KittyGraphicsHandler_exports, {
  KittyGraphicsHandler: () => KittyGraphicsHandler
});
module.exports = __toCommonJS(KittyGraphicsHandler_exports);
var import_ImageRenderer = require("../ImageRenderer");
var import_ImageStorage = require("../ImageStorage");
var import_Base64Decoder = __toESM(require("xterm-wasm-parts/lib/base64/Base64Decoder.wasm"));
var import_KittyGraphicsTypes = require("./KittyGraphicsTypes");
/**
 * Copyright (c) 2026 The xterm.js authors. All rights reserved.
 * @license MIT
 */
const DECODER_KEEP_DATA = 4194304;
const DECODER_INITIAL_DATA = 4194304;
const DECODER_OK = 0;
const MAX_CONTROL_DATA_SIZE = 512;
const SEMICOLON = 59;
class KittyGraphicsHandler {
  constructor(_opts, _renderer, _kittyStorage, _coreTerminal) {
    this._opts = _opts;
    this._renderer = _renderer;
    this._kittyStorage = _kittyStorage;
    this._coreTerminal = _coreTerminal;
    this._aborted = false;
    this._decodeError = false;
    this._activeDecoder = null;
    // Streaming related states
    // True while receiving control data (before semicolon).
    this._inControlData = true;
    // Buffer for control data.
    this._controlData = new Uint32Array(MAX_CONTROL_DATA_SIZE);
    this._controlLength = 0;
    // Pre-calculated encoded size limit
    this._encodedSizeLimit = 0;
    this._totalEncodedSize = 0;
    // Parsed command. These are the control data before semicolon.
    this._parsedCommand = null;
    // Storage related states
    this._pendingTransmissions = /* @__PURE__ */ new Map();
    this._maxEncodedBytes = Math.ceil(this._opts.kittySizeLimit * 4 / 3);
    this._initialEncodedBytes = Math.min(DECODER_INITIAL_DATA, this._maxEncodedBytes);
  }
  reset() {
    this._cleanupAllPending();
    if (this._activeDecoder) {
      this._activeDecoder.release();
      this._activeDecoder = null;
    }
    this._kittyStorage.reset();
  }
  dispose() {
    this.reset();
  }
  _removePendingEntry(key) {
    this._pendingTransmissions.delete(key);
    if (this._lastPendingKey === key) {
      this._lastPendingKey = void 0;
    }
  }
  _cleanupAllPending() {
    for (const pending of this._pendingTransmissions.values()) {
      pending.decoder.release();
    }
    this._pendingTransmissions.clear();
    this._lastPendingKey = void 0;
  }
  start() {
    this._aborted = false;
    this._decodeError = false;
    this._inControlData = true;
    this._controlLength = 0;
    this._parsedCommand = null;
    this._encodedSizeLimit = this._maxEncodedBytes;
    this._totalEncodedSize = 0;
    this._activeDecoder = null;
  }
  put(data, start, end) {
    if (this._aborted) return;
    if (!this._inControlData) {
      this._streamPayload(data, start, end);
    } else {
      let controlEnd = end;
      for (let i = start; i < end; i++) {
        if (data[i] === SEMICOLON) {
          this._inControlData = false;
          controlEnd = i;
          break;
        }
      }
      const copyLength = controlEnd - start;
      if (this._controlLength + copyLength > MAX_CONTROL_DATA_SIZE) {
        this._aborted = true;
        return;
      }
      this._controlData.set(data.subarray(start, controlEnd), this._controlLength);
      this._controlLength += copyLength;
      if (!this._inControlData) {
        this._parsedCommand = (0, import_KittyGraphicsTypes.parseKittyCommand)(this._parseControlDataString());
        if (this._parsedCommand.id !== void 0 && this._parsedCommand.imageNumber !== void 0) {
          this._sendResponse(this._parsedCommand.id, "EINVAL:cannot specify both i and I keys", this._parsedCommand.quiet ?? 0);
          this._aborted = true;
          return;
        }
        if (this._parsedCommand.action === import_KittyGraphicsTypes.KittyAction.DELETE) {
          return;
        }
        const payloadStart = controlEnd + 1;
        if (payloadStart < end) {
          this._streamPayload(data, payloadStart, end);
        }
      }
    }
  }
  // Stream payload bytes into the base64 decoder.
  _streamPayload(data, start, end) {
    if (this._aborted) return;
    const pendingKey = this._parsedCommand?.id ?? this._lastPendingKey ?? 0;
    const pending = this._pendingTransmissions.get(pendingKey);
    const previousEncodedSize = pending?.totalEncodedSize ?? 0;
    this._totalEncodedSize += end - start;
    const cumulativeEncodedSize = previousEncodedSize + this._totalEncodedSize;
    if (cumulativeEncodedSize > this._encodedSizeLimit) {
      const decoderToRelease = this._activeDecoder ?? pending?.decoder;
      if (decoderToRelease) {
        decoderToRelease.release();
      }
      this._activeDecoder = null;
      if (pending) {
        this._removePendingEntry(pendingKey);
      }
      this._aborted = true;
      return;
    }
    if (this._decodeError) return;
    if (pending?.decoder && !this._activeDecoder) {
      this._activeDecoder = pending.decoder;
    }
    if (!this._activeDecoder) {
      this._activeDecoder = new import_Base64Decoder.default(DECODER_KEEP_DATA, this._maxEncodedBytes, this._initialEncodedBytes);
      this._activeDecoder.init();
    }
    if (this._activeDecoder.put(data.subarray(start, end)) !== DECODER_OK) {
      this._activeDecoder.release();
      this._activeDecoder = null;
      this._decodeError = true;
      if (pending) {
        this._removePendingEntry(pendingKey);
      }
    }
  }
  end(success) {
    if (this._aborted || !success) {
      if (this._activeDecoder) {
        this._activeDecoder.release();
        this._activeDecoder = null;
      }
      return true;
    }
    if (this._inControlData) {
      return this._handleNoPayloadCommand();
    }
    const cmd = this._parsedCommand;
    if (cmd.action === import_KittyGraphicsTypes.KittyAction.DELETE) {
      return this._handleDelete(cmd);
    }
    const pendingKey = cmd.id ?? this._lastPendingKey ?? 0;
    const isMoreComing = cmd.more === 1;
    const pending = this._pendingTransmissions.get(pendingKey);
    if (isMoreComing) {
      if (this._activeDecoder) {
        if (pending) {
          pending.totalEncodedSize += this._totalEncodedSize;
          pending.decodeError = pending.decodeError || this._decodeError;
        } else {
          this._pendingTransmissions.set(pendingKey, {
            cmd: { ...cmd },
            decoder: this._activeDecoder,
            totalEncodedSize: this._totalEncodedSize,
            decodeError: this._decodeError
          });
        }
        this._lastPendingKey = pendingKey;
        this._activeDecoder = null;
      }
      return true;
    }
    if (pending) {
      this._lastPendingKey = void 0;
    }
    let decodeError = this._decodeError;
    let finalCmd = cmd;
    let decoder = this._activeDecoder;
    if (pending) {
      finalCmd = pending.cmd;
      decoder = pending.decoder;
      decodeError = decodeError || pending.decodeError;
      this._pendingTransmissions.delete(pendingKey);
    }
    let imageBytes = new Uint8Array(0);
    if (decoder) {
      if (decoder.end() !== DECODER_OK) {
        decodeError = true;
      }
      imageBytes = decoder.data8;
    }
    this._activeDecoder = null;
    const result = this._handleCommandWithBytesAndCmd(finalCmd, imageBytes, decodeError);
    if (decoder) {
      decoder.release();
    }
    return result;
  }
  // Command handling
  _parseControlDataString() {
    let str = "";
    for (let i = 0; i < this._controlLength; i++) {
      str += String.fromCodePoint(this._controlData[i]);
    }
    return str;
  }
  _handleNoPayloadCommand() {
    const cmd = (0, import_KittyGraphicsTypes.parseKittyCommand)(this._parseControlDataString());
    if (cmd.id !== void 0 && cmd.imageNumber !== void 0) {
      this._sendResponse(cmd.id, "EINVAL:cannot specify both i and I keys", cmd.quiet ?? 0);
      return true;
    }
    const action = cmd.action ?? "t";
    switch (action) {
      case import_KittyGraphicsTypes.KittyAction.DELETE:
        return this._handleDelete(cmd);
      case import_KittyGraphicsTypes.KittyAction.QUERY:
        this._sendResponse(cmd.id ?? 0, "OK", cmd.quiet ?? 0);
        return true;
      case import_KittyGraphicsTypes.KittyAction.PLACEMENT:
        return this._handlePlacement(cmd);
      default:
        if (cmd.id !== void 0) {
          this._sendResponse(cmd.id, "EINVAL:unsupported action", cmd.quiet ?? 0);
        }
        return true;
    }
  }
  _handleCommandWithBytesAndCmd(cmd, bytes, decodeError) {
    const action = cmd.action ?? "t";
    switch (action) {
      case import_KittyGraphicsTypes.KittyAction.TRANSMIT: {
        const result = this._handleTransmit(cmd, bytes, decodeError);
        if ((cmd.transmission ?? "d") === "d" && cmd.id !== void 0) {
          if (decodeError) {
            this._sendResponse(cmd.id, "EINVAL:invalid base64 data", cmd.quiet ?? 0);
          } else if (bytes.length > 0) {
            this._sendResponse(cmd.id, "OK", cmd.quiet ?? 0);
          }
        }
        return result;
      }
      case import_KittyGraphicsTypes.KittyAction.TRANSMIT_DISPLAY:
        return this._handleTransmitDisplay(cmd, bytes, decodeError);
      case import_KittyGraphicsTypes.KittyAction.QUERY:
        return this._handleQuery(cmd, bytes, decodeError);
      case import_KittyGraphicsTypes.KittyAction.PLACEMENT:
        return this._handlePlacement(cmd);
      default:
        if (cmd.id !== void 0) {
          this._sendResponse(cmd.id, "EINVAL:unsupported action", cmd.quiet ?? 0);
        }
        return true;
    }
  }
  _handlePlacement(cmd) {
    if (cmd.id === void 0) {
      return true;
    }
    const id = cmd.id;
    const image = this._kittyStorage.getImage(id);
    if (!image) {
      this._sendResponse(id, "ENOENT:image not found", cmd.quiet ?? 0, cmd.placementId);
      return true;
    }
    const result = this._displayImage(image, cmd);
    return result.then((success) => {
      this._sendResponse(id, success ? "OK" : "EINVAL:image rendering failed", cmd.quiet ?? 0, cmd.placementId);
      return true;
    });
  }
  _handleTransmit(cmd, bytes, decodeError) {
    const transmission = cmd.transmission ?? "d";
    if (transmission !== "d") {
      if (cmd.id !== void 0) {
        this._sendResponse(cmd.id, "EINVAL:unsupported transmission medium", cmd.quiet ?? 0);
      }
      return true;
    }
    if (decodeError || bytes.length === 0) return true;
    this._kittyStorage.storeImage(cmd.id, {
      data: new Blob([bytes]),
      width: cmd.width ?? 0,
      height: cmd.height ?? 0,
      format: cmd.format ?? import_KittyGraphicsTypes.KittyFormat.RGBA,
      compression: cmd.compression ?? ""
    });
    return true;
  }
  _handleTransmitDisplay(cmd, bytes, decodeError) {
    if (decodeError) {
      if (cmd.id !== void 0) {
        this._sendResponse(cmd.id, "EINVAL:invalid base64 data", cmd.quiet ?? 0);
      }
      return true;
    }
    this._handleTransmit(cmd, bytes, decodeError);
    const id = cmd.id ?? this._kittyStorage.lastImageId;
    const image = this._kittyStorage.getImage(id);
    if (image) {
      const result = this._displayImage(image, cmd);
      if (cmd.id !== void 0) {
        return result.then((success) => {
          this._sendResponse(id, success ? "OK" : "EINVAL:image rendering failed", cmd.quiet ?? 0);
          return true;
        });
      }
      return result.then(() => true);
    }
    return true;
  }
  _handleQuery(cmd, bytes, decodeError) {
    const id = cmd.id ?? 0;
    const quiet = cmd.quiet ?? 0;
    const transmission = cmd.transmission ?? "d";
    if (transmission !== "d") {
      this._sendResponse(id, "EINVAL:unsupported transmission medium", quiet);
      return true;
    }
    if (decodeError) {
      this._sendResponse(id, "EINVAL:invalid base64 data", quiet);
      return true;
    }
    if (bytes.length === 0) {
      this._sendResponse(id, "OK", quiet);
      return true;
    }
    const format = cmd.format ?? import_KittyGraphicsTypes.KittyFormat.RGBA;
    if (format === import_KittyGraphicsTypes.KittyFormat.PNG) {
      this._sendResponse(id, "OK", quiet);
    } else {
      const width = cmd.width ?? 0;
      const height = cmd.height ?? 0;
      if (!width || !height) {
        this._sendResponse(id, "EINVAL:width and height required for raw pixel data", quiet);
        return true;
      }
      const bytesPerPixel = format === import_KittyGraphicsTypes.KittyFormat.RGBA ? import_KittyGraphicsTypes.BYTES_PER_PIXEL_RGBA : import_KittyGraphicsTypes.BYTES_PER_PIXEL_RGB;
      const expectedBytes = width * height * bytesPerPixel;
      if (bytes.length < expectedBytes) {
        this._sendResponse(id, `EINVAL:insufficient pixel data`, quiet);
        return true;
      }
      this._sendResponse(id, "OK", quiet);
    }
    return true;
  }
  _handleDelete(cmd) {
    const selector = cmd.deleteSelector ?? "a";
    switch (selector) {
      case "a":
      case "A":
        this._cleanupAllPending();
        this._kittyStorage.deleteAll();
        break;
      case "i":
      case "I":
        if (cmd.id !== void 0) {
          const pending = this._pendingTransmissions.get(cmd.id);
          if (pending) {
            pending.decoder.release();
          }
          this._removePendingEntry(cmd.id);
          this._kittyStorage.deleteById(cmd.id);
        }
        break;
      default:
        break;
    }
    return true;
  }
  _sendResponse(id, message, quiet, placementId) {
    const isOk = message === "OK";
    if (isOk && quiet === 1) return;
    if (!isOk && quiet === 2) return;
    const pPart = placementId ? `,p=${placementId}` : "";
    const response = `\x1B_Gi=${id}${pPart};${message}\x1B\\`;
    this._coreTerminal._core.coreService.triggerDataEvent(response);
  }
  // Image display
  _displayImage(image, cmd) {
    return this._decodeAndDisplay(image, cmd).then(() => true).catch(() => false);
  }
  async _decodeAndDisplay(image, cmd) {
    let bitmap = await this._createBitmap(image);
    try {
      const cropX = Math.max(0, cmd.x ?? 0);
      const cropY = Math.max(0, cmd.y ?? 0);
      const cropW = cmd.sourceWidth || bitmap.width - cropX;
      const cropH = cmd.sourceHeight || bitmap.height - cropY;
      const maxCropW = Math.max(0, bitmap.width - cropX);
      const maxCropH = Math.max(0, bitmap.height - cropY);
      const finalCropW = Math.max(0, Math.min(cropW, maxCropW));
      const finalCropH = Math.max(0, Math.min(cropH, maxCropH));
      if (finalCropW === 0 || finalCropH === 0) {
        throw new Error("invalid source rectangle");
      }
      if (cropX !== 0 || cropY !== 0 || finalCropW !== bitmap.width || finalCropH !== bitmap.height) {
        const cropped = await createImageBitmap(bitmap, cropX, cropY, finalCropW, finalCropH);
        bitmap.close();
        bitmap = cropped;
      }
      const cw = this._renderer.dimensions?.css.cell.width || import_ImageStorage.CELL_SIZE_DEFAULT.width;
      const ch = this._renderer.dimensions?.css.cell.height || import_ImageStorage.CELL_SIZE_DEFAULT.height;
      let imgCols;
      let imgRows;
      if (cmd.columns !== void 0 && cmd.rows !== void 0) {
        imgCols = cmd.columns;
        imgRows = cmd.rows;
      } else if (cmd.columns !== void 0) {
        imgCols = cmd.columns;
        imgRows = Math.max(1, Math.ceil(bitmap.height / bitmap.width * (imgCols * cw) / ch));
      } else if (cmd.rows !== void 0) {
        imgRows = cmd.rows;
        imgCols = Math.max(1, Math.ceil(bitmap.width / bitmap.height * (imgRows * ch) / cw));
      } else {
        imgCols = Math.ceil(bitmap.width / cw);
        imgRows = Math.ceil(bitmap.height / ch);
      }
      let w = bitmap.width;
      let h = bitmap.height;
      if (cmd.columns !== void 0 || cmd.rows !== void 0) {
        w = Math.round(imgCols * cw);
        h = Math.round(imgRows * ch);
      }
      if (w * h > this._opts.pixelLimit) {
        throw new Error("image exceeds pixel limit");
      }
      const buffer = this._coreTerminal._core.buffer;
      const savedX = buffer.x;
      const savedY = buffer.y;
      const savedYbase = buffer.ybase;
      const wantsBottom = cmd.zIndex !== void 0 && cmd.zIndex < 0;
      const layer = wantsBottom ? "bottom" : "top";
      if (w !== bitmap.width || h !== bitmap.height) {
        const scaled = await createImageBitmap(bitmap, { resizeWidth: w, resizeHeight: h });
        bitmap.close();
        bitmap = scaled;
      }
      const xOffset = Math.min(Math.max(0, cmd.xOffset ?? 0), cw - 1);
      const yOffset = Math.min(Math.max(0, cmd.yOffset ?? 0), ch - 1);
      if (xOffset !== 0 || yOffset !== 0) {
        const canvasW = cmd.columns !== void 0 ? Math.round(imgCols * cw) : bitmap.width + xOffset;
        const canvasH = cmd.rows !== void 0 ? Math.round(imgRows * ch) : bitmap.height + yOffset;
        const offsetCanvas = import_ImageRenderer.ImageRenderer.createCanvas(window.document, canvasW, canvasH);
        const offsetCtx = offsetCanvas.getContext("2d");
        if (!offsetCtx) {
          throw new Error("Failed to create offset canvas context");
        }
        offsetCtx.drawImage(bitmap, xOffset, yOffset);
        const offsetBitmap = await createImageBitmap(offsetCanvas);
        offsetCanvas.width = offsetCanvas.height = 0;
        bitmap.close();
        bitmap = offsetBitmap;
        w = bitmap.width;
        h = bitmap.height;
        if (w * h > this._opts.pixelLimit) {
          throw new Error("image exceeds pixel limit");
        }
        if (cmd.columns === void 0) {
          imgCols = Math.ceil(bitmap.width / cw);
        }
        if (cmd.rows === void 0) {
          imgRows = Math.ceil(bitmap.height / ch);
        }
      }
      const zIndex = cmd.zIndex ?? 0;
      this._kittyStorage.addImage(image.id, bitmap, true, layer, zIndex);
      bitmap = void 0;
      if (cmd.cursorMovement === 1) {
        const scrolled = buffer.ybase - savedYbase;
        buffer.x = savedX;
        buffer.y = Math.max(savedY - scrolled, 0);
      } else {
        buffer.x = Math.min(savedX + imgCols, this._coreTerminal.cols);
      }
    } catch (e) {
      bitmap?.close();
      throw e;
    }
  }
  // Create ImageBitmap from already-decoded image data.
  async _createBitmap(image) {
    let bytes = new Uint8Array(await image.data.arrayBuffer());
    if (image.compression === import_KittyGraphicsTypes.KittyCompression.ZLIB) {
      bytes = await this._decompressZlib(bytes);
    }
    if (image.format === import_KittyGraphicsTypes.KittyFormat.PNG) {
      const blob = new Blob([bytes], { type: "image/png" });
      if (!window.createImageBitmap) {
        const url = URL.createObjectURL(blob);
        const img = new Image();
        return new Promise((resolve, reject) => {
          img.addEventListener("load", () => {
            URL.revokeObjectURL(url);
            const canvas = import_ImageRenderer.ImageRenderer.createCanvas(window.document, img.width, img.height);
            canvas.getContext("2d")?.drawImage(img, 0, 0);
            createImageBitmap(canvas).then(resolve).catch(reject);
          });
          img.addEventListener("error", () => {
            URL.revokeObjectURL(url);
            reject(new Error("Failed to load image"));
          });
          img.src = url;
        });
      }
      return createImageBitmap(blob);
    }
    const width = image.width;
    const height = image.height;
    if (!width || !height) {
      throw new Error("Width and height required for raw pixel data");
    }
    const bytesPerPixel = image.format === import_KittyGraphicsTypes.KittyFormat.RGBA ? import_KittyGraphicsTypes.BYTES_PER_PIXEL_RGBA : import_KittyGraphicsTypes.BYTES_PER_PIXEL_RGB;
    const expectedBytes = width * height * bytesPerPixel;
    if (bytes.length < expectedBytes) {
      throw new Error("Insufficient pixel data");
    }
    const pixelCount = width * height;
    if (image.format === import_KittyGraphicsTypes.KittyFormat.RGBA) {
      return createImageBitmap(new ImageData(new Uint8ClampedArray(bytes.buffer, bytes.byteOffset, pixelCount * import_KittyGraphicsTypes.BYTES_PER_PIXEL_RGBA), width, height));
    }
    const data = new Uint8ClampedArray(pixelCount * import_KittyGraphicsTypes.BYTES_PER_PIXEL_RGBA);
    const src32 = new Uint32Array(bytes.buffer, bytes.byteOffset, Math.floor(bytes.byteLength / 4));
    const dst32 = new Uint32Array(data.buffer);
    const alignedPixels = pixelCount & ~3;
    let srcOffset = 0;
    let dstOffset = 0;
    for (let i = 0; i < alignedPixels; i += 4) {
      const b0 = src32[srcOffset++];
      const b1 = src32[srcOffset++];
      const b2 = src32[srcOffset++];
      dst32[dstOffset++] = b0 & 16777215 | 4278190080;
      dst32[dstOffset++] = (b0 >>> 24 | b1 << 8) & 16777215 | 4278190080;
      dst32[dstOffset++] = (b1 >>> 16 | b2 << 16) & 16777215 | 4278190080;
      dst32[dstOffset++] = b2 >>> 8 | 4278190080;
    }
    let srcByte = alignedPixels * import_KittyGraphicsTypes.BYTES_PER_PIXEL_RGB;
    let dstByte = alignedPixels * import_KittyGraphicsTypes.BYTES_PER_PIXEL_RGBA;
    for (let i = alignedPixels; i < pixelCount; i++) {
      data[dstByte] = bytes[srcByte];
      data[dstByte + 1] = bytes[srcByte + 1];
      data[dstByte + 2] = bytes[srcByte + 2];
      data[dstByte + 3] = import_KittyGraphicsTypes.ALPHA_OPAQUE;
      srcByte += import_KittyGraphicsTypes.BYTES_PER_PIXEL_RGB;
      dstByte += import_KittyGraphicsTypes.BYTES_PER_PIXEL_RGBA;
    }
    return createImageBitmap(new ImageData(data, width, height));
  }
  async _decompressZlib(compressed) {
    try {
      return await this._decompress(compressed, "deflate");
    } catch {
      return await this._decompress(compressed, "deflate-raw");
    }
  }
  async _decompress(compressed, format) {
    const ds = new DecompressionStream(format);
    const writer = ds.writable.getWriter();
    writer.write(compressed);
    writer.close();
    const chunks = [];
    const reader = ds.readable.getReader();
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value);
    }
    const totalLength = chunks.reduce((sum, chunk) => sum + chunk.length, 0);
    const result = new Uint8Array(totalLength);
    let offset = 0;
    for (const chunk of chunks) {
      result.set(chunk, offset);
      offset += chunk.length;
    }
    return result;
  }
  get images() {
    return this._kittyStorage.images;
  }
  get _kittyIdToStorageId() {
    return this._kittyStorage.kittyIdToStorageId;
  }
  get pendingTransmissions() {
    return this._pendingTransmissions;
  }
}
//# sourceMappingURL=KittyGraphicsHandler.js.map
