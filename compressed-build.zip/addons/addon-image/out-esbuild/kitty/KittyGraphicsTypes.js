"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var KittyGraphicsTypes_exports = {};
__export(KittyGraphicsTypes_exports, {
  ALPHA_OPAQUE: () => ALPHA_OPAQUE,
  BYTES_PER_PIXEL_RGB: () => BYTES_PER_PIXEL_RGB,
  BYTES_PER_PIXEL_RGBA: () => BYTES_PER_PIXEL_RGBA,
  KittyAction: () => KittyAction,
  KittyCompression: () => KittyCompression,
  KittyFormat: () => KittyFormat,
  KittyKey: () => KittyKey,
  parseKittyCommand: () => parseKittyCommand
});
module.exports = __toCommonJS(KittyGraphicsTypes_exports);
/**
 * Copyright (c) 2026 The xterm.js authors. All rights reserved.
 * @license MIT
 *
 * Kitty graphics protocol types, constants, and parsing utilities.
 */
var KittyAction = /* @__PURE__ */ ((KittyAction2) => {
  KittyAction2["TRANSMIT"] = "t";
  KittyAction2["TRANSMIT_DISPLAY"] = "T";
  KittyAction2["QUERY"] = "q";
  KittyAction2["PLACEMENT"] = "p";
  KittyAction2["DELETE"] = "d";
  return KittyAction2;
})(KittyAction || {});
var KittyFormat = /* @__PURE__ */ ((KittyFormat2) => {
  KittyFormat2[KittyFormat2["RGB"] = 24] = "RGB";
  KittyFormat2[KittyFormat2["RGBA"] = 32] = "RGBA";
  KittyFormat2[KittyFormat2["PNG"] = 100] = "PNG";
  return KittyFormat2;
})(KittyFormat || {});
var KittyCompression = /* @__PURE__ */ ((KittyCompression2) => {
  KittyCompression2["NONE"] = "";
  KittyCompression2["ZLIB"] = "z";
  return KittyCompression2;
})(KittyCompression || {});
var KittyKey = /* @__PURE__ */ ((KittyKey2) => {
  KittyKey2["ACTION"] = "a";
  KittyKey2["FORMAT"] = "f";
  KittyKey2["ID"] = "i";
  KittyKey2["IMAGE_NUMBER"] = "I";
  KittyKey2["WIDTH"] = "s";
  KittyKey2["HEIGHT"] = "v";
  KittyKey2["X_OFFSET"] = "x";
  KittyKey2["Y_OFFSET"] = "y";
  KittyKey2["SOURCE_WIDTH"] = "w";
  KittyKey2["SOURCE_HEIGHT"] = "h";
  KittyKey2["X_PLACEMENT_OFFSET"] = "X";
  KittyKey2["Y_PLACEMENT_OFFSET"] = "Y";
  KittyKey2["COLUMNS"] = "c";
  KittyKey2["ROWS"] = "r";
  KittyKey2["MORE"] = "m";
  KittyKey2["COMPRESSION"] = "o";
  KittyKey2["QUIET"] = "q";
  KittyKey2["CURSOR_MOVEMENT"] = "C";
  KittyKey2["Z_INDEX"] = "z";
  KittyKey2["TRANSMISSION"] = "t";
  KittyKey2["DELETE_SELECTOR"] = "d";
  KittyKey2["PLACEMENT_ID"] = "p";
  return KittyKey2;
})(KittyKey || {});
const BYTES_PER_PIXEL_RGB = 3;
const BYTES_PER_PIXEL_RGBA = 4;
const ALPHA_OPAQUE = 255;
function parseKittyCommand(data) {
  const cmd = {};
  const parts = data.split(",");
  for (const part of parts) {
    const eqIdx = part.indexOf("=");
    if (eqIdx === -1) continue;
    const key = part.substring(0, eqIdx);
    const value = part.substring(eqIdx + 1);
    if (key === "a" /* ACTION */) {
      cmd.action = value;
      continue;
    }
    if (key === "o" /* COMPRESSION */) {
      cmd.compression = value;
      continue;
    }
    if (key === "t" /* TRANSMISSION */) {
      cmd.transmission = value;
      continue;
    }
    if (key === "d" /* DELETE_SELECTOR */) {
      cmd.deleteSelector = value;
      continue;
    }
    const numValue = parseInt(value);
    switch (key) {
      case "f" /* FORMAT */:
        cmd.format = numValue;
        break;
      case "i" /* ID */:
        cmd.id = numValue;
        break;
      case "I" /* IMAGE_NUMBER */:
        cmd.imageNumber = numValue;
        break;
      case "s" /* WIDTH */:
        cmd.width = numValue;
        break;
      case "v" /* HEIGHT */:
        cmd.height = numValue;
        break;
      case "x" /* X_OFFSET */:
        cmd.x = numValue;
        break;
      case "y" /* Y_OFFSET */:
        cmd.y = numValue;
        break;
      case "w" /* SOURCE_WIDTH */:
        cmd.sourceWidth = numValue;
        break;
      case "h" /* SOURCE_HEIGHT */:
        cmd.sourceHeight = numValue;
        break;
      case "X" /* X_PLACEMENT_OFFSET */:
        cmd.xOffset = numValue;
        break;
      case "Y" /* Y_PLACEMENT_OFFSET */:
        cmd.yOffset = numValue;
        break;
      case "c" /* COLUMNS */:
        cmd.columns = numValue;
        break;
      case "r" /* ROWS */:
        cmd.rows = numValue;
        break;
      case "m" /* MORE */:
        cmd.more = numValue;
        break;
      case "q" /* QUIET */:
        cmd.quiet = numValue;
        break;
      case "C" /* CURSOR_MOVEMENT */:
        cmd.cursorMovement = numValue;
        break;
      case "z" /* Z_INDEX */:
        cmd.zIndex = numValue;
        break;
      case "p" /* PLACEMENT_ID */:
        cmd.placementId = numValue;
        break;
    }
  }
  return cmd;
}
//# sourceMappingURL=KittyGraphicsTypes.js.map
