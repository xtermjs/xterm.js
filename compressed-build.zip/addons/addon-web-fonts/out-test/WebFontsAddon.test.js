"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const test_1 = __importDefault(require("@playwright/test"));
const assert_1 = require("assert");
const TestUtils_1 = require("../../../test/playwright/TestUtils");
let ctx;
test_1.default.beforeAll(async ({ browser }) => {
    ctx = await (0, TestUtils_1.createTestContext)(browser);
    await (0, TestUtils_1.openTerminal)(ctx, { cols: 40 });
});
test_1.default.afterAll(async () => await ctx.page.close());
test_1.default.describe('WebFontsAddon', () => {
    test_1.default.beforeEach(async () => {
        const empty = await await getDocumentFonts();
        (0, assert_1.deepStrictEqual)(empty, []);
    });
    test_1.default.afterEach(async () => {
        await ctx.page.evaluate(`
      document.styleSheets[0].deleteRule(1);
      document.styleSheets[0].deleteRule(0);
      document.fonts.clear();
    `);
    });
    test_1.default.describe('font loading at runtime', () => {
        (0, test_1.default)('loadFonts (JS)', async () => {
            await ctx.page.evaluate(`
        const ff1 = new FontFace('Kongtext', "url(/kongtext.regular.ttf) format('truetype')");
        const ff2 = new FontFace('BPdots', "url(/bpdots.regular.otf) format('opentype')");
        loadFonts([ff1, ff2]);
      `);
            (0, assert_1.deepStrictEqual)(await getDocumentFonts(), [{ family: 'Kongtext', status: 'loaded' }, { family: 'BPdots', status: 'loaded' }]);
        });
        (0, test_1.default)('loadFonts (CSS, unquoted)', async () => {
            await ctx.page.evaluate(`
        document.styleSheets[0].insertRule("@font-face {font-family: Kongtext; src: url(/kongtext.regular.ttf) format('truetype')}", 0);
        document.styleSheets[0].insertRule("@font-face {font-family: BPdots; src: url(/bpdots.regular.otf) format('opentype')}", 1);
        loadFonts(['Kongtext', 'BPdots']);
      `);
            (0, assert_1.deepStrictEqual)(await getDocumentFonts(), [{ family: 'Kongtext', status: 'loaded' }, { family: 'BPdots', status: 'loaded' }]);
        });
        (0, test_1.default)('loadFonts (CSS, quoted)', async ({ browser }) => {
            await ctx.page.evaluate(`
        document.styleSheets[0].insertRule("@font-face {font-family: 'Kongtext'; src: url(/kongtext.regular.ttf) format('truetype')}", 0);
        document.styleSheets[0].insertRule("@font-face {font-family: 'BPdots'; src: url(/bpdots.regular.otf) format('opentype')}", 1);
        loadFonts(['Kongtext', 'BPdots']);
      `);
            if (browser.browserType().name() === 'firefox') {
                (0, assert_1.deepStrictEqual)(await getDocumentFonts(), [{ family: '"Kongtext"', status: 'loaded' }, { family: '"BPdots"', status: 'loaded' }]);
            }
            else {
                (0, assert_1.deepStrictEqual)(await getDocumentFonts(), [{ family: 'Kongtext', status: 'loaded' }, { family: 'BPdots', status: 'loaded' }]);
            }
        });
        (0, test_1.default)('FontFace hashing', async () => {
            await ctx.page.evaluate(`
        const ff1 = new FontFace('Kongtext', "url(/kongtext.regular.ttf) format('truetype')");
        const ff2 = new FontFace('BPdots', "url(/bpdots.regular.otf) format('opentype')");
        loadFonts([ff1, ff2]);
        loadFonts([ff1, ff2]);
        loadFonts([ff1, ff2]).then(() => loadFonts([ff1, ff2]));
      `);
            (0, assert_1.deepStrictEqual)(await getDocumentFonts(), [{ family: 'Kongtext', status: 'loaded' }, { family: 'BPdots', status: 'loaded' }]);
        });
        (0, test_1.default)('autoload & relayout from ctor', async ({ browser }) => {
            const data = await ctx.page.evaluate(`
          document.styleSheets[0].insertRule("@font-face {font-family: Kongtext; src: url(/kongtext.regular.ttf) format('truetype'); unicode-range: U+00A0-00FF}", 0);
        `);
            (0, assert_1.deepStrictEqual)(await getDocumentFonts(), [{ family: 'Kongtext', status: 'unloaded' }]);
            await ctx.page.evaluate(`
          window.helperTerm = new Terminal({fontFamily: '"Kongtext", ' + term.options.fontFamily});
          window.helperTerm.open(term.element);
        `);
            if (browser.browserType().name() === 'webkit') {
                (0, assert_1.deepStrictEqual)(await getDocumentFonts(), [{ family: 'Kongtext', status: 'loaded' }]);
            }
            else {
                (0, assert_1.deepStrictEqual)(await getDocumentFonts(), [{ family: 'Kongtext', status: 'unloaded' }]);
            }
            await ctx.page.evaluate(`
          window.helperTerm.dispose();
          window.helperTerm = new Terminal({fontFamily: '"Kongtext", ' + term.options.fontFamily});
          window._webfontsAddon = new WebFontsAddon();
          window.helperTerm.loadAddon(window._webfontsAddon);
          window.helperTerm.open(term.element);
        `);
            await (0, TestUtils_1.timeout)(100);
            (0, assert_1.deepStrictEqual)(await getDocumentFonts(), [{ family: 'Kongtext', status: 'loaded' }]);
            await ctx.page.evaluate(`
          window.helperTerm.dispose();
          window._webfontsAddon.dispose();
        `);
        });
    });
});
async function getDocumentFonts() {
    return ctx.page.evaluate(`Array.from(document.fonts).map(ff => ({family: ff.family, status: ff.status}))`);
}
//# sourceMappingURL=WebFontsAddon.test.js.map