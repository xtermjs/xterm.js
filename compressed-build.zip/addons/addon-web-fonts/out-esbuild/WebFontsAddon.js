"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var WebFontsAddon_exports = {};
__export(WebFontsAddon_exports, {
  WebFontsAddon: () => WebFontsAddon,
  loadFonts: () => loadFonts
});
module.exports = __toCommonJS(WebFontsAddon_exports);
/**
 * Copyright (c) 2024 The xterm.js authors. All rights reserved.
 * @license MIT
 */
function unquote(s) {
  if (s[0] === '"' && s[s.length - 1] === '"') return s.slice(1, -1);
  if (s[0] === "'" && s[s.length - 1] === "'") return s.slice(1, -1);
  return s;
}
function quote(s) {
  const pos = s.match(/([-_a-zA-Z0-9\xA0-\u{10FFFF}]+)/u);
  const neg = s.match(/^(-?\d|--)/m);
  if (!neg && pos && pos[1] === s) return s;
  return `"${s.replace(/"/g, '\\"')}"`;
}
function splitFamily(family) {
  if (!family) return [];
  return family.split(",").map((e) => unquote(e.trim()));
}
function createFamily(families) {
  return families.map(quote).join(", ");
}
function hashFontFace(ff) {
  return JSON.stringify([
    unquote(ff.family),
    ff.stretch,
    ff.style,
    ff.unicodeRange,
    ff.weight
  ]);
}
function _loadFonts(fonts) {
  const ffs = Array.from(document.fonts);
  if (!fonts || !fonts.length) {
    return Promise.all(ffs.map((ff) => ff.load()));
  }
  let toLoad = [];
  const ffsHashed = ffs.map((ff) => hashFontFace(ff));
  for (const font of fonts) {
    if (font instanceof FontFace) {
      const fontHashed = hashFontFace(font);
      const idx = ffsHashed.indexOf(fontHashed);
      if (idx === -1) {
        document.fonts.add(font);
        ffs.push(font);
        ffsHashed.push(fontHashed);
        toLoad.push(font);
      } else {
        toLoad.push(ffs[idx]);
      }
    } else {
      const familyFiltered = ffs.filter((ff) => font === unquote(ff.family));
      toLoad = toLoad.concat(familyFiltered);
      if (!familyFiltered.length) {
        return Promise.reject(`font family "${font}" not registered in document.fonts`);
      }
    }
  }
  return Promise.all(toLoad.map((ff) => ff.load()));
}
function loadFonts(fonts) {
  return document.fonts.ready.then(() => _loadFonts(fonts));
}
class WebFontsAddon {
  constructor(initialRelayout = true) {
    this.initialRelayout = initialRelayout;
  }
  dispose() {
    this._term = void 0;
  }
  activate(term) {
    this._term = term;
    if (this.initialRelayout) {
      document.fonts.ready.then(() => this.relayout());
    }
  }
  loadFonts(fonts) {
    return loadFonts(fonts);
  }
  async relayout() {
    if (!this._term) {
      return;
    }
    await document.fonts.ready;
    const family = this._term.options.fontFamily;
    const families = splitFamily(family);
    const webFamilies = Array.from(new Set(Array.from(document.fonts).map((e) => unquote(e.family))));
    const dirty = [];
    const clean = [];
    for (const fam of families) {
      (webFamilies.indexOf(fam) !== -1 ? dirty : clean).push(fam);
    }
    if (!dirty.length) {
      return;
    }
    await _loadFonts(dirty);
    if (this._term) {
      this._term.options.fontFamily = clean.length ? createFamily(clean) : "monospace";
      this._term.options.fontFamily = family;
    }
  }
}
//# sourceMappingURL=WebFontsAddon.js.map
