"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var import_test = __toESM(require("@playwright/test"));
var import_assert = require("assert");
var import_TestUtils = require("../../../test/playwright/TestUtils");
/**
 * Copyright (c) 2024 The xterm.js authors. All rights reserved.
 * @license MIT
 */
let ctx;
import_test.default.beforeAll(async ({ browser }) => {
  ctx = await (0, import_TestUtils.createTestContext)(browser);
  await (0, import_TestUtils.openTerminal)(ctx, { cols: 40 });
});
import_test.default.afterAll(async () => await ctx.page.close());
import_test.default.describe("WebFontsAddon", () => {
  import_test.default.beforeEach(async () => {
    const empty = await await getDocumentFonts();
    (0, import_assert.deepStrictEqual)(empty, []);
  });
  import_test.default.afterEach(async () => {
    await ctx.page.evaluate(`
      document.styleSheets[0].deleteRule(1);
      document.styleSheets[0].deleteRule(0);
      document.fonts.clear();
    `);
  });
  import_test.default.describe("font loading at runtime", () => {
    (0, import_test.default)("loadFonts (JS)", async () => {
      await ctx.page.evaluate(`
        const ff1 = new FontFace('Kongtext', "url(/kongtext.regular.ttf) format('truetype')");
        const ff2 = new FontFace('BPdots', "url(/bpdots.regular.otf) format('opentype')");
        loadFonts([ff1, ff2]);
      `);
      (0, import_assert.deepStrictEqual)(await getDocumentFonts(), [{ family: "Kongtext", status: "loaded" }, { family: "BPdots", status: "loaded" }]);
    });
    (0, import_test.default)("loadFonts (CSS, unquoted)", async () => {
      await ctx.page.evaluate(`
        document.styleSheets[0].insertRule("@font-face {font-family: Kongtext; src: url(/kongtext.regular.ttf) format('truetype')}", 0);
        document.styleSheets[0].insertRule("@font-face {font-family: BPdots; src: url(/bpdots.regular.otf) format('opentype')}", 1);
        loadFonts(['Kongtext', 'BPdots']);
      `);
      (0, import_assert.deepStrictEqual)(await getDocumentFonts(), [{ family: "Kongtext", status: "loaded" }, { family: "BPdots", status: "loaded" }]);
    });
    (0, import_test.default)("loadFonts (CSS, quoted)", async ({ browser }) => {
      await ctx.page.evaluate(`
        document.styleSheets[0].insertRule("@font-face {font-family: 'Kongtext'; src: url(/kongtext.regular.ttf) format('truetype')}", 0);
        document.styleSheets[0].insertRule("@font-face {font-family: 'BPdots'; src: url(/bpdots.regular.otf) format('opentype')}", 1);
        loadFonts(['Kongtext', 'BPdots']);
      `);
      if (browser.browserType().name() === "firefox") {
        (0, import_assert.deepStrictEqual)(await getDocumentFonts(), [{ family: '"Kongtext"', status: "loaded" }, { family: '"BPdots"', status: "loaded" }]);
      } else {
        (0, import_assert.deepStrictEqual)(await getDocumentFonts(), [{ family: "Kongtext", status: "loaded" }, { family: "BPdots", status: "loaded" }]);
      }
    });
    (0, import_test.default)("FontFace hashing", async () => {
      await ctx.page.evaluate(`
        const ff1 = new FontFace('Kongtext', "url(/kongtext.regular.ttf) format('truetype')");
        const ff2 = new FontFace('BPdots', "url(/bpdots.regular.otf) format('opentype')");
        loadFonts([ff1, ff2]);
        loadFonts([ff1, ff2]);
        loadFonts([ff1, ff2]).then(() => loadFonts([ff1, ff2]));
      `);
      (0, import_assert.deepStrictEqual)(await getDocumentFonts(), [{ family: "Kongtext", status: "loaded" }, { family: "BPdots", status: "loaded" }]);
    });
    (0, import_test.default)("autoload & relayout from ctor", async ({ browser }) => {
      const data = await ctx.page.evaluate(`
          document.styleSheets[0].insertRule("@font-face {font-family: Kongtext; src: url(/kongtext.regular.ttf) format('truetype'); unicode-range: U+00A0-00FF}", 0);
        `);
      (0, import_assert.deepStrictEqual)(await getDocumentFonts(), [{ family: "Kongtext", status: "unloaded" }]);
      await ctx.page.evaluate(`
          window.helperTerm = new Terminal({fontFamily: '"Kongtext", ' + term.options.fontFamily});
          window.helperTerm.open(term.element);
        `);
      if (browser.browserType().name() === "webkit") {
        (0, import_assert.deepStrictEqual)(await getDocumentFonts(), [{ family: "Kongtext", status: "loaded" }]);
      } else {
        (0, import_assert.deepStrictEqual)(await getDocumentFonts(), [{ family: "Kongtext", status: "unloaded" }]);
      }
      await ctx.page.evaluate(`
          window.helperTerm.dispose();
          window.helperTerm = new Terminal({fontFamily: '"Kongtext", ' + term.options.fontFamily});
          window._webfontsAddon = new WebFontsAddon();
          window.helperTerm.loadAddon(window._webfontsAddon);
          window.helperTerm.open(term.element);
        `);
      await (0, import_TestUtils.timeout)(100);
      (0, import_assert.deepStrictEqual)(await getDocumentFonts(), [{ family: "Kongtext", status: "loaded" }]);
      await ctx.page.evaluate(`
          window.helperTerm.dispose();
          window._webfontsAddon.dispose();
        `);
    });
  });
});
async function getDocumentFonts() {
  return ctx.page.evaluate(`Array.from(document.fonts).map(ff => ({family: ff.family, status: ff.status}))`);
}
//# sourceMappingURL=WebFontsAddon.test.js.map
