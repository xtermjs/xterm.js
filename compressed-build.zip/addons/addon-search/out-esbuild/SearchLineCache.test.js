"use strict";
var import_chai = require("chai");
var import_SearchLineCache = require("./SearchLineCache");
var import_Terminal = require("browser/public/Terminal");
var import_Async = require("common/Async");
/**
 * Copyright (c) 2024 The xterm.js authors. All rights reserved.
 * @license MIT
 */
function writeP(terminal, data) {
  return new Promise((r) => terminal.write(data, r));
}
describe("SearchLineCache", () => {
  let terminal;
  let cache;
  beforeEach(() => {
    terminal = new import_Terminal.Terminal({ cols: 80, rows: 24 });
    cache = new import_SearchLineCache.SearchLineCache(terminal);
  });
  afterEach(() => {
    cache.dispose();
    terminal.dispose();
  });
  describe("constructor", () => {
    it("should create a SearchLineCache instance", () => {
      import_chai.assert.instanceOf(cache, import_SearchLineCache.SearchLineCache);
    });
    it("should start with no cache initialized", () => {
      import_chai.assert.equal(cache.getLineFromCache(0), void 0);
    });
  });
  describe("initLinesCache", () => {
    it("should initialize the lines cache array", () => {
      cache.initLinesCache();
      import_chai.assert.equal(cache.getLineFromCache(0), void 0, "cache should be initialized but empty");
    });
    it("should not reinitialize if cache already exists", () => {
      cache.initLinesCache();
      cache.setLineInCache(0, ["test", [0]]);
      cache.initLinesCache();
      const entry = cache.getLineFromCache(0);
      import_chai.assert.deepEqual(entry, ["test", [0]], "cache should still contain the previously set entry");
    });
    it("should set up TTL timeout", () => {
      cache.initLinesCache();
      cache.setLineInCache(0, ["test", [0]]);
      import_chai.assert.deepEqual(cache.getLineFromCache(0), ["test", [0]], "entry should exist after initialization");
    });
  });
  describe("getLineFromCache", () => {
    it("should return undefined when cache is not initialized", () => {
      import_chai.assert.equal(cache.getLineFromCache(0), void 0);
      import_chai.assert.equal(cache.getLineFromCache(10), void 0);
    });
    it("should return undefined for unset entries when cache is initialized", () => {
      cache.initLinesCache();
      import_chai.assert.equal(cache.getLineFromCache(0), void 0);
      import_chai.assert.equal(cache.getLineFromCache(50), void 0);
    });
    it("should return cached entries", () => {
      cache.initLinesCache();
      const entry = ["test content", [0]];
      cache.setLineInCache(5, entry);
      import_chai.assert.deepEqual(cache.getLineFromCache(5), entry);
    });
  });
  describe("setLineInCache", () => {
    it("should not set entries when cache is not initialized", () => {
      const entry = ["test content", [0]];
      cache.setLineInCache(0, entry);
      import_chai.assert.equal(cache.getLineFromCache(0), void 0);
    });
    it("should set entries when cache is initialized", () => {
      cache.initLinesCache();
      const entry = ["test content", [0]];
      cache.setLineInCache(10, entry);
      import_chai.assert.deepEqual(cache.getLineFromCache(10), entry);
    });
    it("should overwrite existing entries", () => {
      cache.initLinesCache();
      const entry1 = ["first content", [0]];
      const entry2 = ["second content", [0]];
      cache.setLineInCache(0, entry1);
      import_chai.assert.deepEqual(cache.getLineFromCache(0), entry1);
      cache.setLineInCache(0, entry2);
      import_chai.assert.deepEqual(cache.getLineFromCache(0), entry2);
    });
  });
  describe("translateBufferLineToStringWithWrap", () => {
    it("should translate a single line without wrapping", async () => {
      await writeP(terminal, "Hello World");
      const result = cache.translateBufferLineToStringWithWrap(0, true);
      import_chai.assert.equal(result[0], "Hello World");
      import_chai.assert.deepEqual(result[1], [0]);
    });
    it("should handle trimRight parameter", async () => {
      await writeP(terminal, "Hello World   ");
      const resultTrimmed = cache.translateBufferLineToStringWithWrap(0, true);
      const resultNotTrimmed = cache.translateBufferLineToStringWithWrap(0, false);
      import_chai.assert.equal(resultTrimmed[0].trimEnd(), "Hello World");
      import_chai.assert.isTrue(resultNotTrimmed[0].startsWith("Hello World   "));
      import_chai.assert.isTrue(resultNotTrimmed[0].length > resultTrimmed[0].length, "non-trimmed result should be longer");
    });
    it("should handle wrapped lines", async () => {
      const longText = "A".repeat(200);
      await writeP(terminal, longText);
      const result = cache.translateBufferLineToStringWithWrap(0, true);
      import_chai.assert.equal(result[0], longText);
      import_chai.assert.isTrue(result[1].length > 1, "should have multiple offsets due to wrapping");
      import_chai.assert.equal(result[1][0], 0, "first offset should be 0");
    });
    it("should handle wide characters", async () => {
      await writeP(terminal, "Hello \u4E16\u754C");
      const result = cache.translateBufferLineToStringWithWrap(0, true);
      import_chai.assert.equal(result[0], "Hello \u4E16\u754C");
      import_chai.assert.deepEqual(result[1], [0]);
    });
    it("should handle empty lines", () => {
      const result = cache.translateBufferLineToStringWithWrap(0, true);
      import_chai.assert.equal(result[0], "");
      import_chai.assert.deepEqual(result[1], [0]);
    });
    it("should handle lines beyond buffer", () => {
      const result = cache.translateBufferLineToStringWithWrap(1e3, true);
      import_chai.assert.equal(result[0], "");
      import_chai.assert.deepEqual(result[1], [0]);
    });
    it("should handle complex wrapped content", async () => {
      await writeP(terminal, "Line 1\r\n");
      await writeP(terminal, "Line 2 with some longer content that might wrap\r\n");
      await writeP(terminal, "Line 3");
      const result1 = cache.translateBufferLineToStringWithWrap(0, true);
      const result2 = cache.translateBufferLineToStringWithWrap(1, true);
      const result3 = cache.translateBufferLineToStringWithWrap(2, true);
      import_chai.assert.equal(result1[0], "Line 1");
      import_chai.assert.equal(result2[0], "Line 2 with some longer content that might wrap");
      import_chai.assert.equal(result3[0], "Line 3");
    });
  });
  describe("cache invalidation", () => {
    it("should invalidate cache on line feed", async () => {
      cache.initLinesCache();
      cache.setLineInCache(0, ["test", [0]]);
      import_chai.assert.deepEqual(cache.getLineFromCache(0), ["test", [0]]);
      terminal.write("test\r\n");
      await (0, import_Async.timeout)(10);
      import_chai.assert.equal(cache.getLineFromCache(0), void 0);
    });
    it("should invalidate cache on cursor move", async () => {
      cache.initLinesCache();
      cache.setLineInCache(0, ["test", [0]]);
      import_chai.assert.deepEqual(cache.getLineFromCache(0), ["test", [0]]);
      await writeP(terminal, "some text");
      await (0, import_Async.timeout)(10);
      import_chai.assert.equal(cache.getLineFromCache(0), void 0);
    });
    it("should invalidate cache on resize", async () => {
      cache.initLinesCache();
      cache.setLineInCache(0, ["test", [0]]);
      import_chai.assert.deepEqual(cache.getLineFromCache(0), ["test", [0]]);
      terminal.resize(100, 30);
      await (0, import_Async.timeout)(10);
      import_chai.assert.equal(cache.getLineFromCache(0), void 0);
    });
  });
  describe("disposal", () => {
    it("should clean up resources on dispose", () => {
      cache.initLinesCache();
      cache.setLineInCache(0, ["test", [0]]);
      import_chai.assert.deepEqual(cache.getLineFromCache(0), ["test", [0]]);
      cache.dispose();
      import_chai.assert.equal(cache.getLineFromCache(0), void 0, "cache should be destroyed after disposal");
    });
    it("should be safe to dispose multiple times", () => {
      cache.initLinesCache();
      cache.dispose();
      cache.dispose();
      import_chai.assert.equal(cache.getLineFromCache(0), void 0);
    });
  });
  describe("LineCacheEntry type", () => {
    it("should handle complex line offsets", () => {
      const entry = [
        "A very long line that wraps multiple times across several terminal lines",
        [0, 20, 40, 60]
      ];
      cache.initLinesCache();
      cache.setLineInCache(0, entry);
      const retrieved = cache.getLineFromCache(0);
      import_chai.assert.deepEqual(retrieved, entry);
      import_chai.assert.equal(retrieved[0].length, 72);
      import_chai.assert.equal(retrieved[1].length, 4);
    });
    it("should handle unicode characters in cache entries", () => {
      const entry = [
        "Hello \u4E16\u754C \u{1F30D} \u6D4B\u8BD5",
        [0]
      ];
      cache.initLinesCache();
      cache.setLineInCache(0, entry);
      const retrieved = cache.getLineFromCache(0);
      import_chai.assert.deepEqual(retrieved, entry);
      import_chai.assert.equal(retrieved[0], "Hello \u4E16\u754C \u{1F30D} \u6D4B\u8BD5");
    });
  });
  describe("integration with real terminal content", () => {
    it("should correctly translate real buffer content", async () => {
      await writeP(terminal, "Hello World");
      const cached = cache.translateBufferLineToStringWithWrap(0, true);
      const directTranslation = terminal.buffer.active.getLine(0)?.translateToString(true) || "";
      import_chai.assert.equal(cached[0], directTranslation);
    });
    it("should handle real wrapped content correctly", async () => {
      const longContent = "This is a very long line that will definitely wrap around in an 80 column terminal and should be handled correctly by the cache";
      await writeP(terminal, longContent);
      const result = cache.translateBufferLineToStringWithWrap(0, true);
      import_chai.assert.equal(result[0], longContent);
      import_chai.assert.isTrue(result[1].length > 1, "should have wrapped");
    });
    it("should work with real escape sequences", async () => {
      await writeP(terminal, "Before\x1B[31mRed Text\x1B[0mAfter");
      const result = cache.translateBufferLineToStringWithWrap(0, true);
      import_chai.assert.include(result[0], "Before");
      import_chai.assert.include(result[0], "Red Text");
      import_chai.assert.include(result[0], "After");
    });
  });
});
//# sourceMappingURL=SearchLineCache.test.js.map
