"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var DecorationManager_exports = {};
__export(DecorationManager_exports, {
  DecorationManager: () => DecorationManager
});
module.exports = __toCommonJS(DecorationManager_exports);
var import_Lifecycle = require("common/Lifecycle");
/**
 * Copyright (c) 2017 The xterm.js authors. All rights reserved.
 * @license MIT
 */
class DecorationManager extends import_Lifecycle.Disposable {
  constructor(_terminal) {
    super();
    this._terminal = _terminal;
    this._highlightDecorations = [];
    this._highlightedLines = /* @__PURE__ */ new Set();
    this._register((0, import_Lifecycle.toDisposable)(() => this.clearHighlightDecorations()));
  }
  /**
   * Creates decorations for all provided search results.
   * @param results The search results to create decorations for.
   * @param options The decoration options.
   */
  createHighlightDecorations(results, options) {
    this.clearHighlightDecorations();
    for (const match of results) {
      const decorations = this._createResultDecorations(match, options, false);
      if (decorations) {
        for (const decoration of decorations) {
          this._storeDecoration(decoration, match);
        }
      }
    }
  }
  /**
   * Creates decorations for the currently active search result.
   * @param result The active search result.
   * @param options The decoration options.
   * @returns The multi-highlight decoration or undefined if creation failed.
   */
  createActiveDecoration(result, options) {
    const decorations = this._createResultDecorations(result, options, true);
    if (decorations) {
      return { decorations, match: result, dispose() {
        (0, import_Lifecycle.dispose)(decorations);
      } };
    }
    return void 0;
  }
  /**
   * Clears all highlight decorations.
   */
  clearHighlightDecorations() {
    (0, import_Lifecycle.dispose)(this._highlightDecorations);
    this._highlightDecorations = [];
    this._highlightedLines.clear();
  }
  /**
   * Stores a decoration and tracks it for management.
   * @param decoration The decoration to store.
   * @param match The search result this decoration represents.
   */
  _storeDecoration(decoration, match) {
    this._highlightedLines.add(decoration.marker.line);
    this._highlightDecorations.push({ decoration, match, dispose() {
      decoration.dispose();
    } });
  }
  /**
   * Applies styles to the decoration when it is rendered.
   * @param element The decoration's element.
   * @param borderColor The border color to apply.
   * @param isActiveResult Whether the element is part of the active search result.
   */
  _applyStyles(element, borderColor, isActiveResult) {
    if (!element.classList.contains("xterm-find-result-decoration")) {
      element.classList.add("xterm-find-result-decoration");
      if (borderColor) {
        element.style.outline = `1px solid ${borderColor}`;
      }
    }
    if (isActiveResult) {
      element.classList.add("xterm-find-active-result-decoration");
    }
  }
  /**
   * Creates a decoration for the result and applies styles
   * @param result the search result for which to create the decoration
   * @param options the options for the decoration
   * @param isActiveResult whether this is the currently active result
   * @returns the decorations or undefined if the marker has already been disposed of
   */
  _createResultDecorations(result, options, isActiveResult) {
    const decorationRanges = [];
    let currentCol = result.col;
    let remainingSize = result.size;
    let markerOffset = -this._terminal.buffer.active.baseY - this._terminal.buffer.active.cursorY + result.row;
    while (remainingSize > 0) {
      const amountThisRow = Math.min(this._terminal.cols - currentCol, remainingSize);
      decorationRanges.push([markerOffset, currentCol, amountThisRow]);
      currentCol = 0;
      remainingSize -= amountThisRow;
      markerOffset++;
    }
    const decorations = [];
    for (const range of decorationRanges) {
      const marker = this._terminal.registerMarker(range[0]);
      const decoration = this._terminal.registerDecoration({
        marker,
        x: range[1],
        width: range[2],
        layer: isActiveResult ? "top" : "bottom",
        backgroundColor: isActiveResult ? options.activeMatchBackground : options.matchBackground,
        overviewRulerOptions: this._highlightedLines.has(marker.line) ? void 0 : {
          color: isActiveResult ? options.activeMatchColorOverviewRuler : options.matchOverviewRuler,
          position: "center"
        }
      });
      if (decoration) {
        const disposables = [];
        disposables.push(marker);
        disposables.push(decoration.onRender((e) => this._applyStyles(e, isActiveResult ? options.activeMatchBorder : options.matchBorder, false)));
        disposables.push(decoration.onDispose(() => (0, import_Lifecycle.dispose)(disposables)));
        decorations.push(decoration);
      }
    }
    return decorations.length === 0 ? void 0 : decorations;
  }
}
//# sourceMappingURL=DecorationManager.js.map
