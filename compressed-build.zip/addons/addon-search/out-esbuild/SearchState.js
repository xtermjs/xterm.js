"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var SearchState_exports = {};
__export(SearchState_exports, {
  SearchState: () => SearchState
});
module.exports = __toCommonJS(SearchState_exports);
/**
 * Copyright (c) 2017 The xterm.js authors. All rights reserved.
 * @license MIT
 */
class SearchState {
  /**
   * Gets the currently cached search term.
   */
  get cachedSearchTerm() {
    return this._cachedSearchTerm;
  }
  /**
   * Sets the cached search term.
   */
  set cachedSearchTerm(term) {
    this._cachedSearchTerm = term;
  }
  /**
   * Gets the last search options used.
   */
  get lastSearchOptions() {
    return this._lastSearchOptions;
  }
  /**
   * Sets the last search options used.
   */
  set lastSearchOptions(options) {
    this._lastSearchOptions = options;
  }
  /**
   * Validates a search term to ensure it's not empty or invalid.
   * @param term The search term to validate.
   * @returns true if the term is valid for searching.
   */
  isValidSearchTerm(term) {
    return !!(term && term.length > 0);
  }
  /**
   * Determines if search options have changed compared to the last search.
   * @param newOptions The new search options to compare.
   * @returns true if the options have changed.
   */
  didOptionsChange(newOptions) {
    if (!this._lastSearchOptions) {
      return true;
    }
    if (!newOptions) {
      return false;
    }
    if (this._lastSearchOptions.caseSensitive !== newOptions.caseSensitive) {
      return true;
    }
    if (this._lastSearchOptions.regex !== newOptions.regex) {
      return true;
    }
    if (this._lastSearchOptions.wholeWord !== newOptions.wholeWord) {
      return true;
    }
    return false;
  }
  /**
   * Determines if a new search should trigger highlighting updates.
   * @param term The search term.
   * @param options The search options.
   * @returns true if highlighting should be updated.
   */
  shouldUpdateHighlighting(term, options) {
    if (!options?.decorations) {
      return false;
    }
    return this._cachedSearchTerm === void 0 || term !== this._cachedSearchTerm || this.didOptionsChange(options);
  }
  /**
   * Clears the cached search term.
   */
  clearCachedTerm() {
    this._cachedSearchTerm = void 0;
  }
  /**
   * Resets all state.
   */
  reset() {
    this._cachedSearchTerm = void 0;
    this._lastSearchOptions = void 0;
  }
}
//# sourceMappingURL=SearchState.js.map
