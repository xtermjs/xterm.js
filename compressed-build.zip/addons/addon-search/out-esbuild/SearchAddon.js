"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var SearchAddon_exports = {};
__export(SearchAddon_exports, {
  SearchAddon: () => SearchAddon
});
module.exports = __toCommonJS(SearchAddon_exports);
var import_Event = require("common/Event");
var import_Lifecycle = require("common/Lifecycle");
var import_Async = require("common/Async");
var import_SearchLineCache = require("./SearchLineCache");
var import_SearchState = require("./SearchState");
var import_SearchEngine = require("./SearchEngine");
var import_DecorationManager = require("./DecorationManager");
var import_SearchResultTracker = require("./SearchResultTracker");
/**
 * Copyright (c) 2017 The xterm.js authors. All rights reserved.
 * @license MIT
 */
var Constants = /* @__PURE__ */ ((Constants2) => {
  Constants2[Constants2["DEFAULT_HIGHLIGHT_LIMIT"] = 1e3] = "DEFAULT_HIGHLIGHT_LIMIT";
  return Constants2;
})(Constants || {});
class SearchAddon extends import_Lifecycle.Disposable {
  constructor(options) {
    super();
    this._highlightTimeout = this._register(new import_Lifecycle.MutableDisposable());
    this._lineCache = this._register(new import_Lifecycle.MutableDisposable());
    // Component instances
    this._state = new import_SearchState.SearchState();
    this._resultTracker = this._register(new import_SearchResultTracker.SearchResultTracker());
    this._onAfterSearch = this._register(new import_Event.Emitter());
    this.onAfterSearch = this._onAfterSearch.event;
    this._onBeforeSearch = this._register(new import_Event.Emitter());
    this.onBeforeSearch = this._onBeforeSearch.event;
    this._highlightLimit = options?.highlightLimit ?? 1e3 /* DEFAULT_HIGHLIGHT_LIMIT */;
  }
  get onDidChangeResults() {
    return this._resultTracker.onDidChangeResults;
  }
  activate(terminal) {
    this._terminal = terminal;
    this._lineCache.value = new import_SearchLineCache.SearchLineCache(terminal);
    this._engine = new import_SearchEngine.SearchEngine(terminal, this._lineCache.value);
    this._decorationManager = new import_DecorationManager.DecorationManager(terminal);
    this._register(this._terminal.onWriteParsed(() => this._updateMatches()));
    this._register(this._terminal.onResize(() => this._updateMatches()));
    this._register((0, import_Lifecycle.toDisposable)(() => this.clearDecorations()));
  }
  _updateMatches() {
    this._highlightTimeout.clear();
    if (this._state.cachedSearchTerm && this._state.lastSearchOptions?.decorations) {
      this._highlightTimeout.value = (0, import_Async.disposableTimeout)(() => {
        const term = this._state.cachedSearchTerm;
        this._state.clearCachedTerm();
        this.findPrevious(term, { ...this._state.lastSearchOptions, incremental: true }, { noScroll: true });
      }, 200);
    }
  }
  clearDecorations(retainCachedSearchTerm) {
    this._resultTracker.clearSelectedDecoration();
    this._decorationManager?.clearHighlightDecorations();
    this._resultTracker.clearResults();
    if (!retainCachedSearchTerm) {
      this._state.clearCachedTerm();
    }
  }
  clearActiveDecoration() {
    this._resultTracker.clearSelectedDecoration();
  }
  /**
   * Find the next instance of the term, then scroll to and select it. If it
   * doesn't exist, do nothing.
   * @param term The search term.
   * @param searchOptions Search options.
   * @returns Whether a result was found.
   */
  findNext(term, searchOptions, internalSearchOptions) {
    if (!this._terminal || !this._engine) {
      throw new Error("Cannot use addon until it has been loaded");
    }
    this._onBeforeSearch.fire();
    this._state.lastSearchOptions = searchOptions;
    if (this._state.shouldUpdateHighlighting(term, searchOptions)) {
      this._highlightAllMatches(term, searchOptions);
    }
    const found = this._findNextAndSelect(term, searchOptions, internalSearchOptions);
    this._fireResults(searchOptions);
    this._state.cachedSearchTerm = term;
    this._onAfterSearch.fire();
    return found;
  }
  _highlightAllMatches(term, searchOptions) {
    if (!this._terminal || !this._engine || !this._decorationManager) {
      throw new Error("Cannot use addon until it has been loaded");
    }
    if (!this._state.isValidSearchTerm(term)) {
      this.clearDecorations();
      return;
    }
    this.clearDecorations(true);
    const results = [];
    let prevResult = void 0;
    let result = this._engine.find(term, 0, 0, searchOptions);
    while (result && (prevResult?.row !== result.row || prevResult?.col !== result.col)) {
      if (results.length >= this._highlightLimit) {
        break;
      }
      prevResult = result;
      results.push(prevResult);
      result = this._engine.find(
        term,
        prevResult.col + prevResult.term.length >= this._terminal.cols ? prevResult.row + 1 : prevResult.row,
        prevResult.col + prevResult.term.length >= this._terminal.cols ? 0 : prevResult.col + 1,
        searchOptions
      );
    }
    this._resultTracker.updateResults(results, this._highlightLimit);
    if (searchOptions.decorations) {
      this._decorationManager.createHighlightDecorations(results, searchOptions.decorations);
    }
  }
  _findNextAndSelect(term, searchOptions, internalSearchOptions) {
    if (!this._terminal || !this._engine) {
      return false;
    }
    if (!this._state.isValidSearchTerm(term)) {
      this._terminal.clearSelection();
      this.clearDecorations();
      return false;
    }
    const result = this._engine.findNextWithSelection(term, searchOptions, this._state.cachedSearchTerm);
    return this._selectResult(result, searchOptions?.decorations, internalSearchOptions?.noScroll);
  }
  /**
   * Find the previous instance of the term, then scroll to and select it. If it
   * doesn't exist, do nothing.
   * @param term The search term.
   * @param searchOptions Search options.
   * @returns Whether a result was found.
   */
  findPrevious(term, searchOptions, internalSearchOptions) {
    if (!this._terminal || !this._engine) {
      throw new Error("Cannot use addon until it has been loaded");
    }
    this._onBeforeSearch.fire();
    this._state.lastSearchOptions = searchOptions;
    if (this._state.shouldUpdateHighlighting(term, searchOptions)) {
      this._highlightAllMatches(term, searchOptions);
    }
    const found = this._findPreviousAndSelect(term, searchOptions, internalSearchOptions);
    this._fireResults(searchOptions);
    this._state.cachedSearchTerm = term;
    this._onAfterSearch.fire();
    return found;
  }
  _fireResults(searchOptions) {
    this._resultTracker.fireResultsChanged(!!searchOptions?.decorations);
  }
  _findPreviousAndSelect(term, searchOptions, internalSearchOptions) {
    if (!this._terminal || !this._engine) {
      return false;
    }
    if (!this._state.isValidSearchTerm(term)) {
      this._terminal.clearSelection();
      this.clearDecorations();
      return false;
    }
    const result = this._engine.findPreviousWithSelection(term, searchOptions, this._state.cachedSearchTerm);
    return this._selectResult(result, searchOptions?.decorations, internalSearchOptions?.noScroll);
  }
  /**
   * Selects and scrolls to a result.
   * @param result The result to select.
   * @returns Whether a result was selected.
   */
  _selectResult(result, options, noScroll) {
    if (!this._terminal || !this._decorationManager) {
      return false;
    }
    this._resultTracker.clearSelectedDecoration();
    if (!result) {
      this._terminal.clearSelection();
      return false;
    }
    this._terminal.select(result.col, result.row, result.size);
    if (options) {
      const activeDecoration = this._decorationManager.createActiveDecoration(result, options);
      if (activeDecoration) {
        this._resultTracker.selectedDecoration = activeDecoration;
      }
    }
    if (!noScroll) {
      if (result.row >= this._terminal.buffer.active.viewportY + this._terminal.rows || result.row < this._terminal.buffer.active.viewportY) {
        let scroll = result.row - this._terminal.buffer.active.viewportY;
        scroll -= Math.floor(this._terminal.rows / 2);
        this._terminal.scrollLines(scroll);
      }
    }
    return true;
  }
}
//# sourceMappingURL=SearchAddon.js.map
