"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var SearchLineCache_exports = {};
__export(SearchLineCache_exports, {
  SearchLineCache: () => SearchLineCache
});
module.exports = __toCommonJS(SearchLineCache_exports);
var import_Lifecycle = require("common/Lifecycle");
var import_Async = require("common/Async");
/**
 * Copyright (c) 2017 The xterm.js authors. All rights reserved.
 * @license MIT
 */
var Constants = /* @__PURE__ */ ((Constants2) => {
  Constants2[Constants2["LINES_CACHE_TIME_TO_LIVE"] = 15e3] = "LINES_CACHE_TIME_TO_LIVE";
  return Constants2;
})(Constants || {});
class SearchLineCache extends import_Lifecycle.Disposable {
  constructor(_terminal) {
    super();
    this._terminal = _terminal;
    this._linesCacheTimeout = this._register(new import_Lifecycle.MutableDisposable());
    this._linesCacheDisposables = this._register(new import_Lifecycle.MutableDisposable());
    // Track access to avoid recreating a timeout on every init call which occurs once per search
    // result (findNext/findPrevious -> _highlightAllMatches -> find loop).
    this._lastAccessTimestamp = 0;
    this._register((0, import_Lifecycle.toDisposable)(() => this._destroyLinesCache()));
  }
  /**
   * Sets up a line cache with a ttl
   */
  initLinesCache() {
    if (!this._linesCache) {
      this._linesCache = new Array(this._terminal.buffer.active.length);
      this._linesCacheDisposables.value = (0, import_Lifecycle.combinedDisposable)(
        this._terminal.onLineFeed(() => this._destroyLinesCache()),
        this._terminal.onCursorMove(() => this._destroyLinesCache()),
        this._terminal.onResize(() => this._destroyLinesCache())
      );
    }
    this._lastAccessTimestamp = Date.now();
    if (!this._linesCacheTimeout.value) {
      this._scheduleLinesCacheTimeout(15e3 /* LINES_CACHE_TIME_TO_LIVE */);
    }
  }
  _destroyLinesCache() {
    this._linesCache = void 0;
    this._lastAccessTimestamp = 0;
    this._linesCacheDisposables.clear();
    this._linesCacheTimeout.clear();
  }
  _scheduleLinesCacheTimeout(delay) {
    this._linesCacheTimeout.value = (0, import_Async.disposableTimeout)(() => {
      if (!this._linesCache) {
        return;
      }
      const now = Date.now();
      const elapsed = now - this._lastAccessTimestamp;
      if (elapsed >= 15e3 /* LINES_CACHE_TIME_TO_LIVE */) {
        this._destroyLinesCache();
        return;
      }
      this._scheduleLinesCacheTimeout(15e3 /* LINES_CACHE_TIME_TO_LIVE */ - elapsed);
    }, delay);
  }
  getLineFromCache(row) {
    return this._linesCache?.[row];
  }
  setLineInCache(row, entry) {
    if (this._linesCache) {
      this._linesCache[row] = entry;
    }
  }
  /**
   * Translates a buffer line to a string, including subsequent lines if they are wraps.
   * Wide characters will count as two columns in the resulting string. This
   * function is useful for getting the actual text underneath the raw selection
   * position.
   * @param lineIndex The index of the line being translated.
   * @param trimRight Whether to trim whitespace to the right.
   */
  translateBufferLineToStringWithWrap(lineIndex, trimRight) {
    const strings = [];
    const lineOffsets = [0];
    let line = this._terminal.buffer.active.getLine(lineIndex);
    while (line) {
      const nextLine = this._terminal.buffer.active.getLine(lineIndex + 1);
      const lineWrapsToNext = nextLine ? nextLine.isWrapped : false;
      let string = line.translateToString(!lineWrapsToNext && trimRight);
      if (lineWrapsToNext && nextLine) {
        const lastCell = line.getCell(line.length - 1);
        const lastCellIsNull = lastCell && lastCell.getCode() === 0 && lastCell.getWidth() === 1;
        if (lastCellIsNull && nextLine.getCell(0)?.getWidth() === 2) {
          string = string.slice(0, -1);
        }
      }
      strings.push(string);
      if (lineWrapsToNext) {
        lineOffsets.push(lineOffsets[lineOffsets.length - 1] + string.length);
      } else {
        break;
      }
      lineIndex++;
      line = nextLine;
    }
    return [strings.join(""), lineOffsets];
  }
}
//# sourceMappingURL=SearchLineCache.js.map
