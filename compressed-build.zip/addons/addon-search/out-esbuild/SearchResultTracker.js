"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var SearchResultTracker_exports = {};
__export(SearchResultTracker_exports, {
  SearchResultTracker: () => SearchResultTracker
});
module.exports = __toCommonJS(SearchResultTracker_exports);
var import_Event = require("common/Event");
var import_Lifecycle = require("common/Lifecycle");
/**
 * Copyright (c) 2017 The xterm.js authors. All rights reserved.
 * @license MIT
 */
class SearchResultTracker extends import_Lifecycle.Disposable {
  constructor() {
    super(...arguments);
    this._searchResults = [];
    this._onDidChangeResults = this._register(new import_Event.Emitter());
  }
  get onDidChangeResults() {
    return this._onDidChangeResults.event;
  }
  /**
   * Gets the current search results.
   */
  get searchResults() {
    return this._searchResults;
  }
  /**
   * Gets the currently selected decoration.
   */
  get selectedDecoration() {
    return this._selectedDecoration;
  }
  /**
   * Sets the currently selected decoration.
   */
  set selectedDecoration(decoration) {
    this._selectedDecoration = decoration;
  }
  /**
   * Updates the search results with a new set of results.
   * @param results The new search results.
   * @param maxResults The maximum number of results to track.
   */
  updateResults(results, maxResults) {
    this._searchResults = results.slice(0, maxResults);
  }
  /**
   * Clears all search results.
   */
  clearResults() {
    this._searchResults = [];
  }
  /**
   * Clears the selected decoration.
   */
  clearSelectedDecoration() {
    if (this._selectedDecoration) {
      this._selectedDecoration.dispose();
      this._selectedDecoration = void 0;
    }
  }
  /**
   * Finds the index of a result in the current results array.
   * @param result The result to find.
   * @returns The index of the result, or -1 if not found.
   */
  findResultIndex(result) {
    for (let i = 0; i < this._searchResults.length; i++) {
      const match = this._searchResults[i];
      if (match.row === result.row && match.col === result.col && match.size === result.size) {
        return i;
      }
    }
    return -1;
  }
  /**
   * Fires a result change event with the current state.
   * @param hasDecorations Whether decorations are enabled.
   */
  fireResultsChanged(hasDecorations) {
    if (!hasDecorations) {
      return;
    }
    let resultIndex = -1;
    if (this._selectedDecoration) {
      resultIndex = this.findResultIndex(this._selectedDecoration.match);
    }
    this._onDidChangeResults.fire({
      resultIndex,
      resultCount: this._searchResults.length
    });
  }
  /**
   * Resets all state.
   */
  reset() {
    this.clearSelectedDecoration();
    this.clearResults();
  }
}
//# sourceMappingURL=SearchResultTracker.js.map
