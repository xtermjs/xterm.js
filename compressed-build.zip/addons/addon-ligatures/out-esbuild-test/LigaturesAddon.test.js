"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const path = __importStar(require("path"));
const chai_1 = require("chai");
const fontFinder = require('font-finder');
const ligatureSupport = require('../out-esbuild/index');
const originalList = fontFinder.list;
describe('LigaturesAddon', () => {
    let onRefresh;
    let term;
    const input = 'a -> b www c';
    before(() => {
        fontFinder.list = () => Promise.resolve({
            'Fira Code': [{
                    path: path.join(__dirname, '../fonts/firaCode.otf'),
                    style: fontFinder.Style.Regular,
                    type: fontFinder.Type.Monospace,
                    weight: 400
                }],
            'Iosevka': [{
                    path: path.join(__dirname, '../fonts/iosevka.ttf'),
                    style: fontFinder.Style.Regular,
                    type: fontFinder.Type.Monospace,
                    weight: 400
                }],
            'Nonexistant Font': [{
                    path: path.join(__dirname, '../fonts/nonexistant.ttf'),
                    style: fontFinder.Style.Regular,
                    type: fontFinder.Type.Monospace,
                    weight: 400
                }]
        });
    });
    after(() => {
        fontFinder.list = originalList;
    });
    beforeEach(() => {
        onRefresh = Object.assign((..._args) => { onRefresh.called = true; onRefresh.callCount++; }, { called: false, callCount: 0 });
        term = new MockTerminal(onRefresh);
        ligatureSupport.enableLigatures(term);
    });
    it('registers itself correctly', () => {
        const term = new MockTerminal(() => { });
        chai_1.assert.isUndefined(term.joiner);
        ligatureSupport.enableLigatures(term);
        chai_1.assert.isFunction(term.joiner);
    });
    it('registers itself correctly when called directly', () => {
        const term = new MockTerminal(() => { });
        chai_1.assert.isUndefined(term.joiner);
        ligatureSupport.enableLigatures(term);
        chai_1.assert.isFunction(term.joiner);
    });
    it('returns an empty set of ranges on the first call while the font is loading', () => {
        chai_1.assert.deepEqual(term.joiner(input), []);
    });
    it('fails if it finds but cannot load the font', async () => {
        term.options.fontFamily = 'Nonexistant Font, monospace';
        chai_1.assert.deepEqual(term.joiner(input), []);
        await delay(500);
        chai_1.assert.strictEqual(onRefresh.callCount, 0);
    });
    it('returns nothing if the font is not present on the system', async () => {
        term.options.fontFamily = 'notinstalled';
        chai_1.assert.deepEqual(term.joiner(input), []);
        await delay(500);
        chai_1.assert.strictEqual(onRefresh.callCount, 0);
        chai_1.assert.deepEqual(term.joiner(input), []);
    });
    it('returns nothing if no specific font is specified', async () => {
        term.options.fontFamily = 'monospace';
        chai_1.assert.deepEqual(term.joiner(input), []);
        await delay(500);
        chai_1.assert.strictEqual(onRefresh.callCount, 0);
        chai_1.assert.deepEqual(term.joiner(input), []);
    });
    it('returns nothing if no fonts are provided', async () => {
        term.options.fontFamily = '';
        chai_1.assert.deepEqual(term.joiner(input), []);
        await delay(500);
        chai_1.assert.strictEqual(onRefresh.callCount, 0);
        chai_1.assert.deepEqual(term.joiner(input), []);
    });
    it('fails when given malformed inputs', async () => {
        term.options.fontFamily = {};
        chai_1.assert.deepEqual(term.joiner(input), []);
        await delay(500);
        chai_1.assert.strictEqual(onRefresh.callCount, 0);
    });
});
class MockTerminal {
    _options = {
        fontFamily: 'Fira Code, monospace',
        rows: 50
    };
    joiner;
    refresh;
    constructor(onRefresh) {
        this.refresh = onRefresh;
    }
    registerCharacterJoiner(handler) {
        this.joiner = handler;
        return 1;
    }
    deregisterCharacterJoiner(id) {
        this.joiner = undefined;
    }
    get options() { return this._options; }
    set options(options) {
        for (const key in this._options) {
            this._options[key] = options[key];
        }
    }
}
function delay(delayMs) {
    return new Promise(resolve => setTimeout(resolve, delayMs));
}
//# sourceMappingURL=LigaturesAddon.test.js.map