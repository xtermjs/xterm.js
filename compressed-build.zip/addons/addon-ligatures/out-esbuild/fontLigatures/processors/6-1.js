"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __exports = {};
__export(__exports, {
  default: () => buildTree
});
module.exports = __toCommonJS(__exports);
var import_coverage = require("./coverage");
var import_helper = require("./helper");
function buildTree(table, lookups, tableIndex) {
  const result = {
    individual: {},
    range: []
  };
  const firstGlyphs = (0, import_coverage.listGlyphsByIndex)(table.coverage);
  for (const { glyphId, index } of firstGlyphs) {
    const chainRuleSet = table.chainRuleSets[index];
    if (!chainRuleSet) {
      continue;
    }
    for (const [subIndex, subTable] of chainRuleSet.entries()) {
      let currentEntries = (0, import_helper.getInputTree)(
        result,
        subTable.lookupRecords,
        lookups,
        0,
        glyphId
      ).map(({ entry, substitution }) => ({ entry, substitutions: [substitution] }));
      for (const [index2, glyph] of subTable.input.entries()) {
        currentEntries = (0, import_helper.processInputPosition)(
          [glyph],
          index2 + 1,
          currentEntries,
          subTable.lookupRecords,
          lookups
        );
      }
      for (const glyph of subTable.lookahead) {
        currentEntries = (0, import_helper.processLookaheadPosition)(
          [glyph],
          currentEntries
        );
      }
      for (const glyph of subTable.backtrack) {
        currentEntries = (0, import_helper.processBacktrackPosition)(
          [glyph],
          currentEntries
        );
      }
      for (const { entry, substitutions } of currentEntries) {
        entry.lookup = {
          substitutions,
          length: subTable.input.length + 1,
          index: tableIndex,
          subIndex,
          contextRange: [
            -1 * subTable.backtrack.length,
            1 + subTable.input.length + subTable.lookahead.length
          ]
        };
      }
    }
  }
  return result;
}
//# sourceMappingURL=6-1.js.map
