"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var helper_exports = {};
__export(helper_exports, {
  getInputTree: () => getInputTree,
  processBacktrackPosition: () => processBacktrackPosition,
  processInputPosition: () => processInputPosition,
  processLookaheadPosition: () => processLookaheadPosition
});
module.exports = __toCommonJS(helper_exports);
var import_substitution = require("./substitution");
function processInputPosition(glyphs, position, currentEntries, lookupRecords, lookups) {
  const nextEntries = [];
  for (const currentEntry of currentEntries) {
    currentEntry.entry.forward = {
      individual: {},
      range: []
    };
    for (const glyph of glyphs) {
      nextEntries.push(...getInputTree(
        currentEntry.entry.forward,
        lookupRecords,
        lookups,
        position,
        glyph
      ).map(({ entry, substitution }) => ({
        entry,
        substitutions: [...currentEntry.substitutions, substitution]
      })));
    }
  }
  return nextEntries;
}
function processLookaheadPosition(glyphs, currentEntries) {
  const nextEntries = [];
  const processedEntries = /* @__PURE__ */ new Set();
  for (const currentEntry of currentEntries) {
    if (processedEntries.has(currentEntry.entry)) {
      continue;
    }
    processedEntries.add(currentEntry.entry);
    currentEntry.entry.forward ??= {
      individual: {},
      range: []
    };
    const sharedEntry = {};
    for (const glyph of glyphs) {
      if (Array.isArray(glyph)) {
        currentEntry.entry.forward.range.push({
          entry: sharedEntry,
          range: glyph
        });
      } else {
        currentEntry.entry.forward.individual[glyph] = sharedEntry;
      }
    }
    nextEntries.push({
      entry: sharedEntry,
      substitutions: currentEntry.substitutions
    });
  }
  return nextEntries;
}
function processBacktrackPosition(glyphs, currentEntries) {
  const nextEntries = [];
  const processedEntries = /* @__PURE__ */ new Set();
  for (const currentEntry of currentEntries) {
    if (processedEntries.has(currentEntry.entry)) {
      continue;
    }
    processedEntries.add(currentEntry.entry);
    currentEntry.entry.reverse ??= {
      individual: {},
      range: []
    };
    const sharedEntry = {};
    for (const glyph of glyphs) {
      if (Array.isArray(glyph)) {
        currentEntry.entry.reverse.range.push({
          entry: sharedEntry,
          range: glyph
        });
      } else {
        currentEntry.entry.reverse.individual[glyph] = sharedEntry;
      }
    }
    nextEntries.push({
      entry: sharedEntry,
      substitutions: currentEntry.substitutions
    });
  }
  return nextEntries;
}
function getInputTree(tree, substitutions, lookups, inputIndex, glyphId) {
  const result = [];
  if (!Array.isArray(glyphId)) {
    tree.individual[glyphId] = {};
    result.push({
      entry: tree.individual[glyphId],
      substitution: getSubstitutionAtPosition(substitutions, lookups, inputIndex, glyphId)
    });
  } else {
    const subs = getSubstitutionAtPositionRange(substitutions, lookups, inputIndex, glyphId);
    for (const [range, substitution] of subs) {
      const entry = {};
      if (Array.isArray(range)) {
        tree.range.push({ range, entry });
      } else {
        tree.individual[range] = {};
      }
      result.push({ entry, substitution });
    }
  }
  return result;
}
function getSubstitutionAtPositionRange(substitutions, lookups, index, range) {
  for (const substitution of substitutions.filter((s) => s.sequenceIndex === index)) {
    for (const substitutionTable of lookups[substitution.lookupListIndex].subtables) {
      const sub = (0, import_substitution.getRangeSubstitutionGlyphs)(
        substitutionTable,
        range
      );
      if (!Array.from(sub.values()).every((val) => val !== null)) {
        return sub;
      }
    }
  }
  return /* @__PURE__ */ new Map([[range, null]]);
}
function getSubstitutionAtPosition(substitutions, lookups, index, glyphId) {
  for (const substitution of substitutions.filter((s) => s.sequenceIndex === index)) {
    for (const substitutionTable of lookups[substitution.lookupListIndex].subtables) {
      const sub = (0, import_substitution.getIndividualSubstitutionGlyph)(
        substitutionTable,
        glyphId
      );
      if (sub !== null) {
        return sub;
      }
    }
  }
  return null;
}
//# sourceMappingURL=helper.js.map
