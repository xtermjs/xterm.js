"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var classDef_exports = {};
__export(classDef_exports, {
  default: () => getGlyphClass,
  listClassGlyphs: () => listClassGlyphs
});
module.exports = __toCommonJS(classDef_exports);
function getGlyphClass(table, glyphId) {
  switch (table.format) {
    // https://docs.microsoft.com/en-us/typography/opentype/spec/chapter2#class-definition-table-format-2
    case 2:
      if (Array.isArray(glyphId)) {
        return getRangeGlyphClass(table, glyphId);
      }
      return /* @__PURE__ */ new Map([[
        glyphId,
        getIndividualGlyphClass(table, glyphId)
      ]]);
    // https://docs.microsoft.com/en-us/typography/opentype/spec/chapter2#class-definition-table-format-1
    default:
      return /* @__PURE__ */ new Map([[glyphId, null]]);
  }
}
function getRangeGlyphClass(table, glyphId) {
  const classStart = glyphId[0];
  const currentClass = getIndividualGlyphClass(table, classStart);
  let search = glyphId[0] + 1;
  const result = /* @__PURE__ */ new Map();
  while (search < glyphId[1]) {
    const clazz = getIndividualGlyphClass(table, search);
    if (clazz !== currentClass) {
      if (search - classStart <= 1) {
        result.set(classStart, currentClass);
      } else {
        result.set([classStart, search], currentClass);
      }
    }
    search++;
  }
  if (search - classStart <= 1) {
    result.set(classStart, currentClass);
  } else {
    result.set([classStart, search], currentClass);
  }
  return result;
}
function getIndividualGlyphClass(table, glyphId) {
  for (const range of table.ranges) {
    if (range.start <= glyphId && range.end >= glyphId) {
      return range.classId;
    }
  }
  return null;
}
function listClassGlyphs(table, index) {
  switch (table.format) {
    case 2:
      const results = [];
      for (const range of table.ranges) {
        if (range.classId !== index) {
          continue;
        }
        if (range.end === range.start) {
          results.push(range.start);
        } else {
          results.push([range.start, range.end + 1]);
        }
      }
      return results;
    default:
      return [];
  }
}
//# sourceMappingURL=classDef.js.map
