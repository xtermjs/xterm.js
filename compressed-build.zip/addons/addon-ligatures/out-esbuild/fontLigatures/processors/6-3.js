"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __exports = {};
__export(__exports, {
  default: () => buildTree
});
module.exports = __toCommonJS(__exports);
var import_coverage = require("./coverage");
var import_helper = require("./helper");
function buildTree(table, lookups, tableIndex) {
  const result = {
    individual: {},
    range: []
  };
  const firstGlyphs = (0, import_coverage.listGlyphsByIndex)(table.inputCoverage[0]);
  for (const { glyphId } of firstGlyphs) {
    let currentEntries = (0, import_helper.getInputTree)(
      result,
      table.lookupRecords,
      lookups,
      0,
      glyphId
    ).map(({ entry, substitution }) => ({ entry, substitutions: [substitution] }));
    for (const [index, coverage] of table.inputCoverage.slice(1).entries()) {
      currentEntries = (0, import_helper.processInputPosition)(
        (0, import_coverage.listGlyphsByIndex)(coverage).map((glyph) => glyph.glyphId),
        index + 1,
        currentEntries,
        table.lookupRecords,
        lookups
      );
    }
    for (const coverage of table.lookaheadCoverage) {
      currentEntries = (0, import_helper.processLookaheadPosition)(
        (0, import_coverage.listGlyphsByIndex)(coverage).map((glyph) => glyph.glyphId),
        currentEntries
      );
    }
    for (const coverage of table.backtrackCoverage) {
      currentEntries = (0, import_helper.processBacktrackPosition)(
        (0, import_coverage.listGlyphsByIndex)(coverage).map((glyph) => glyph.glyphId),
        currentEntries
      );
    }
    for (const { entry, substitutions } of currentEntries) {
      entry.lookup = {
        substitutions,
        index: tableIndex,
        subIndex: 0,
        length: table.inputCoverage.length,
        contextRange: [
          -1 * table.backtrackCoverage.length,
          table.inputCoverage.length + table.lookaheadCoverage.length
        ]
      };
    }
  }
  return result;
}
//# sourceMappingURL=6-3.js.map
