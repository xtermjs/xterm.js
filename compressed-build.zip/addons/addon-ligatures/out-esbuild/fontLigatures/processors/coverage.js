"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var coverage_exports = {};
__export(coverage_exports, {
  default: () => getCoverageGlyphIndex,
  listGlyphsByIndex: () => listGlyphsByIndex
});
module.exports = __toCommonJS(coverage_exports);
function getCoverageGlyphIndex(table, glyphId) {
  switch (table.format) {
    // https://docs.microsoft.com/en-us/typography/opentype/spec/chapter2#coverage-format-1
    case 1:
      const index = table.glyphs.indexOf(glyphId);
      return index !== -1 ? index : null;
    // https://docs.microsoft.com/en-us/typography/opentype/spec/chapter2#coverage-format-2
    case 2:
      const range = table.ranges.find((range2) => range2.start <= glyphId && range2.end >= glyphId);
      return range ? range.index : null;
  }
}
function listGlyphsByIndex(table) {
  switch (table.format) {
    case 1:
      return table.glyphs.map((glyphId, index) => ({ glyphId, index }));
    case 2:
      const results = [];
      for (const [index, range] of table.ranges.entries()) {
        if (range.end === range.start) {
          results.push({ glyphId: range.start, index });
        } else {
          results.push({ glyphId: [range.start, range.end + 1], index });
        }
      }
      return results;
  }
}
//# sourceMappingURL=coverage.js.map
