"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __exports = {};
__export(__exports, {
  default: () => buildTree
});
module.exports = __toCommonJS(__exports);
var import_merge = __toESM(require("../merge"));
var import_coverage = require("./coverage");
var import_classDef = __toESM(require("./classDef"));
var import_helper = require("./helper");
function buildTree(table, lookups, tableIndex) {
  const results = [];
  const firstGlyphs = (0, import_coverage.listGlyphsByIndex)(table.coverage);
  for (const { glyphId } of firstGlyphs) {
    const firstInputClass = (0, import_classDef.default)(table.inputClassDef, glyphId);
    for (const [glyphId2, inputClass] of firstInputClass.entries()) {
      if (inputClass === null) {
        continue;
      }
      const classSet = table.chainClassSet[inputClass];
      if (!classSet) {
        continue;
      }
      for (const [subIndex, subTable] of classSet.entries()) {
        const result = {
          individual: {},
          range: []
        };
        let currentEntries = (0, import_helper.getInputTree)(
          result,
          subTable.lookupRecords,
          lookups,
          0,
          glyphId2
        ).map(({ entry, substitution }) => ({ entry, substitutions: [substitution] }));
        for (const [index, classNum] of subTable.input.entries()) {
          currentEntries = (0, import_helper.processInputPosition)(
            (0, import_classDef.listClassGlyphs)(table.inputClassDef, classNum),
            index + 1,
            currentEntries,
            subTable.lookupRecords,
            lookups
          );
        }
        for (const classNum of subTable.lookahead) {
          currentEntries = (0, import_helper.processLookaheadPosition)(
            (0, import_classDef.listClassGlyphs)(table.lookaheadClassDef, classNum),
            currentEntries
          );
        }
        for (const classNum of subTable.backtrack) {
          currentEntries = (0, import_helper.processBacktrackPosition)(
            (0, import_classDef.listClassGlyphs)(table.backtrackClassDef, classNum),
            currentEntries
          );
        }
        for (const { entry, substitutions } of currentEntries) {
          entry.lookup = {
            substitutions,
            index: tableIndex,
            subIndex,
            length: subTable.input.length + 1,
            contextRange: [
              -1 * subTable.backtrack.length,
              1 + subTable.input.length + subTable.lookahead.length
            ]
          };
        }
        results.push(result);
      }
    }
  }
  return (0, import_merge.default)(results);
}
//# sourceMappingURL=6-2.js.map
