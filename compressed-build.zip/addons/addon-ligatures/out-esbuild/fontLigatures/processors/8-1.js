"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __exports = {};
__export(__exports, {
  default: () => buildTree
});
module.exports = __toCommonJS(__exports);
var import_coverage = require("./coverage");
var import_helper = require("./helper");
function buildTree(table, tableIndex) {
  const result = {
    individual: {},
    range: []
  };
  const glyphs = (0, import_coverage.listGlyphsByIndex)(table.coverage);
  for (const { glyphId, index } of glyphs) {
    const initialEntry = {};
    if (Array.isArray(glyphId)) {
      result.range.push({
        entry: initialEntry,
        range: glyphId
      });
    } else {
      result.individual[glyphId] = initialEntry;
    }
    let currentEntries = [{
      entry: initialEntry,
      substitutions: [table.substitutes[index]]
    }];
    for (const coverage of table.lookaheadCoverage) {
      currentEntries = (0, import_helper.processLookaheadPosition)(
        (0, import_coverage.listGlyphsByIndex)(coverage).map((glyph) => glyph.glyphId),
        currentEntries
      );
    }
    for (const coverage of table.backtrackCoverage) {
      currentEntries = (0, import_helper.processBacktrackPosition)(
        (0, import_coverage.listGlyphsByIndex)(coverage).map((glyph) => glyph.glyphId),
        currentEntries
      );
    }
    for (const { entry, substitutions } of currentEntries) {
      entry.lookup = {
        substitutions,
        index: tableIndex,
        subIndex: 0,
        length: 1,
        contextRange: [
          -1 * table.backtrackCoverage.length,
          1 + table.lookaheadCoverage.length
        ]
      };
    }
  }
  return result;
}
//# sourceMappingURL=8-1.js.map
