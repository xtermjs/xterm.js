"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var substitution_exports = {};
__export(substitution_exports, {
  getIndividualSubstitutionGlyph: () => getIndividualSubstitutionGlyph,
  getRangeSubstitutionGlyphs: () => getRangeSubstitutionGlyphs
});
module.exports = __toCommonJS(substitution_exports);
var import_coverage = __toESM(require("./coverage"));
function getRangeSubstitutionGlyphs(table, glyphId) {
  const replacementStart = glyphId[0];
  const currentReplacement = getIndividualSubstitutionGlyph(table, replacementStart);
  let search = glyphId[0] + 1;
  const result = /* @__PURE__ */ new Map();
  while (search < glyphId[1]) {
    const sub = getIndividualSubstitutionGlyph(table, search);
    if (sub !== currentReplacement) {
      if (search - replacementStart <= 1) {
        result.set(replacementStart, currentReplacement);
      } else {
        result.set([replacementStart, search], currentReplacement);
      }
    }
    search++;
  }
  if (search - replacementStart <= 1) {
    result.set(replacementStart, currentReplacement);
  } else {
    result.set([replacementStart, search], currentReplacement);
  }
  return result;
}
function getIndividualSubstitutionGlyph(table, glyphId) {
  const coverageIndex = (0, import_coverage.default)(table.coverage, glyphId);
  if (coverageIndex === null) {
    return null;
  }
  switch (table.substFormat) {
    // https://docs.microsoft.com/en-us/typography/opentype/spec/gsub#11-single-substitution-format-1
    case 1:
      return (glyphId + table.deltaGlyphId) % 2 ** 16;
    // https://docs.microsoft.com/en-us/typography/opentype/spec/gsub#12-single-substitution-format-2
    case 2:
      return table.substitute[coverageIndex] ?? null;
  }
}
//# sourceMappingURL=substitution.js.map
