"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var walk_exports = {};
__export(walk_exports, {
  default: () => walkTree
});
module.exports = __toCommonJS(walk_exports);
function walkTree(tree, sequence, startIndex, index) {
  const glyphId = sequence[index];
  const subtree = tree[glyphId];
  if (!subtree) {
    return void 0;
  }
  let lookup = subtree.lookup;
  if (subtree.reverse) {
    const reverseLookup = walkReverse(subtree.reverse, sequence, startIndex);
    if (!lookup && reverseLookup || reverseLookup && lookup && (lookup.index > reverseLookup.index || lookup.index === reverseLookup.index && lookup.subIndex > reverseLookup.subIndex)) {
      lookup = reverseLookup;
    }
  }
  if (++index >= sequence.length || !subtree.forward) {
    return lookup;
  }
  const forwardLookup = walkTree(subtree.forward, sequence, startIndex, index);
  if (!lookup && forwardLookup || forwardLookup && lookup && (lookup.index > forwardLookup.index || lookup.index === forwardLookup.index && lookup.subIndex > forwardLookup.subIndex)) {
    lookup = forwardLookup;
  }
  return lookup;
}
function walkReverse(tree, sequence, index) {
  let subtree = tree[sequence[--index]];
  let lookup = subtree && subtree.lookup;
  while (subtree) {
    if (!lookup && subtree.lookup || subtree.lookup && lookup && lookup.index > subtree.lookup.index) {
      lookup = subtree.lookup;
    }
    if (--index < 0 || !subtree.reverse) {
      break;
    }
    subtree = subtree.reverse[sequence[index]];
  }
  return lookup;
}
//# sourceMappingURL=walk.js.map
