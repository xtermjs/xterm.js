"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var flatten_exports = {};
__export(flatten_exports, {
  default: () => flatten
});
module.exports = __toCommonJS(flatten_exports);
function flatten(tree, visited = /* @__PURE__ */ new Map()) {
  const result = {};
  for (const [glyphId, entry] of Object.entries(tree.individual)) {
    result[glyphId] = flattenEntry(entry, visited);
  }
  for (const { range, entry } of tree.range) {
    const flattened = flattenEntry(entry, visited);
    for (let glyphId = range[0]; glyphId < range[1]; glyphId++) {
      result[glyphId] = flattened;
    }
  }
  return result;
}
function flattenEntry(entry, visited) {
  if (visited.has(entry)) {
    return visited.get(entry);
  }
  const result = {};
  visited.set(entry, result);
  if (entry.forward) {
    result.forward = flatten(entry.forward, visited);
  }
  if (entry.reverse) {
    result.reverse = flatten(entry.reverse, visited);
  }
  if (entry.lookup) {
    result.lookup = entry.lookup;
  }
  return result;
}
//# sourceMappingURL=flatten.js.map
