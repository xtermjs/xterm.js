"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var import_chai = require("chai");
var import_mergeRange = __toESM(require("./mergeRange"));
/**
 * Copyright (c) 2018 The xterm.js authors. All rights reserved.
 * @license MIT
 */
describe("addon-ligatures - mergeRange", () => {
  it("inserts a new range before the existing ones", () => {
    const result = (0, import_mergeRange.default)([[1, 2], [2, 3]], 0, 1);
    import_chai.assert.deepEqual(result, [[0, 1], [1, 2], [2, 3]]);
  });
  it("inserts in between two ranges", () => {
    const result = (0, import_mergeRange.default)([[0, 2], [4, 6]], 2, 4);
    import_chai.assert.deepEqual(result, [[0, 2], [2, 4], [4, 6]]);
  });
  it("inserts after the last range", () => {
    const result = (0, import_mergeRange.default)([[0, 2], [4, 6]], 6, 8);
    import_chai.assert.deepEqual(result, [[0, 2], [4, 6], [6, 8]]);
  });
  it("extends the beginning of a range", () => {
    const result = (0, import_mergeRange.default)([[0, 2], [4, 6]], 3, 5);
    import_chai.assert.deepEqual(result, [[0, 2], [3, 6]]);
  });
  it("extends the end of a range", () => {
    const result = (0, import_mergeRange.default)([[0, 2], [4, 6]], 1, 4);
    import_chai.assert.deepEqual(result, [[0, 4], [4, 6]]);
  });
  it("extends the last range", () => {
    const result = (0, import_mergeRange.default)([[0, 2], [4, 6]], 5, 7);
    import_chai.assert.deepEqual(result, [[0, 2], [4, 7]]);
  });
  it("connects two ranges", () => {
    const result = (0, import_mergeRange.default)([[0, 2], [4, 6]], 1, 5);
    import_chai.assert.deepEqual(result, [[0, 6]]);
  });
  it("connects more than two ranges", () => {
    const result = (0, import_mergeRange.default)([[0, 2], [4, 6], [8, 10], [12, 14]], 1, 10);
    import_chai.assert.deepEqual(result, [[0, 10], [12, 14]]);
  });
});
//# sourceMappingURL=mergeRange.test.js.map
