"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fontLigatures_exports = {};
__export(fontLigatures_exports, {
  Font: () => import_types.IFont,
  LigatureData: () => import_types.ILigatureData,
  Options: () => import_types.IOptions,
  loadBuffer: () => loadBuffer
});
module.exports = __toCommonJS(fontLigatures_exports);
var opentype = __toESM(require("opentype.js"));
var import_types = require("./types");
var import_merge = __toESM(require("./merge"));
var import_walk = __toESM(require("./walk"));
var import_mergeRange = __toESM(require("./mergeRange"));
var import__ = __toESM(require("./processors/6-1"));
var import__2 = __toESM(require("./processors/6-2"));
var import__3 = __toESM(require("./processors/6-3"));
var import__4 = __toESM(require("./processors/8-1"));
var import_flatten = __toESM(require("./flatten"));
const LRUCache = require("lru-cache");
class FontImpl {
  constructor(font, options) {
    this._lookupTrees = [];
    this._glyphLookups = {};
    this._font = font;
    if (options.cacheSize > 0) {
      this._cache = new LRUCache({
        max: options.cacheSize,
        length: ((val, key) => key.length)
      });
    }
    const caltFeatures = this._font.tables.gsub && this._font.tables.gsub.features.filter((f) => f.tag === "calt") || [];
    const lookupIndices = caltFeatures.reduce((acc, val) => [...acc, ...val.feature.lookupListIndexes], []);
    const allLookups = this._font.tables.gsub && this._font.tables.gsub.lookups || [];
    const lookupGroups = allLookups.filter((l, i) => lookupIndices.some((idx) => idx === i));
    for (const [index, lookup] of lookupGroups.entries()) {
      const trees = [];
      switch (lookup.lookupType) {
        case 6:
          for (const [index2, table] of lookup.subtables.entries()) {
            switch (table.substFormat) {
              case 1:
                trees.push((0, import__.default)(table, allLookups, index2));
                break;
              case 2:
                trees.push((0, import__2.default)(table, allLookups, index2));
                break;
              case 3:
                trees.push((0, import__3.default)(table, allLookups, index2));
                break;
            }
          }
          break;
        case 8:
          for (const [index2, table] of lookup.subtables.entries()) {
            trees.push((0, import__4.default)(table, index2));
          }
          break;
      }
      const tree = (0, import_flatten.default)((0, import_merge.default)(trees));
      this._lookupTrees.push({
        tree,
        processForward: lookup.lookupType !== 8
      });
      for (const glyphId of Object.keys(tree)) {
        if (!this._glyphLookups[glyphId]) {
          this._glyphLookups[glyphId] = [];
        }
        this._glyphLookups[glyphId].push(index);
      }
    }
  }
  findLigatures(text) {
    const cached = this._cache && this._cache.get(text);
    if (cached && !Array.isArray(cached)) {
      return cached;
    }
    const glyphIds = [];
    for (const char of text) {
      glyphIds.push(this._font.charToGlyphIndex(char));
    }
    if (this._lookupTrees.length === 0) {
      return {
        inputGlyphs: glyphIds,
        outputGlyphs: glyphIds,
        contextRanges: []
      };
    }
    const result = this._findInternal(glyphIds.slice());
    const finalResult = {
      inputGlyphs: glyphIds,
      outputGlyphs: result.sequence,
      contextRanges: result.ranges
    };
    if (this._cache) {
      this._cache.set(text, finalResult);
    }
    return finalResult;
  }
  findLigatureRanges(text) {
    if (this._lookupTrees.length === 0) {
      return [];
    }
    const cached = this._cache && this._cache.get(text);
    if (cached) {
      return Array.isArray(cached) ? cached : cached.contextRanges;
    }
    const glyphIds = [];
    for (const char of text) {
      glyphIds.push(this._font.charToGlyphIndex(char));
    }
    const result = this._findInternal(glyphIds);
    if (this._cache) {
      this._cache.set(text, result.ranges);
    }
    return result.ranges;
  }
  _findInternal(sequence) {
    const ranges = [];
    let nextLookup = this._getNextLookup(sequence, 0);
    while (nextLookup.index !== null) {
      const lookup = this._lookupTrees[nextLookup.index];
      if (lookup.processForward) {
        let lastGlyphIndex = nextLookup.last;
        for (let i = nextLookup.first; i < lastGlyphIndex; i++) {
          const result = (0, import_walk.default)(lookup.tree, sequence, i, i);
          if (result) {
            for (let j = 0; j < result.substitutions.length; j++) {
              const sub = result.substitutions[j];
              if (sub !== null) {
                sequence[i + j] = sub;
              }
            }
            (0, import_mergeRange.default)(
              ranges,
              result.contextRange[0] + i,
              result.contextRange[1] + i
            );
            if (i + result.length >= lastGlyphIndex) {
              lastGlyphIndex = i + result.length + 1;
            }
            i += result.length - 1;
          }
        }
      } else {
        for (let i = nextLookup.last - 1; i >= nextLookup.first; i--) {
          const result = (0, import_walk.default)(lookup.tree, sequence, i, i);
          if (result) {
            for (let j = 0; j < result.substitutions.length; j++) {
              const sub = result.substitutions[j];
              if (sub !== null) {
                sequence[i + j] = sub;
              }
            }
            (0, import_mergeRange.default)(
              ranges,
              result.contextRange[0] + i,
              result.contextRange[1] + i
            );
            i -= result.length - 1;
          }
        }
      }
      nextLookup = this._getNextLookup(sequence, nextLookup.index + 1);
    }
    return { sequence, ranges };
  }
  /**
   * Returns the lookup and glyph range for the first lookup that might
   * contain a match.
   *
   * @param sequence Input glyph sequence
   * @param start The first input to try
   */
  _getNextLookup(sequence, start) {
    const result = {
      index: null,
      first: Infinity,
      last: -1
    };
    for (let i = 0; i < sequence.length; i++) {
      const lookups = this._glyphLookups[sequence[i]];
      if (!lookups) {
        continue;
      }
      for (let j = 0; j < lookups.length; j++) {
        const lookupIndex = lookups[j];
        if (lookupIndex >= start) {
          if (result.index === null || lookupIndex <= result.index) {
            result.index = lookupIndex;
            if (result.first > i) {
              result.first = i;
            }
            result.last = i + 1;
          }
          break;
        }
      }
    }
    return result;
  }
}
function loadBuffer(buffer, options) {
  const font = opentype.parse(buffer);
  return new FontImpl(font, {
    cacheSize: 0,
    ...options
  });
}
//# sourceMappingURL=index.js.map
