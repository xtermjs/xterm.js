"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var mergeRange_exports = {};
__export(mergeRange_exports, {
  default: () => mergeRange
});
module.exports = __toCommonJS(mergeRange_exports);
function mergeRange(ranges, newRangeStart, newRangeEnd) {
  let inRange = false;
  for (let i = 0; i < ranges.length; i++) {
    const range = ranges[i];
    if (!inRange) {
      if (newRangeEnd <= range[0]) {
        ranges.splice(i, 0, [newRangeStart, newRangeEnd]);
        return ranges;
      }
      if (newRangeEnd <= range[1]) {
        range[0] = Math.min(newRangeStart, range[0]);
        return ranges;
      }
      if (newRangeStart < range[1]) {
        range[0] = Math.min(newRangeStart, range[0]);
        inRange = true;
      } else {
        continue;
      }
    } else {
      if (newRangeEnd <= range[0]) {
        ranges[i - 1][1] = newRangeEnd;
        return ranges;
      }
      if (newRangeEnd <= range[1]) {
        ranges[i - 1][1] = Math.max(newRangeEnd, range[1]);
        ranges.splice(i, 1);
        inRange = false;
        return ranges;
      }
      ranges.splice(i, 1);
      i--;
    }
  }
  if (inRange) {
    ranges[ranges.length - 1][1] = newRangeEnd;
  } else {
    ranges.push([newRangeStart, newRangeEnd]);
  }
  return ranges;
}
//# sourceMappingURL=mergeRange.js.map
