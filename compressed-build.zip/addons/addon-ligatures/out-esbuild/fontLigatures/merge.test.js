"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var import_chai = require("chai");
var import_merge = __toESM(require("./merge"));
/**
 * Copyright (c) 2018 The xterm.js authors. All rights reserved.
 * @license MIT
 */
function lookup(substitutionGlyph, index, subIndex) {
  return {
    contextRange: [0, 1],
    index: index || 0,
    subIndex: subIndex || 0,
    length: 1,
    substitutions: [substitutionGlyph]
  };
}
describe("addon-ligatures - merge", () => {
  describe("mergeTrees", () => {
    it("combines disjoint trees", () => {
      const result = (0, import_merge.default)([
        {
          individual: {
            "1": { lookup: lookup(1) }
          },
          range: []
        },
        {
          individual: {},
          range: [{
            entry: { lookup: lookup(2) },
            range: [2, 4]
          }]
        },
        {
          individual: {
            "5": { lookup: lookup(3) }
          },
          range: []
        },
        {
          individual: {},
          range: [{
            entry: { lookup: lookup(4) },
            range: [8, 10]
          }]
        }
      ]);
      import_chai.assert.deepEqual(result, {
        individual: {
          "1": { lookup: lookup(1) },
          "5": { lookup: lookup(3) }
        },
        range: [{
          entry: { lookup: lookup(2) },
          range: [2, 4]
        }, {
          entry: { lookup: lookup(4) },
          range: [8, 10]
        }]
      });
    });
    it("merges matching individual glyphs", () => {
      const result = (0, import_merge.default)([
        {
          individual: {
            "1": { lookup: lookup(1, 1) }
          },
          range: []
        },
        {
          individual: {
            "1": { lookup: lookup(2, 0) }
          },
          range: []
        },
        {
          individual: {
            "1": { lookup: lookup(3, 2) }
          },
          range: []
        }
      ]);
      import_chai.assert.deepEqual(result, {
        individual: {
          "1": { lookup: lookup(2, 0) }
        },
        range: []
      });
    });
    it("merges range glyphs overlapping individual glyphs", () => {
      const result = (0, import_merge.default)([
        {
          individual: {
            "1": { lookup: lookup(1, 0) }
          },
          range: []
        },
        {
          individual: {},
          range: [{
            entry: { lookup: lookup(2, 1) },
            range: [0, 4]
          }]
        }
      ]);
      import_chai.assert.deepEqual(result, {
        individual: {
          "0": { lookup: lookup(2, 1) },
          "1": { lookup: lookup(1, 0) }
        },
        range: [{
          entry: { lookup: lookup(2, 1) },
          range: [2, 4]
        }]
      });
    });
    it("merges individual glyphs overlapping range glyphs", () => {
      const result = (0, import_merge.default)([
        {
          individual: {},
          range: [{
            entry: { lookup: lookup(2, 1) },
            range: [0, 4]
          }]
        },
        {
          individual: {
            "1": { lookup: lookup(1, 0) }
          },
          range: []
        }
      ]);
      import_chai.assert.deepEqual(result, {
        individual: {
          "0": { lookup: lookup(2, 1) },
          "1": { lookup: lookup(1, 0) }
        },
        range: [{
          entry: { lookup: lookup(2, 1) },
          range: [2, 4]
        }]
      });
    });
    it("merges multiple overlapping ranges", () => {
      const result = (0, import_merge.default)([
        {
          individual: {},
          range: [{
            entry: { lookup: lookup(1, 2) },
            range: [0, 3]
          }, {
            entry: { lookup: lookup(2, 1) },
            range: [6, 12]
          }, {
            entry: { lookup: lookup(5, 3) },
            range: [15, 20]
          }, {
            entry: { lookup: lookup(7, 4) },
            range: [20, 22]
          }]
        },
        {
          individual: {},
          range: [{
            entry: { lookup: lookup(3, 0) },
            range: [2, 8]
          }, {
            entry: { lookup: lookup(4, 0) },
            range: [10, 13]
          }, {
            entry: { lookup: lookup(6, 0) },
            range: [16, 21]
          }]
        }
      ]);
      import_chai.assert.deepEqual(result, {
        individual: {
          "2": { lookup: lookup(3, 0) },
          "12": { lookup: lookup(4, 0) },
          "15": { lookup: lookup(5, 3) },
          "20": { lookup: lookup(6, 0) },
          "21": { lookup: lookup(7, 4) }
        },
        range: [{
          entry: { lookup: lookup(1, 2) },
          range: [0, 2]
        }, {
          entry: { lookup: lookup(3, 0) },
          range: [6, 8]
        }, {
          entry: { lookup: lookup(3, 0) },
          range: [3, 6]
        }, {
          entry: { lookup: lookup(2, 1) },
          range: [8, 10]
        }, {
          entry: { lookup: lookup(4, 0) },
          range: [10, 12]
        }, {
          entry: { lookup: lookup(6, 0) },
          range: [16, 20]
        }]
      });
    });
  });
});
//# sourceMappingURL=merge.test.js.map
