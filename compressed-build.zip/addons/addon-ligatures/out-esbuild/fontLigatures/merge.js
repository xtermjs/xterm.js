"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var merge_exports = {};
__export(merge_exports, {
  default: () => mergeTrees
});
module.exports = __toCommonJS(merge_exports);
function mergeTrees(trees) {
  const result = {
    individual: {},
    range: []
  };
  const mergedEntries = /* @__PURE__ */ new WeakMap();
  for (const tree of trees) {
    mergeSubtree(result, tree, mergedEntries);
  }
  return result;
}
function mergeSubtree(mainTree, mergeTree, mergedEntries) {
  for (const [glyphId, value] of Object.entries(mergeTree.individual)) {
    if (mainTree.individual[glyphId]) {
      mergeTreeEntry(mainTree.individual[glyphId], value, mergedEntries);
    } else {
      let matched = false;
      for (const [index, { range, entry }] of mainTree.range.entries()) {
        const overlap = getIndividualOverlap(Number(glyphId), range);
        if (overlap.both === null) {
          continue;
        }
        matched = true;
        mainTree.individual[glyphId] = value;
        mergeTreeEntry(mainTree.individual[glyphId], cloneEntry(entry), mergedEntries);
        mainTree.range.splice(index, 1);
        for (const glyph of overlap.second) {
          if (Array.isArray(glyph)) {
            mainTree.range.push({
              range: glyph,
              entry: cloneEntry(entry)
            });
          } else {
            mainTree.individual[glyph] = cloneEntry(entry);
          }
        }
      }
      if (!matched) {
        mainTree.individual[glyphId] = value;
      }
    }
  }
  for (const { range, entry } of mergeTree.range) {
    let remainingRanges = [range];
    for (let index = 0; index < mainTree.range.length; index++) {
      const { range: range2, entry: resultEntry } = mainTree.range[index];
      for (const [remainingIndex, remainingRange] of remainingRanges.entries()) {
        if (Array.isArray(remainingRange)) {
          const overlap = getRangeOverlap(remainingRange, range2);
          if (overlap.both === null) {
            continue;
          }
          mainTree.range.splice(index, 1);
          index--;
          const entryToMerge = cloneEntry(resultEntry);
          if (Array.isArray(overlap.both)) {
            mainTree.range.push({
              range: overlap.both,
              entry: entryToMerge
            });
          } else {
            mainTree.individual[overlap.both] = entryToMerge;
          }
          mergeTreeEntry(entryToMerge, cloneEntry(entry), mergedEntries);
          for (const second of overlap.second) {
            if (Array.isArray(second)) {
              mainTree.range.push({
                range: second,
                entry: cloneEntry(resultEntry)
              });
            } else {
              mainTree.individual[second] = cloneEntry(resultEntry);
            }
          }
          remainingRanges = overlap.first;
        } else {
          const overlap = getIndividualOverlap(remainingRange, range2);
          if (overlap.both === null) {
            continue;
          }
          mainTree.individual[remainingRange] = cloneEntry(entry);
          mergeTreeEntry(mainTree.individual[remainingRange], cloneEntry(resultEntry), mergedEntries);
          mainTree.range.splice(index, 1);
          index--;
          for (const glyph of overlap.second) {
            if (Array.isArray(glyph)) {
              mainTree.range.push({
                range: glyph,
                entry: cloneEntry(resultEntry)
              });
            } else {
              mainTree.individual[glyph] = cloneEntry(resultEntry);
            }
          }
          remainingRanges.splice(remainingIndex, 1, ...overlap.first);
          break;
        }
      }
    }
    for (const glyphId of Object.keys(mainTree.individual)) {
      for (const [remainingIndex, remainingRange] of remainingRanges.entries()) {
        if (Array.isArray(remainingRange)) {
          const overlap = getIndividualOverlap(Number(glyphId), remainingRange);
          if (overlap.both === null) {
            continue;
          }
          mergeTreeEntry(mainTree.individual[glyphId], cloneEntry(entry), mergedEntries);
          remainingRanges.splice(remainingIndex, 1, ...overlap.second);
          break;
        } else {
          if (Number(glyphId) === remainingRange) {
            mergeTreeEntry(mainTree.individual[glyphId], cloneEntry(entry), mergedEntries);
            break;
          }
        }
      }
    }
    for (const remainingRange of remainingRanges) {
      if (Array.isArray(remainingRange)) {
        mainTree.range.push({
          range: remainingRange,
          entry: cloneEntry(entry)
        });
      } else {
        mainTree.individual[remainingRange] = cloneEntry(entry);
      }
    }
  }
}
function mergeTreeEntry(mainTree, mergeTree, mergedEntries) {
  let mergedSet = mergedEntries.get(mainTree);
  if (mergedSet?.has(mergeTree)) {
    return;
  }
  if (!mergedSet) {
    mergedSet = /* @__PURE__ */ new Set();
    mergedEntries.set(mainTree, mergedSet);
  }
  mergedSet.add(mergeTree);
  if (mergeTree.lookup && (!mainTree.lookup || mainTree.lookup.index > mergeTree.lookup.index || mainTree.lookup.index === mergeTree.lookup.index && mainTree.lookup.subIndex > mergeTree.lookup.subIndex)) {
    mainTree.lookup = mergeTree.lookup;
  }
  if (mergeTree.forward) {
    if (!mainTree.forward) {
      mainTree.forward = mergeTree.forward;
    } else {
      mergeSubtree(mainTree.forward, mergeTree.forward, mergedEntries);
    }
  }
  if (mergeTree.reverse) {
    if (!mainTree.reverse) {
      mainTree.reverse = mergeTree.reverse;
    } else {
      mergeSubtree(mainTree.reverse, mergeTree.reverse, mergedEntries);
    }
  }
}
function getRangeOverlap(first, second) {
  const result = {
    first: [],
    second: [],
    both: null
  };
  if (first[0] < second[1] && second[0] < first[1]) {
    const start = Math.max(first[0], second[0]);
    const end = Math.min(first[1], second[1]);
    result.both = rangeOrIndividual(start, end);
  }
  if (first[0] < second[0]) {
    const start = first[0];
    const end = Math.min(second[0], first[1]);
    result.first.push(rangeOrIndividual(start, end));
  } else if (second[0] < first[0]) {
    const start = second[0];
    const end = Math.min(second[1], first[0]);
    result.second.push(rangeOrIndividual(start, end));
  }
  if (first[1] > second[1]) {
    const start = Math.max(first[0], second[1]);
    const end = first[1];
    result.first.push(rangeOrIndividual(start, end));
  } else if (second[1] > first[1]) {
    const start = Math.max(first[1], second[0]);
    const end = second[1];
    result.second.push(rangeOrIndividual(start, end));
  }
  return result;
}
function getIndividualOverlap(first, second) {
  if (first < second[0] || first > second[1]) {
    return {
      first: [first],
      second: [second],
      both: null
    };
  }
  const result = {
    first: [],
    second: [],
    both: first
  };
  if (second[0] < first) {
    result.second.push(rangeOrIndividual(second[0], first));
  }
  if (second[1] > first) {
    result.second.push(rangeOrIndividual(first + 1, second[1]));
  }
  return result;
}
function rangeOrIndividual(start, end) {
  if (end - start === 1) {
    return start;
  }
  return [start, end];
}
function cloneEntry(entry, visited = /* @__PURE__ */ new Map()) {
  if (visited.has(entry)) {
    return visited.get(entry);
  }
  const result = {};
  visited.set(entry, result);
  if (entry.forward) {
    result.forward = cloneTree(entry.forward, visited);
  }
  if (entry.reverse) {
    result.reverse = cloneTree(entry.reverse, visited);
  }
  if (entry.lookup) {
    result.lookup = {
      contextRange: entry.lookup.contextRange.slice(),
      index: entry.lookup.index,
      length: entry.lookup.length,
      subIndex: entry.lookup.subIndex,
      substitutions: entry.lookup.substitutions.slice()
    };
  }
  return result;
}
function cloneTree(tree, visited = /* @__PURE__ */ new Map()) {
  const individual = {};
  for (const [glyphId, entry] of Object.entries(tree.individual)) {
    individual[glyphId] = cloneEntry(entry, visited);
  }
  return {
    individual,
    range: tree.range.map(({ range, entry }) => ({
      range: range.slice(),
      entry: cloneEntry(entry, visited)
    }))
  };
}
//# sourceMappingURL=merge.js.map
